import { Career } from '../types';
import { CAREER_PATHS } from './careers';
import { ADDITIONAL_CAREERS } from './moreCareers';

export const ALL_CAREERS: Career[] = [...CAREER_PATHS, ...ADDITIONAL_CAREERS];

export function getCareerById(id: string): Career {
  const found = ALL_CAREERS.find((c) => c.id === id);
  return found || ALL_CAREERS[0];
}

export function getAllSkills(career: Career) {
  return career.skillTree;
}

export function findSkillAndModule(moduleId: string): {
  career?: Career;
  skill?: Career['skillTree'][0];
  module?: Career['skillTree'][0]['modules'][0];
} {
  for (const c of ALL_CAREERS) {
    for (const s of c.skillTree) {
      for (const m of s.modules) {
        if (m.id === moduleId) {
          return { career: c, skill: s, module: m };
        }
      }
    }
  }
  return {};
}
