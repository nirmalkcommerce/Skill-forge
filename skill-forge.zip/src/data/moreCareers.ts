import { Career } from '../types';

export const ADDITIONAL_CAREERS: Career[] = [
  {
    id: 'financial-analyst',
    title: 'Financial Analyst',
    tagline: 'Evaluate financial health, build valuation models, and guide strategic capital investments.',
    category: 'Finance',
    icon: 'TrendingUp',
    difficulty: 'Intermediate',
    estimatedHours: '60–75 hours',
    summary:
      'Financial analysts evaluate economic trends, audit corporate balance sheets, build financial models, analyze capital expenditures, and advise management on investment decisions.',
    responsibilities: [
      'Constructing 3-statement financial models (Income, Balance Sheet, Cash Flow)',
      'Evaluating discounted cash flow (DCF) and comparable company valuations',
      'Auditing historical financial performance and variance against budget',
      'Assessing risk profiles and return on invested capital (ROIC) for new ventures',
      'Preparing quarterly investor decks and board presentations',
    ],
    prerequisites: [
      'Solid numeracy and understanding of basic accounting principles',
      'Comfort with detailed spreadsheet modeling',
    ],
    coreSkills: [
      { name: 'Financial Statement Analysis', proficiencyTarget: 85, description: 'Balance sheet, income statement, cash flows' },
      { name: 'Financial Modeling & DCF', proficiencyTarget: 80, description: 'WACC, terminal value, sensitivity tables' },
      { name: 'Excel for Finance', proficiencyTarget: 90, description: 'INDEX/MATCH, dynamic arrays, scenario managers' },
      { name: 'Valuation Methodologies', proficiencyTarget: 75, description: 'Precedent transactions, trading comps, DCF' },
      { name: 'Business Forecasting', proficiencyTarget: 75, description: 'Variance analysis, scenario forecasting' },
    ],
    assessmentOverview:
      'Cash flow projection modeling, variance explanation memos, and investment case study defense.',
    realWorldOutcome:
      'Deliver an investment thesis memo accompanied by a live 3-statement forecast model.',
    skillTree: [
      {
        id: 'fin-found',
        title: 'Financial Statements & Cash Flow',
        shortDesc: 'Understand the linkage between income, balance sheet, and operating cash flow.',
        category: 'foundation',
        prerequisites: [],
        estimatedMinutes: 25,
        icon: 'DollarSign',
        modules: [
          {
            id: 'fin-found-1',
            skillId: 'fin-found',
            title: 'Cash Flow vs Net Income',
            estimatedMinutes: 20,
            goal: 'Analyze why a company showing positive accounting net income can experience a cash crisis.',
            learnContent: {
              keyConcepts: [
                'Accrual accounting vs Cash accounting',
                'Working capital swings: Accounts Receivable & Inventory build-ups',
                'Operating Cash Flow (OCF) as the true measure of solvency',
              ],
              explanation:
                'Revenue is booked when earned, not when cash hits the bank. If a company ships $10M of goods on 90-day payment terms, it shows high paper profits while being unable to pay next week payroll.',
              workplaceContext:
                'During economic downturns, suppliers extend receivables. Financial analysts track days sales outstanding (DSO) to protect liquidity.',
            },
            example: {
              title: 'The Solvency Trap',
              description: 'Company XYZ Q2 financials:',
              sampleData: {
                headers: ['Metric', 'Reported Amount', 'Diagnostic Note'],
                rows: [
                  ['Net Income', '+$450,000', 'Looks profitable on paper'],
                  ['Accounts Receivable Change', '+$1,200,000', 'Customers have not paid cash yet'],
                  ['Operating Cash Flow', '-$620,000', 'Severe cash burn requiring immediate credit line'],
                ],
              },
              keyTakeaway: 'Cash flow pays bills, not accounting net income.',
            },
            practice: {
              question: 'If a company has $1M in net income but accounts receivable increases by $400K, what is the cash impact on operating cash flow?',
              options: [
                'Operating cash flow increases by $400K',
                'Operating cash flow decreases by $400K because cash is tied up in unpaid customer invoices',
                'There is no change to cash flow',
                'Net income becomes negative',
              ],
              correctIndex: 1,
              explanation:
                'An increase in accounts receivable is a cash outflow/use of cash on the Cash Flow Statement.',
              hint: 'Cash has not been received yet.',
            },
            apply: {
              title: 'Liquidity Advisory Memo',
              scenario:
                'Your CFO notices revenue grew 50% this quarter but cash in the bank dropped by $300K. In 2 sentences, explain the most likely reason and recommend 1 action.',
              starterQueryOrText: 'Cash is tied up in working capital...',
              modelSolution:
                'Rapid growth frequently consumes cash through bloated inventory purchases and delayed accounts receivable collections from new clients. We recommend tightening payment terms to 30 days and securing a working capital revolving facility.',
              rubricTip: 'Accurately diagnoses working capital strain during rapid growth.',
            },
            assessment: {
              questions: [
                {
                  id: 'q-fin-1',
                  type: 'mcq',
                  prompt: 'Why is EBITDA widely used by analysts despite not including depreciation and taxes?',
                  options: [
                    'It provides a clean proxy for operating cash generation before capital structure and tax differences',
                    'EBITDA is required by tax authorities to file taxes',
                    'It ignores all company expenses',
                    'It guarantees higher stock prices',
                  ],
                  correctAnswer: 0,
                  explanation:
                    'EBITDA normalizes for differing debt structures and capital expenditure intensity across comparable companies.',
                },
              ],
            },
          },
        ],
      },
    ],
    projects: [
      {
        id: 'fin-proj-1',
        careerId: 'financial-analyst',
        title: 'Retail Expansion Capital Valuation & DCF Model',
        summary:
          'Build a 5-year discounted cash flow model evaluating whether an omnichannel retail brand should open 20 new flagship locations.',
        skillsCovered: ['DCF Modeling', 'WACC Calculation', 'Sensitivity Analysis', 'Executive Briefing'],
        difficulty: 'Standard',
        estimatedTime: '6–8 hours',
        sampleDataOrScenario:
          'Management has $15M in discretionary capital. You must model projected store sales, lease liabilities, inflation, and discount cash flows at 8.5% WACC.',
        steps: [
          {
            title: '1. Revenue & Capex Projections',
            description: 'Model unit economics per store including fit-out capital and working capital.',
            deliverable: 'Dynamic spreadsheet tab.',
          },
          {
            title: '2. DCF & Sensitivity Table',
            description: 'Calculate Net Present Value (NPV) and Internal Rate of Return (IRR) across varying foot-traffic scenarios.',
            deliverable: 'Sensitivity matrix.',
          },
        ],
        rubric: ['Accurate formula linkages', 'Clear scenario toggles (Bull/Base/Bear)'],
      },
    ],
  },
  {
    id: 'project-manager',
    title: 'Project Coordinator / Manager',
    tagline: 'Deliver complex projects on time, within budget, and with high stakeholder alignment.',
    category: 'Management',
    icon: 'CheckSquare',
    difficulty: 'Beginner Friendly',
    estimatedHours: '45–60 hours',
    summary:
      'Project managers align cross-functional teams, define project scopes, manage budgets and timelines, anticipate risks, unblock operational friction, and ensure clear communication with leadership.',
    responsibilities: [
      'Creating Work Breakdown Structures (WBS) and realistic sprint timelines',
      'Facilitating Agile ceremonies: daily standups, sprint planning, retrospectives',
      'Maintaining a comprehensive Risk, Assumption, Issue, Dependency (RAID) log',
      'Managing scope creep and processing change requests with business sponsors',
      'Publishing weekly status reports highlighting critical path items',
    ],
    prerequisites: ['Strong organizational skills and empathy for diverse team roles'],
    coreSkills: [
      { name: 'Agile & Scrum Methodologies', proficiencyTarget: 85, description: 'Sprints, standups, Kanban, backlog grooming' },
      { name: 'Scope & Work Breakdown (WBS)', proficiencyTarget: 80, description: 'Milestones, dependencies, critical path' },
      { name: 'Risk Management (RAID)', proficiencyTarget: 85, description: 'Probability, impact, mitigation plans' },
      { name: 'Stakeholder Communication', proficiencyTarget: 85, description: 'Status reporting, conflict resolution' },
      { name: 'Budget & Resource Allocation', proficiencyTarget: 70, description: 'Capacity planning, burn rates' },
    ],
    assessmentOverview:
      'Schedule variance troubleshooting, risk mitigation trade-offs, and critical path analysis.',
    realWorldOutcome:
      'Deliver an end-to-end project charter, RAID register, and critical path Gantt schedule.',
    skillTree: [
      {
        id: 'pm-found',
        title: 'Project Scope & Critical Path',
        shortDesc: 'Understand the project triple constraint (Scope, Time, Cost) and critical path analysis.',
        category: 'foundation',
        prerequisites: [],
        estimatedMinutes: 20,
        icon: 'Calendar',
        modules: [
          {
            id: 'pm-found-1',
            skillId: 'pm-found',
            title: 'The Triple Constraint & Managing Scope Creep',
            estimatedMinutes: 20,
            goal: 'Negotiate trade-offs when stakeholders request new features without extending budget or timeline.',
            learnContent: {
              keyConcepts: [
                'The Triple Constraint: Scope, Time, and Budget (with Quality in the center)',
                'Identifying scope creep before it damages team morale',
                'Formal change request procedures',
              ],
              explanation:
                'You cannot increase scope without either increasing budget or pushing the deadline—unless you sacrifice quality. Skilled project managers educate sponsors on these trade-offs transparently.',
              workplaceContext:
                'Two weeks before a major app release, the sales VP requests 3 new custom export options for a prospect.',
            },
            example: {
              title: 'Handling a Late Scope Request',
              description: 'Diplomatic trade-off negotiation:',
              codeSnippet: `Hi [Sponsor],
We can certainly include the custom export feature.
Because our engineering capacity is committed to the core payment milestone next week, adding this feature requires one of two options:
Option A: Push our public launch date by 10 business days to accommodate testing.
Option B: Release on the agreed launch date and prioritize exports in Sprint 14 immediately following release.
Which option aligns best with your strategic priorities?`,
              keyTakeaway: 'Always present clear, actionable choices rather than an unhelpful flat refusal.',
            },
            practice: {
              question: 'What is the Critical Path in project scheduling?',
              options: [
                'The sequence of dependent tasks that represents the longest overall duration, where any delay delays the entire project',
                'The list of tasks that are most fun to work on',
                'The path taken by the CEO to visit the office',
                'The tasks that cost the least money',
              ],
              correctIndex: 0,
              explanation:
                'The critical path has zero slack or float; any delay on these items directly pushes the project delivery date.',
              hint: 'Zero float sequence of dependent tasks.',
            },
            apply: {
              title: 'Critical Path Schedule Recovery',
              scenario:
                'A supplier informs you that hardware components on your project critical path will arrive 5 days late. Draft your 3-step action plan to keep the launch on schedule.',
              starterQueryOrText: 'Step 1: Assess schedule float...\nStep 2: ...\nStep 3: ...',
              modelSolution:
                '1. Assess schedule dependencies to see if subsequent software testing can be fast-tracked or started in parallel on simulator units. 2. Inquire about expedited priority freight or backup suppliers. 3. Update the RAID log and inform executive sponsors immediately with the proposed mitigation.',
              rubricTip: 'Emphasizes proactive schedule compression and transparent stakeholder communication.',
            },
            assessment: {
              questions: [
                {
                  id: 'q-pm-1',
                  type: 'mcq',
                  prompt: 'What does a RAID log track in project management?',
                  options: [
                    'Risks, Assumptions, Issues, and Dependencies',
                    'Revenue, Assets, Income, and Debt',
                    'Reports, Audits, Invoices, and Deliverables',
                    'Random Automated Internet Data',
                  ],
                  correctAnswer: 0,
                  explanation:
                    'RAID is the industry standard framework for tracking project vulnerabilities and interdependencies.',
                },
              ],
            },
          },
        ],
      },
    ],
    projects: [
      {
        id: 'pm-proj-1',
        careerId: 'project-manager',
        title: 'Mobile App Launch Operational Charter & Schedule',
        summary:
          'Create a full project management charter, sprint schedule, and risk mitigation plan for a 4-month cross-functional mobile app rollout.',
        skillsCovered: ['WBS', 'Agile Backlog', 'RAID Register', 'Resource Allocation'],
        difficulty: 'Standard',
        estimatedTime: '5–7 hours',
        sampleDataOrScenario:
          'A health tech startup is launching its first patient-doctor teleconsultation app, involving mobile engineers, legal compliance, and hospital onboarding teams.',
        steps: [
          {
            title: '1. Project Charter & Scope Statement',
            description: 'Define clear project boundaries, deliverables, and out-of-scope items.',
            deliverable: 'Charter document with sign-off criteria.',
          },
          {
            title: '2. RAID Register & Critical Path',
            description: 'Identify 5 high-impact regulatory and technical risks with mitigation playbooks.',
            deliverable: 'Complete RAID register.',
          },
        ],
        rubric: ['Thorough risk planning', 'Realistic timeline estimates'],
      },
    ],
  },
  {
    id: 'content-strategist',
    title: 'Content & Media Strategist',
    tagline: 'Craft high-converting narratives, editorial architectures, and multi-platform media that build brand trust.',
    category: 'Content',
    icon: 'PenTool',
    difficulty: 'Beginner Friendly',
    estimatedHours: '40–55 hours',
    summary:
      'Content strategists craft editorial architectures, author brand narratives, script video and audio assets, optimize content for search intent, and analyze reader engagement to drive loyalty and action.',
    responsibilities: [
      'Developing brand editorial voice guidelines and multi-channel content pillars',
      'Researching customer search intent and authoring authoritative case studies',
      'Writing high-converting landing page copy, video scripts, and newsletter editions',
      'Auditing content performance metrics: dwell time, social shares, lead conversions',
      'Repurposing core long-form research into snackable micro-content across channels',
    ],
    prerequisites: ['Passion for clear writing, storytelling, and audience psychology'],
    coreSkills: [
      { name: 'Editorial Strategy & Content Pillars', proficiencyTarget: 85, description: 'Audience resonance, thematic planning' },
      { name: 'Copywriting & Persuasion', proficiencyTarget: 85, description: 'Hook, story, offer, clear calls-to-action' },
      { name: 'SEO Content Architecture', proficiencyTarget: 75, description: 'Topic clusters, search intent, internal linking' },
      { name: 'Video & Audio Scripting', proficiencyTarget: 70, description: 'Pacing, visual cues, hook retention' },
      { name: 'Content Analytics & Optimization', proficiencyTarget: 70, description: 'Scroll depth, click-through rates, conversions' },
    ],
    assessmentOverview:
      'Editorial calendar design, headline A/B split testing, and long-form case study composition.',
    realWorldOutcome:
      'Publish a comprehensive Content Strategy Guide with a live portfolio of published articles and scripts.',
    skillTree: [
      {
        id: 'cs-found',
        title: 'Storytelling & Brand Voice',
        shortDesc: 'Understand brand tone, audience hooks, and structured narrative arcs.',
        category: 'foundation',
        prerequisites: [],
        estimatedMinutes: 20,
        icon: 'BookOpen',
        modules: [
          {
            id: 'cs-found-1',
            skillId: 'cs-found',
            title: 'Writing Compelling Professional Case Studies',
            estimatedMinutes: 20,
            goal: 'Structure high-converting customer success stories using the Problem-Agitation-Solution (PAS) framework.',
            learnContent: {
              keyConcepts: [
                'Problem-Agitation-Solution (PAS) and Hero Journey in B2B content',
                'Backing claims with specific numerical evidence rather than generic praise',
                'Formatting for scannability: subheadings, callout blocks, pull quotes',
              ],
              explanation:
                'Readers scan before they read. If a case study reads like boring corporate PR, nobody shares it. When it reads like a real story with honest challenges, readers trust your brand.',
              workplaceContext:
                'Prospects in the consideration stage read customer case studies to justify the purchasing decision to their CFO.',
            },
            example: {
              title: 'Corporate Fluff vs Authentic Proof',
              description: 'Comparing case study lead paragraphs:',
              codeSnippet: `// BAD: "Company X is proud to deliver world-class synergy that empowered Client Y."

// GOOD:
"In October 2024, Meridian Logistics was losing $84,000 every month to missed delivery time windows.
Here is how their operations team cut routing errors by 73% in 60 days using automated geofencing."`,
              keyTakeaway: 'Specific numbers and real struggles make case studies memorable and trustworthy.',
            },
            practice: {
              question: 'Which of the following headlines will achieve higher reader click-through and trust?',
              options: [
                'Our Software is the Best in the Industry',
                'How a 4-Person Support Team Answered 12,000 Tickets in 48 Hours Without Burnout',
                'A General Discussion on Customer Service Solutions',
                'Why You Need Synergy Today',
              ],
              correctIndex: 1,
              explanation:
                'Specific numbers, relatable scale, and an emotional stakes resolution create high curiosity and credibility.',
              hint: 'Look for specific proof and human outcome.',
            },
            apply: {
              title: 'Customer Success Story Hook',
              scenario:
                'A boutique coffee roasting client increased subscription retention from 35% to 62% by introducing a personalized roast quiz. Draft the opening 2 sentences of a case study featuring this achievement.',
              starterQueryOrText: 'For most direct-to-consumer coffee brands, customer retention drops after 30 days...',
              modelSolution:
                'For specialty coffee roasters, nearly two-thirds of first-time subscribers cancel before their second bag. By replacing generic bean descriptions with an interactive 60-second roast quiz, BeanCraft boosted 90-day subscriber retention from 35% to 62%.',
              rubricTip: 'Combines industry reality, specific action, and verified numerical improvement.',
            },
            assessment: {
              questions: [
                {
                  id: 'q-cs-1',
                  type: 'mcq',
                  prompt: 'What does "search intent" mean in content strategy?',
                  options: [
                    'The underlying goal or question that motivates a user to type a specific query into a search engine',
                    'The algorithm code used by Google',
                    'The speed at which a user types on their keyboard',
                    'The number of ads displayed on a page',
                  ],
                  correctAnswer: 0,
                  explanation:
                    'Search intent dictates whether the user wants information (informational), a specific site (navigational), or to buy (transactional).',
                },
              ],
            },
          },
        ],
      },
    ],
    projects: [
      {
        id: 'cs-proj-1',
        careerId: 'content-strategist',
        title: 'Brand Editorial Style Guide & Pillar Content Hub',
        summary:
          'Create a 3-month content architecture strategy including topic clusters, editorial tone guidelines, and 3 full-length showcase articles.',
        skillsCovered: ['Content Architecture', 'Editorial Guidelines', 'Copywriting', 'SEO Topic Clusters'],
        difficulty: 'Standard',
        estimatedTime: '5–7 hours',
        sampleDataOrScenario:
          'A sustainable home architecture studio wants to establish themselves as the thought leader in passive solar heating and net-zero residential construction.',
        steps: [
          {
            title: '1. Brand Voice & Editorial Tone Matrix',
            description: 'Define voice attributes, do/do-not guidelines, and grammar conventions.',
            deliverable: 'Brand tone matrix.',
          },
          {
            title: '2. Topic Cluster Content Map',
            description: 'Structure 1 pillar page with 6 supporting cluster sub-topics.',
            deliverable: 'Visual topic cluster hierarchy.',
          },
        ],
        rubric: ['Avoids generic clichés', 'Compelling storytelling with scannable structure'],
      },
    ],
  },
  {
    id: 'tech-entrepreneur',
    title: 'Technology Entrepreneur',
    tagline: 'Discover unmet needs, validate customer willingness to pay, and build scalable ventures.',
    category: 'Entrepreneurship',
    icon: 'Rocket',
    difficulty: 'Intermediate',
    estimatedHours: '60–80 hours',
    summary:
      'Entrepreneurs turn ideas into viable, self-sustaining businesses. They conduct customer problem discovery, prototype minimal viable products (MVPs), calculate unit economics, acquire initial customers, and iterate rapidly based on market feedback.',
    responsibilities: [
      'Conducting Mom Test customer interviews to discover genuine user friction',
      'Defining core value propositions and constructing lightweight prototypes / MVPs',
      'Calculating customer acquisition cost (CAC), lifetime value (LTV), and gross margins',
      'Designing early traction experiments and sales outreach strategies',
      'Assembling investor pitch decks and articulating clear defensible moats',
    ],
    prerequisites: ['Resilience, curiosity, and willingness to listen to hard customer feedback'],
    coreSkills: [
      { name: 'Customer Discovery & Validation', proficiencyTarget: 85, description: 'The Mom Test, problem interviews, pain identification' },
      { name: 'MVP Prototyping', proficiencyTarget: 80, description: 'No-code, rapid MVPs, smoke tests, landing page tests' },
      { name: 'Unit Economics & Financial Viability', proficiencyTarget: 80, description: 'CAC, LTV, churn, contribution margin, payback period' },
      { name: 'Go-To-Market & Early Traction', proficiencyTarget: 80, description: 'Cold outreach, founder-led sales, distribution loops' },
      { name: 'Pitching & Investor Relations', proficiencyTarget: 75, description: 'Storytelling, market sizing (TAM/SAM/SOM), deck design' },
    ],
    assessmentOverview:
      'Customer interview audits, unit economics modeling, traction experiment design, and pitch deck defense.',
    realWorldOutcome:
      'Produce a validated venture memo with recorded customer interview synthesis, an MVP specification, and unit economics model.',
    skillTree: [
      {
        id: 'ent-found',
        title: 'Customer Discovery & Problem Validation',
        shortDesc: 'Learn how to talk to customers and avoid false positive validation.',
        category: 'foundation',
        prerequisites: [],
        estimatedMinutes: 20,
        icon: 'Compass',
        modules: [
          {
            id: 'ent-found-1',
            skillId: 'ent-found',
            title: 'The Mom Test: Uncovering Genuine Pain Points',
            estimatedMinutes: 20,
            goal: 'Ask unbiased interview questions about past behavior instead of asking hypothetical opinions.',
            learnContent: {
              keyConcepts: [
                'Rule 1: Talk about their life and past actions, not your idea',
                'Rule 2: Ask about specific instances in the past, not generic hypothetical futures',
                'Rule 3: Talk less and listen more (avoid pitching during discovery)',
              ],
              explanation:
                'People want to be polite. If you ask friends or colleagues "Would you buy an app that organizes your closet?", they will always say yes. But they won’t actually pay. Validating past spending and active workarounds proves real demand.',
              workplaceContext:
                '90% of startups fail because they build something nobody actually wants. Mastering customer interviews de-risks your time before writing a single line of code.',
            },
            example: {
              title: 'Hypothetical Question vs Past Behavior',
              description: 'Interview dialogue comparison:',
              sampleData: {
                headers: ['Question Approach', 'Example Question', 'Data Quality'],
                rows: [
                  ['Bad (Hypothetical)', '"Would you pay $10/month for an automated recipe meal planner?"', 'Useless: Users guess and say yes out of politeness'],
                  ['Good (Past Behavior)', '"When was the last time you planned meals for the week? What was difficult about it?"', 'High: Reveals real habits and friction'],
                  ['Gold (Active Workaround)', '"What tools or apps have you already tried or spent money on to solve this?"', 'Highest: Proves existing budget and desperation'],
                ],
              },
              keyTakeaway: 'Look for active workarounds: if they haven’t searched for a solution, the pain is not severe.',
            },
            practice: {
              question: 'Which of the following questions is most effective during customer discovery interviews?',
              options: [
                'Do you think our AI solution is innovative?',
                'How much would you pay for this if we built it?',
                'Tell me about the last time this problem happened. How did you resolve it and how much time did it take?',
                'Will you invest in my seed round?',
              ],
              correctIndex: 2,
              explanation:
                'Asking about the last specific instance reveals real concrete actions, true severity, and actual time/money spent.',
              hint: 'Focus on concrete past experiences.',
            },
            apply: {
              title: 'Startup Problem Interview Script',
              scenario:
                'You want to start a software tool helping freelance contractors track business expenses. Draft 3 customer discovery questions that strictly follow The Mom Test rules.',
              starterQueryOrText: 'Question 1: How do you currently...\nQuestion 2: ...\nQuestion 3: ...',
              modelSolution:
                '1. How did you handle your business expense receipts during the last tax filing season? 2. What was the most frustrating part of that process, and what software or tools did you use? 3. Have you ever lost money or deductions because of a missing receipt? What did you do when that happened?',
              rubricTip: 'Strictly avoids pitching or asking hypothetical "would you buy" questions.',
            },
            assessment: {
              questions: [
                {
                  id: 'q-ent-1',
                  type: 'mcq',
                  prompt: 'Why is a pre-order or deposit the highest form of idea validation?',
                  options: [
                    'It legally binds the customer to buy all future products',
                    'It proves the customer experiences enough friction to part with real currency before the product is finished',
                    'It prevents competitors from launching similar ideas',
                    'It guarantees venture capital funding immediately',
                  ],
                  correctAnswer: 1,
                  explanation:
                    'Financial commitment is the definitive truth in business validation, filtering out casual compliments.',
                },
              ],
            },
          },
        ],
      },
    ],
    projects: [
      {
        id: 'ent-proj-1',
        careerId: 'tech-entrepreneur',
        title: 'Venture Opportunity Assessment & MVP Launch Plan',
        summary:
          'Validate a customer pain point through 5 structured interviews, design a smoke test MVP landing page, and calculate unit economics.',
        skillsCovered: ['Customer Discovery', 'Smoke Testing', 'Unit Economics', 'GTM Strategy'],
        difficulty: 'Standard',
        estimatedTime: '6–8 hours',
        sampleDataOrScenario:
          'You notice independent auto repair shops struggle with inventory tracking and ordering parts during busy repair days, often keeping cars on lifts overnight.',
        steps: [
          {
            title: '1. Customer Interview Synthesis',
            description: 'Summarize insights, quotes, and active workarounds from discovery interviews.',
            deliverable: 'Validation matrix.',
          },
          {
            title: '2. Unit Economics Model',
            description: 'Model CAC, subscription pricing ($149/mo), churn assumptions, and payback period.',
            deliverable: 'Unit economics spreadsheet.',
          },
        ],
        rubric: ['Real past-behavior questions used', 'Feasible unit economics with margin calculations'],
      },
    ],
  },
];
