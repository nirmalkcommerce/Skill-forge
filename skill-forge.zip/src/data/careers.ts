import { Career } from '../types';

export const CAREER_PATHS: Career[] = [
  {
    id: 'data-analyst',
    title: 'Data Analyst',
    tagline: 'Turn raw numbers into actionable business decisions and clear stories.',
    category: 'Data & AI',
    icon: 'BarChart3',
    difficulty: 'Beginner Friendly',
    estimatedHours: '60–80 hours of active practice',
    summary:
      'Data analysts inspect, clean, transform, and model data to discover useful information, inform conclusions, and support organizational decision-making across product, sales, marketing, and operations.',
    responsibilities: [
      'Extracting and querying databases with SQL to answer key business questions',
      'Cleaning untidy spreadsheets and handling missing or anomalous values',
      'Calculating statistical metrics and identifying core growth drivers',
      'Building interactive dashboards that executive teams rely on daily',
      'Translating complex data findings into actionable recommendations for non-technical leaders',
    ],
    prerequisites: [
      'Curiosity about how businesses make decisions',
      'Basic comfort with spreadsheets and numbers (no advanced math degree required)',
      'Willingness to learn logical query languages',
    ],
    coreSkills: [
      { name: 'Excel & Spreadsheets', proficiencyTarget: 85, description: 'Formulas, VLOOKUP/XLOOKUP, Pivot Tables, Cleaning' },
      { name: 'SQL Querying', proficiencyTarget: 80, description: 'SELECT, WHERE, JOINs, GROUP BY, Aggregations' },
      { name: 'Statistics & Math', proficiencyTarget: 70, description: 'Distributions, Outliers, Correlation vs Causation' },
      { name: 'Python for Analysis', proficiencyTarget: 65, description: 'Pandas, NumPy, Exploratory Data Analysis' },
      { name: 'Data Visualization', proficiencyTarget: 80, description: 'Visual hierarchy, chart selection, storytelling' },
      { name: 'Business Communication', proficiencyTarget: 75, description: 'Executive summaries, actionable recommendations' },
    ],
    assessmentOverview:
      'Performance-based assessments consisting of SQL query authoring, spreadsheet data transformation, metric interpretation scenarios, and capstone project demonstrations.',
    realWorldOutcome:
      'Build a verified portfolio containing real-world datasets, reproducible queries, and executive dashboards demonstrating applied analytical competency.',
    skillTree: [
      {
        id: 'da-foundation',
        title: 'Analytical Foundations',
        shortDesc: 'Understand business metrics, data literacy, and structured problem framing.',
        category: 'foundation',
        prerequisites: [],
        estimatedMinutes: 20,
        icon: 'BookOpen',
        modules: [
          {
            id: 'da-found-1',
            skillId: 'da-foundation',
            title: 'Business Metrics & Problem Framing',
            estimatedMinutes: 15,
            goal: 'Distinguish between vanity metrics and decision-driving KPIs in a business environment.',
            learnContent: {
              keyConcepts: [
                'KPIs (Key Performance Indicators) vs Vanity Metrics',
                'Input metrics vs Output metrics',
                'The structured problem-solving framework: Situation, Question, Hypothesis, Validation',
              ],
              explanation:
                'In the workplace, leaders do not ask for "charts" for fun—they need to solve problems like dropping retention or rising acquisition costs. A metric is only valuable if a change in its value leads to a specific business action.',
              workplaceContext:
                'A subscription app notices daily downloads are up 40%, but monthly recurring revenue is flat. As an analyst, your role is to dissect the conversion funnel rather than celebrate download volume.',
            },
            example: {
              title: 'Output vs Input Metrics at a Retailer',
              description: 'Retail leaders wanted to increase quarterly revenue by 10%.',
              sampleData: {
                headers: ['Metric Name', 'Type', 'Actionability'],
                rows: [
                  ['Quarterly Total Revenue', 'Output (Lagging)', 'Cannot directly change today'],
                  ['Average Cart Size', 'Input (Leading)', 'Can optimize bundles and cross-sells'],
                  ['Email Re-engagement Rate', 'Input (Leading)', 'Can refine subject lines and offers'],
                ],
              },
              keyTakeaway: 'Focus analysis on controllable input metrics to influence the lagging business outcome.',
            },
            practice: {
              question: 'Which of the following is an actionable input metric for an e-commerce store?',
              options: [
                'Total gross annual merchandise value',
                'Checkout abandonment rate on mobile checkout page',
                'Total number of Twitter followers',
                'CEO satisfaction score',
              ],
              correctIndex: 1,
              explanation:
                'Checkout abandonment rate on mobile is a direct, measurable input that engineering and design can investigate and improve.',
              hint: 'Look for the metric that points directly to where customers encounter friction.',
            },
            apply: {
              title: 'Executive Metric Audit',
              scenario:
                'A regional delivery startup CEO asks: "Our website visits doubled last month, so why are our profits down?" Write a 2-3 sentence diagnosis explaining what metrics you will investigate first.',
              starterQueryOrText: 'I would look into customer acquisition costs versus order completion...',
              modelSolution:
                'I would investigate customer acquisition cost (CAC) per channel, checkout conversion rate, and average order value. A traffic surge often brings lower-intent visitors or expensive ad clicks that fail to generate profitable orders.',
              rubricTip:
                'Notice how this connects marketing spend, traffic quality, and actual unit economics.',
            },
            assessment: {
              questions: [
                {
                  id: 'q1',
                  type: 'mcq',
                  prompt: 'Why are total page views often considered a vanity metric if analyzed in isolation?',
                  options: [
                    'Because page views are too difficult to measure in analytics software',
                    'Because high page views do not guarantee engagement, conversions, or customer retention',
                    'Because Google Analytics does not record page views accurately',
                    'Because executive teams never care about website performance',
                  ],
                  correctAnswer: 1,
                  explanation:
                    'Page views do not tell you whether users derived value or took key actions like purchasing or registering.',
                },
              ],
            },
          },
        ],
      },
      {
        id: 'da-excel',
        title: 'Excel & Data Cleaning',
        shortDesc: 'Master data cleaning, logic formulas (IFS, VLOOKUP/XLOOKUP), and Pivot Tables.',
        category: 'core',
        prerequisites: ['da-foundation'],
        estimatedMinutes: 25,
        icon: 'Table',
        modules: [
          {
            id: 'da-excel-1',
            skillId: 'da-excel',
            title: 'Spreadsheet Formulas & Data Cleaning',
            estimatedMinutes: 20,
            goal: 'Clean messy string entries and apply lookup logic to reconcile disconnected sales files.',
            learnContent: {
              keyConcepts: [
                'Text functions: TRIM, UPPER, PROPER, TEXTBEFORE',
                'Handling NULL or mismatched IDs with XLOOKUP / IFERROR',
                'Validating data types before performing mathematical sums',
              ],
              explanation:
                'Real-world spreadsheets are messy: extra spaces, customer names in mixed case, and mismatched product codes. Cleaning data properly before running calculations prevents costly reporting errors.',
              workplaceContext:
                'Every month, finance sends raw sales logs from payment gateways while warehouse operations tracks fulfillment codes. Analysts join these two sources using XLOOKUP.',
            },
            example: {
              title: 'Resolving Discrepancies with XLOOKUP',
              description: 'Matching order IDs with regional shipping status:',
              codeSnippet: '=XLOOKUP(A2, Orders!A:A, Orders!E:E, "Unfulfilled", 0)',
              keyTakeaway: 'Always provide a default fallback (e.g. "Unfulfilled") to avoid unhandled #N/A cells.',
            },
            practice: {
              question: 'A customer entered "   Chennai  " with accidental leading spaces. Which formula cleans it?',
              options: ['=CLEAN(A2)', '=TRIM(A2)', '=REMOVE_SPACES(A2)', '=SUBSTITUTE(A2)'],
              correctIndex: 1,
              explanation: '=TRIM removes leading, trailing, and duplicate spaces from text strings.',
              hint: 'Standard spreadsheet formula for whitespace stripping.',
            },
            apply: {
              title: 'Customer Ledger Reconciliation',
              scenario:
                'Your manager found that 15% of customer records in the CRM have trailing spaces in the email column, causing lookup failures. Outline the two spreadsheet formulas you would use to clean and verify the email list.',
              starterQueryOrText: 'Step 1: =TRIM(LOWER(A2))...\nStep 2: Check length or duplicates...',
              modelSolution:
                'Step 1: Use =TRIM(LOWER(A2)) to normalize casing and eliminate whitespace. Step 2: Use =XLOOKUP(cleaned_email, CRM!A:A, CRM!B:B, "Not Found") with =COUNTIF to spot duplicate registrations.',
              rubricTip: 'Clean data is the prerequisite to all downstream reporting.',
            },
            assessment: {
              questions: [
                {
                  id: 'q-excel-1',
                  type: 'mcq',
                  prompt: 'Why is XLOOKUP generally preferred over traditional VLOOKUP in modern spreadsheets?',
                  options: [
                    'XLOOKUP requires no column index numbers, searches left or right, and handles defaults safely',
                    'VLOOKUP is no longer supported in any version of Microsoft Excel',
                    'XLOOKUP only works on numeric values',
                    'XLOOKUP automatically converts data into SQL databases',
                  ],
                  correctAnswer: 0,
                  explanation:
                    'XLOOKUP does not break when columns are rearranged, can look left, and has built-in error handling.',
                },
              ],
            },
          },
        ],
      },
      {
        id: 'da-sql',
        title: 'SQL for Business Analytics',
        shortDesc: 'Extract, filter, aggregate, and join relational tables to answer business questions.',
        category: 'core',
        prerequisites: ['da-excel'],
        estimatedMinutes: 30,
        icon: 'Database',
        modules: [
          {
            id: 'da-sql-1',
            skillId: 'da-sql',
            title: 'The WHERE Clause & Conditional Filtering',
            estimatedMinutes: 20,
            goal: 'Filter customer transactions accurately using multi-condition logic (AND, OR, IN, BETWEEN).',
            learnContent: {
              keyConcepts: [
                'Execution order: FROM -> WHERE -> SELECT',
                'Comparison operators (=, !=, >, <, BETWEEN, IN, LIKE)',
                'Case sensitivity and handling NULL values (IS NULL / IS NOT NULL)',
              ],
              explanation:
                'The WHERE clause filters rows BEFORE grouping or sorting takes place. Writing efficient filters reduces server load and ensures your metrics reflect only relevant records.',
              workplaceContext:
                'A retail company wants to launch a promotional loyalty campaign exclusively for customers residing in specific states whose historical purchase volume exceeds standard thresholds.',
            },
            example: {
              title: 'Targeting Regional High-Value Customers',
              description: 'Filter customers from Tamil Nadu who spent over $500 in 2025:',
              codeSnippet: `SELECT customer_id, full_name, state, total_spent
FROM customers
WHERE state = 'Tamil Nadu'
  AND total_spent > 500
ORDER BY total_spent DESC;`,
              keyTakeaway: 'String literals require single quotes, and numerical thresholds should not have dollar signs.',
            },
            practice: {
              question: 'Which query correctly finds orders placed between $100 and $500 that are shipped?',
              options: [
                "WHERE amount >= 100 AND amount <= 500 AND status = 'Shipped'",
                "WHERE amount IN (100, 500) AND status = 'Shipped'",
                "WHERE amount = 100 TO 500 AND status == 'Shipped'",
                "WHERE status = Shipped OR amount BETWEEN 100 AND 500",
              ],
              correctIndex: 0,
              explanation:
                'Both BETWEEN 100 AND 500 or amount >= 100 AND amount <= 500 with AND status = "Shipped" correctly enforce both criteria.',
              hint: 'Remember that SQL requires explicit logical conditions joined by AND.',
            },
            apply: {
              title: 'Regional Campaign Extraction Query',
              scenario:
                'A company wants to identify customers from Tamil Nadu who made purchases above $250 between June 1 and August 31, 2025. Author the appropriate SQL SELECT query.',
              starterQueryOrText: 'SELECT customer_id, name, order_total, order_date\nFROM orders\nWHERE ...',
              modelSolution: `SELECT customer_id, customer_name, order_total, state, order_date
FROM orders
WHERE state = 'Tamil Nadu'
  AND order_total > 250
  AND order_date BETWEEN '2025-06-01' AND '2025-08-31';`,
              rubricTip: 'Check for single quotes on strings/dates, correct operator for > 250, and date ranges.',
            },
            assessment: {
              questions: [
                {
                  id: 'q-sql-1',
                  type: 'mcq',
                  prompt: 'In SQL query processing order, when is the WHERE clause evaluated?',
                  options: [
                    'After the SELECT clause and after ORDER BY',
                    'Immediately after the FROM/JOIN clause and before GROUP BY',
                    'At the very end of query execution',
                    'Simultaneously with LIMIT',
                  ],
                  correctAnswer: 1,
                  explanation:
                    'SQL engines filter individual rows in WHERE right after loading tables (FROM), before aggregating (GROUP BY) or selecting columns.',
                },
                {
                  id: 'q-sql-2',
                  type: 'scenario',
                  prompt: 'A query with WHERE discount_code = NULL returned 0 rows even though 400 orders had no discount. What was the mistake?',
                  options: [
                    'Should use WHERE discount_code IS NULL because NULL cannot be compared with equality (=)',
                    'NULL values are always automatically converted to 0 in SQL',
                    'The table must be corrupted',
                    'Should use WHERE discount_code == "None"',
                  ],
                  correctAnswer: 0,
                  explanation: 'In SQL three-valued logic, comparison with = NULL evaluates to UNKNOWN. You must use IS NULL.',
                },
              ],
            },
          },
          {
            id: 'da-sql-2',
            skillId: 'da-sql',
            title: 'Relational JOINs & Aggregations',
            estimatedMinutes: 25,
            goal: 'Combine normalized transaction and customer tables to calculate customer lifetime value (LTV).',
            learnContent: {
              keyConcepts: [
                'INNER JOIN vs LEFT JOIN vs RIGHT JOIN',
                'Primary Keys and Foreign Keys',
                'GROUP BY with Aggregate functions (COUNT, SUM, AVG)',
                'Filtering aggregated results using HAVING',
              ],
              explanation:
                'Databases store data across multiple tables to eliminate redundancy. An analyst must join them together and summarize results to calculate metrics like revenue per customer or churn per region.',
              workplaceContext:
                'Product management needs to find users who registered in the last 6 months but have placed 0 orders, so the marketing team can send an onboarding discount.',
            },
            example: {
              title: 'Identifying Inactive Registered Users',
              description: 'Using LEFT JOIN to detect users with no matching orders:',
              codeSnippet: `SELECT u.user_id, u.email, u.created_at
FROM users u
LEFT JOIN orders o ON u.user_id = o.user_id
WHERE o.order_id IS NULL;`,
              keyTakeaway: 'A LEFT JOIN keeps all left rows; if right table columns are NULL, no transaction occurred.',
            },
            practice: {
              question: 'When should you use HAVING instead of WHERE?',
              options: [
                'Whenever you want the query to run faster',
                'To filter rows based on aggregate calculations like SUM() or COUNT()',
                'When searching for string columns only',
                'HAVING is just an alias for WHERE',
              ],
              correctIndex: 1,
              explanation:
                'WHERE filters raw individual records before grouping. HAVING filters grouped metric aggregates after GROUP BY.',
              hint: 'Think about when aggregate functions like COUNT() are computed.',
            },
            apply: {
              title: 'VIP Customer Retention Query',
              scenario:
                'The VP of Growth needs a list of all customers who placed more than 5 completed orders and generated over $1,000 in total spend. Write the query joining customers and orders.',
              starterQueryOrText: 'SELECT c.customer_id, c.name, COUNT(o.order_id) as total_orders, SUM(o.amount) as total_spend\nFROM customers c\nJOIN orders o ON c.customer_id = o.customer_id\n...',
              modelSolution: `SELECT c.customer_id, c.name,
       COUNT(o.order_id) AS total_orders,
       SUM(o.amount) AS total_spend
FROM customers c
INNER JOIN orders o ON c.customer_id = o.customer_id
WHERE o.status = 'Completed'
GROUP BY c.customer_id, c.name
HAVING COUNT(o.order_id) > 5 AND SUM(o.amount) > 1000
ORDER BY total_spend DESC;`,
              rubricTip: 'Ensure you grouped by customer attributes and put aggregate filters inside HAVING.',
            },
            assessment: {
              questions: [
                {
                  id: 'q-sql-3',
                  type: 'mcq',
                  prompt: 'What happens if you run an INNER JOIN between customers and orders?',
                  options: [
                    'All customers are returned, even those with no orders',
                    'Only customers who have at least one matching record in the orders table are returned',
                    'Every customer is matched with every order, creating a Cartesian product',
                    'The query will throw a syntax error unless WHERE is included',
                  ],
                  correctAnswer: 1,
                  explanation:
                    'INNER JOIN returns only rows where there is a match in both the left and right tables.',
                },
              ],
            },
          },
        ],
      },
      {
        id: 'da-stats',
        title: 'Statistical Thinking for Analysts',
        shortDesc: 'Calculate central tendencies, detect outliers, and avoid misleading correlations.',
        category: 'core',
        prerequisites: ['da-excel'],
        estimatedMinutes: 20,
        icon: 'Calculator',
        modules: [
          {
            id: 'da-stats-1',
            skillId: 'da-stats',
            title: 'Averages vs Medians & Handling Skew',
            estimatedMinutes: 20,
            goal: 'Choose appropriate statistical summaries for skewed business distributions like salary or order size.',
            learnContent: {
              keyConcepts: [
                'Mean vs Median vs Mode',
                'Skewed distributions and outlier impact',
                'Percentiles (p50, p90, p99) in latency and customer spend',
              ],
              explanation:
                'If an enterprise client signs a $2,000,000 contract while 99 consumers spend $20, the "average order value" will look high, but completely mislead business planning. Medians and percentiles tell the real story.',
              workplaceContext:
                'A fintech app calculates delivery response time. A few orders stuck in transit for 4 days artificially inflate the arithmetic mean, giving an inaccurate impression of typical user experience.',
            },
            example: {
              title: 'Outlier Distortion in Customer Support',
              description: 'Resolution times in minutes: [10, 12, 14, 15, 16, 18, 980]',
              sampleData: {
                headers: ['Metric', 'Value', 'Executive Interpretation'],
                rows: [
                  ['Mean', '152.1 minutes', 'Misleading: suggests support is terrible for everyone'],
                  ['Median', '15.0 minutes', 'Accurate: represents the typical customer experience'],
                  ['Outlier (980)', 'Escalated edge case', 'Should be investigated separately as a system bug'],
                ],
              },
              keyTakeaway: 'Always report both median and percentiles when distributions have extreme values.',
            },
            practice: {
              question: 'When reporting customer income for loan approval risk, why is median preferred over mean?',
              options: [
                'Median is easier to compute in SQL',
                'A few ultra-high-net-worth individuals skew the mean higher than what 90% of applicants earn',
                'Mean is only usable on categorical data',
                'Median guarantees 100% credit approval rates',
              ],
              correctIndex: 1,
              explanation:
                'Income is heavily right-skewed. The median reflects the true middle earner without distortion from extreme billionaires.',
              hint: 'Think about the impact of a billionaire entering an ordinary coffee shop.',
            },
            apply: {
              title: 'Delivery Times Audit',
              scenario:
                'Your operations lead says: "Our average customer wait time is 42 minutes, but half our reviews say they waited under 20 minutes." Explain in 2 sentences what is happening statistically and what metric you will provide.',
              starterQueryOrText: 'The distribution is right-skewed because...',
              modelSolution:
                'A small number of severe delivery delays (outliers) are pulling up the arithmetic mean. I will report the median (p50) for typical customer wait time alongside p90 to track how bad the worst-case delays are.',
              rubricTip: 'Highlight right-skewness and recommend median / percentiles.',
            },
            assessment: {
              questions: [
                {
                  id: 'q-stats-1',
                  type: 'mcq',
                  prompt: 'What is the definition of the 90th percentile (p90) in website load times?',
                  options: [
                    '90% of all page loads completed at or faster than this duration',
                    'The website crashed 90% of the time',
                    'The top 10% fastest users had this load time',
                    'The average speed multiplied by 0.90',
                  ],
                  correctAnswer: 0,
                  explanation:
                    'p90 means 90% of observation values fall below that threshold, giving a clear picture of user experience.',
                },
              ],
            },
          },
        ],
      },
      {
        id: 'da-python',
        title: 'Python for Data Wrangling',
        shortDesc: 'Automate repetitive workflows and clean datasets with Pandas and NumPy.',
        category: 'advanced',
        prerequisites: ['da-sql', 'da-stats'],
        estimatedMinutes: 25,
        icon: 'Code',
        modules: [
          {
            id: 'da-py-1',
            skillId: 'da-python',
            title: 'Pandas DataFrames & Aggregation',
            estimatedMinutes: 20,
            goal: 'Load CSV data, filter records, and generate summary statistics using Pandas.',
            learnContent: {
              keyConcepts: [
                'DataFrames and Series data structures',
                'Boolean indexing: df[df["category"] == "Tech"]',
                'Grouping and aggregation: df.groupby().agg()',
              ],
              explanation:
                'While SQL handles data inside databases, Python allows analysts to merge external APIs, automate daily email reports, and run advanced statistical models directly in memory.',
              workplaceContext:
                'Marketing downloads 50 different advertising CSV files every Monday. Writing a 10-line Python script cleans and merges them in 3 seconds.',
            },
            example: {
              title: 'Summarizing Revenue by Product Line',
              description: 'Pandas groupby example:',
              codeSnippet: `import pandas as pd

df = pd.read_csv('sales_data.csv')
summary = (df[df['status'] == 'Shipped']
           .groupby('category')['revenue']
           .agg(['count', 'sum', 'mean'])
           .reset_index())
print(summary)`,
              keyTakeaway: 'Chaining methods with clear parentheses makes data transformations readable and reproducible.',
            },
            practice: {
              question: 'Which Pandas command calculates missing values in every column of dataframe df?',
              options: [
                'df.isnull().sum()',
                'df.empty_values()',
                'df.find_nulls()',
                'df.count_missing()',
              ],
              correctIndex: 0,
              explanation:
                'df.isnull().sum() returns a boolean mask for null entries and sums True values per column.',
              hint: 'Combines a null check with a summation method.',
            },
            apply: {
              title: 'Customer Churn Analysis Task',
              scenario:
                'Write Python code using Pandas to filter a DataFrame df for active subscribers in the "Pro" tier whose monthly usage is below 10 hours, and sort by sign-up date.',
              starterQueryOrText: 'risk_users = df[...] ...',
              modelSolution: `risk_users = df[(df['tier'] == 'Pro') & (df['usage_hours'] < 10)]
risk_users = risk_users.sort_values(by='signup_date', ascending=False)`,
              rubricTip: 'Use single ampersand & with parentheses around each condition for element-wise boolean indexing.',
            },
            assessment: {
              questions: [
                {
                  id: 'q-py-1',
                  type: 'mcq',
                  prompt: 'Why do analysts prefer Pandas over manual spreadsheet copy-pasting for recurring weekly tasks?',
                  options: [
                    'Python code creates a repeatable, version-controlled pipeline that runs automatically without manual click errors',
                    'Python is owned by Microsoft and replaces Excel entirely',
                    'Spreadsheets cannot handle more than 50 rows of data',
                    'Python guarantees that numbers are never wrong',
                  ],
                  correctAnswer: 0,
                  explanation:
                    'Reproducibility and automation are key advantages of programmatic data analysis over manual manipulation.',
                },
              ],
            },
          },
        ],
      },
      {
        id: 'da-viz',
        title: 'Data Storytelling & Dashboards',
        shortDesc: 'Design high-impact visual representations and executive summaries that drive action.',
        category: 'integration',
        prerequisites: ['da-stats', 'da-excel'],
        estimatedMinutes: 20,
        icon: 'LineChart',
        modules: [
          {
            id: 'da-viz-1',
            skillId: 'da-viz',
            title: 'Chart Selection & Visual Hierarchy',
            estimatedMinutes: 20,
            goal: 'Select the optimal chart type to communicate trends, comparisons, and distributions without clutter.',
            learnContent: {
              keyConcepts: [
                'Line charts for continuous time series',
                'Bar charts for discrete categorical comparisons (avoid 3D charts)',
                'Scatter plots for correlation between two continuous variables',
                'Eliminating chart junk: gridlines, unnecessary legends, and misleading truncated axes',
              ],
              explanation:
                'A brilliant analysis is wasted if the stakeholder cannot comprehend the key takeaway within 5 seconds. Great analysts design with clarity, clear labels, and purposeful color contrast.',
              workplaceContext:
                'You are presenting Q3 sales results to the VP of Sales. A cluttered pie chart with 14 slices causes confusion, while a sorted horizontal bar chart highlights the top 3 lagging territories immediately.',
            },
            example: {
              title: 'Declining Product Sales Diagnosis',
              description: 'Here is a sales dataset showing 5 product categories over 6 months:',
              sampleData: {
                headers: ['Product Category', 'Q1 Sales ($)', 'Q2 Sales ($)', 'Delta %'],
                rows: [
                  ['Hardware Accessories', '$142,000', '$138,000', '-2.8%'],
                  ['Enterprise Cloud Subscriptions', '$310,000', '$385,000', '+24.2%'],
                  ['Legacy Desktop Software', '$89,000', '$41,000', '-53.9%'],
                  ['Consulting Support Hours', '$75,000', '$71,000', '-5.3%'],
                  ['Consumer Mobile Add-ons', '$94,000', '$96,000', '+2.1%'],
                ],
              },
              keyTakeaway: 'Sort comparisons descending by absolute change or magnitude rather than alphabetical order.',
            },
            practice: {
              question: 'Which chart type is most effective for displaying the trend of daily active users over a 12-month period?',
              options: [
                'Pie chart with 365 slices',
                'Line chart with clear monthly time intervals and labeled annotations',
                'Radar spider chart',
                'Stacked 3D cylinder chart',
              ],
              correctIndex: 1,
              explanation:
                'Line charts preserve continuous temporal sequence and allow viewers to effortlessly spot seasonal spikes or dips.',
              hint: 'Continuous time series data requires continuous visual axes.',
            },
            apply: {
              title: 'Executive Sales Decline Briefing',
              scenario:
                'Looking at the sample dataset above, identify the product category with the most severe decline and draft a 2-sentence executive summary advising leadership on the recommended next step.',
              starterQueryOrText: 'Legacy Desktop Software experienced a 53.9% drop...\nWe recommend...',
              modelSolution:
                'Legacy Desktop Software experienced a critical 53.9% revenue drop from $89K to $41K. We recommend auditing migration pathways to the thriving Enterprise Cloud product and winding down marketing spend on legacy versions.',
              rubricTip: 'Provide the exact metric drop and a forward-looking business recommendation.',
            },
            assessment: {
              questions: [
                {
                  id: 'q-viz-1',
                  type: 'mcq',
                  prompt: 'Why do data visualization standards recommend avoiding pie charts with more than 3-4 slices?',
                  options: [
                    'Human eyes are poor at judging small differences in angular area compared to bar lengths',
                    'Browsers cannot render circles efficiently',
                    'Pie charts are illegal under accessibility guidelines',
                    'Pie charts only work with negative numbers',
                  ],
                  correctAnswer: 0,
                  explanation:
                    'Visual perception science proves humans compare linear lengths on a common baseline far more accurately than slice angles.',
                },
              ],
            },
          },
        ],
      },
    ],
    projects: [
      {
        id: 'da-project-1',
        careerId: 'data-analyst',
        title: 'Sales Performance & Customer Retention Analysis',
        summary:
          'Conduct end-to-end data cleaning, SQL query extraction, and visual dashboard synthesis on a multi-million transaction retail dataset to solve customer churn.',
        skillsCovered: ['SQL', 'Excel / Pandas', 'Statistics', 'Data Storytelling', 'Business Recommendations'],
        difficulty: 'Standard',
        estimatedTime: '4–6 hours',
        sampleDataOrScenario:
          'You are hired by a fast-growing direct-to-consumer brand whose gross revenue looks healthy, but repeat order rates have declined from 42% to 28% over the past 9 months. You are given three relational tables: `customers`, `orders`, and `product_catalog`.',
        steps: [
          {
            title: '1. Data Inspection & Cleaning',
            description:
              'Verify order amounts, address duplicate customer entries, and flag orders with anomalous shipping durations or negative prices.',
            deliverable: 'Cleaned dataset summary and documented data hygiene rules.',
          },
          {
            title: '2. SQL Cohort Extraction',
            description:
              'Author SQL queries to group customer cohorts by their first purchase month and calculate monthly retention curves at 30, 60, and 90-day intervals.',
            deliverable: 'Reproducible SQL script with GROUP BY, LEFT JOIN, and DATE_TRUNC logic.',
          },
          {
            title: '3. Root Cause Investigation',
            description:
              'Cross-tabulate repeat order rates against product return rates, regional delivery delays, and customer review scores to isolate why users churn.',
            deliverable: 'Visual breakdown showing the primary correlation driving customer dissatisfaction.',
          },
          {
            title: '4. Executive Synthesis & Portfolio Artifact',
            description:
              'Compose a 1-page executive brief containing 3 clear, actionable operational recommendations for the COO.',
            deliverable: 'Executive memorandum with key visualizations ready for your portfolio.',
          },
        ],
        rubric: [
          'SQL queries are syntactically sound and handle NULL values properly',
          'Statistical summaries differentiate between average order values and medians',
          'Visualizations follow clean layout principles with no misleading axis truncation',
          'Recommendations are prioritized by business impact and operational feasibility',
        ],
      },
      {
        id: 'da-project-2',
        careerId: 'data-analyst',
        title: 'Regional Store Optimization & Inventory Forecaster',
        summary:
          'Analyze regional warehouse supply bottlenecks, product returns, and profit margins across 12 territories to optimize holiday inventory allocation.',
        skillsCovered: ['Excel Modeling', 'SQL Aggregations', 'Outlier Detection', 'Inventory KPIs'],
        difficulty: 'Advanced',
        estimatedTime: '6–8 hours',
        sampleDataOrScenario:
          'A nationwide electronics retailer is preparing for the Q4 peak shopping season. Certain regional warehouses suffer stockouts while others hold expensive surplus.',
        steps: [
          {
            title: '1. Inventory Turnover Calculation',
            description: 'Calculate days-sales-of-inventory (DSI) per region and category.',
            deliverable: 'Spreadsheet model with dynamic formulas.',
          },
          {
            title: '2. Bottleneck Detection Query',
            description: 'Write SQL queries identifying SKUs with >45 days of supply and negative margin trends.',
            deliverable: 'SQL extraction query with HAVING and window functions.',
          },
          {
            title: '3. Reallocation Strategy',
            description: 'Draft a re-balancing strategy to move excess stock to high-demand fulfillment centers.',
            deliverable: 'Strategic briefing deck slide with cost-benefit analysis.',
          },
        ],
        rubric: [
          'Accurate inventory turnover math',
          'Clear identification of high-risk SKUs',
          'Practical logistics recommendations considering freight costs',
        ],
      },
    ],
  },
  {
    id: 'web-developer',
    title: 'Web Developer',
    tagline: 'Engineer responsive, accessible, and fast web applications that people love to use.',
    category: 'Technology',
    icon: 'Code2',
    difficulty: 'Beginner Friendly',
    estimatedHours: '70–90 hours of active building',
    summary:
      'Web developers build the digital interfaces and server endpoints that power modern web applications. They focus on clean HTML/CSS architecture, JavaScript/TypeScript programming, API consumption, state management, and responsive design across devices.',
    responsibilities: [
      'Structuring accessible, semantic web layouts using modern HTML and Tailwind CSS',
      'Implementing dynamic user interactions, asynchronous data fetching, and state management',
      'Connecting frontends to RESTful and GraphQL backend endpoints safely',
      'Debugging cross-browser compatibility issues and mobile viewport anomalies',
      'Testing component functionality and optimizing client-side performance',
    ],
    prerequisites: [
      'Basic computer literacy and understanding of how websites work',
      'Problem-solving mindset and comfort with trial-and-error debugging',
      'No prior computer science degree required',
    ],
    coreSkills: [
      { name: 'HTML & Semantic Accessibility', proficiencyTarget: 90, description: 'ARIA, semantics, forms, screen-reader support' },
      { name: 'CSS & Modern Layouts', proficiencyTarget: 85, description: 'Flexbox, CSS Grid, Tailwind utilities, responsive breakpoints' },
      { name: 'JavaScript & TypeScript', proficiencyTarget: 80, description: 'Async/await, DOM manipulation, types, array methods' },
      { name: 'React & Component Architecture', proficiencyTarget: 80, description: 'Hooks, state management, props, lifecycle' },
      { name: 'API Integration & Networking', proficiencyTarget: 75, description: 'Fetch, REST endpoints, error handling, JSON schemas' },
      { name: 'Git & Version Control', proficiencyTarget: 70, description: 'Branches, commits, pull requests, merge conflict resolution' },
    ],
    assessmentOverview:
      'Hands-on coding challenges, bug-fixing simulations, interactive state audits, and deploying a functional full-stack project.',
    realWorldOutcome:
      'Publish functional web apps on your public portfolio demonstrating responsive design, clean modular TypeScript, and live API handling.',
    skillTree: [
      {
        id: 'web-found',
        title: 'Modern Web Foundations',
        shortDesc: 'Semantic HTML, accessibility standards, and responsive CSS architecture.',
        category: 'foundation',
        prerequisites: [],
        estimatedMinutes: 20,
        icon: 'Layout',
        modules: [
          {
            id: 'web-found-1',
            skillId: 'web-found',
            title: 'Semantic HTML & Accessibility (A11y)',
            estimatedMinutes: 15,
            goal: 'Build accessible web structures using correct semantic elements and ARIA roles.',
            learnContent: {
              keyConcepts: [
                'Semantic elements: <main>, <nav>, <header>, <article>, <section>',
                'Accessible forms: <label for="">, aria-describedby, visible focus rings',
                'Color contrast ratios (WCAG AA standard: minimum 4.5:1 for body text)',
              ],
              explanation:
                'Semantic HTML provides meaning to browsers, search engines, and screen readers. Using <div> for everything hurts SEO, breaks keyboard navigation, and creates inaccessible digital experiences.',
              workplaceContext:
                'Many corporate and government websites are legally required to meet WCAG AA accessibility standards. Developers who know accessibility build superior products for everyone.',
            },
            example: {
              title: 'Accessible Button vs Clickable Div',
              description: 'Why native <button> elements are essential:',
              codeSnippet: `<!-- BAD: Not keyboard accessible, no role -->
<div class="btn" onclick="submit()">Submit</div>

<!-- GOOD: Built-in Enter/Space activation, tab focus, screen-reader announced -->
<button type="submit" class="px-4 py-2 bg-blue-600 text-white rounded">Submit</button>`,
              keyTakeaway: 'Always use native HTML buttons and links to get keyboard navigation and screen-reader support for free.',
            },
            practice: {
              question: 'Which HTML element should be used for navigating between different pages of a web app?',
              options: [
                '<button onClick="...">',
                '<a href="...">',
                '<span class="link">',
                '<div data-route="...">',
              ],
              correctIndex: 1,
              explanation:
                'Anchor tags <a> with an href are semantic for changing location, enabling right-click "Open in New Tab" and search crawler indexing.',
              hint: 'Standard HTML element for page-to-page navigation.',
            },
            apply: {
              title: 'Fix an Inaccessible Login Form',
              scenario:
                'A junior developer built a login form using un-labeled inputs with placeholder text only. Write out the corrected HTML snippet for the Email input field that passes WCAG AA accessibility.',
              starterQueryOrText: '<div class="form-group">\n  <label for="email">...</label>\n...',
              modelSolution: `<div class="flex flex-col gap-1">
  <label for="user-email" class="text-sm font-medium text-gray-700">Email Address</label>
  <input
    id="user-email"
    type="email"
    name="email"
    required
    autocomplete="email"
    placeholder="name@company.com"
    class="border px-3 py-2 rounded focus:ring-2 focus:ring-blue-500"
  />
</div>`,
              rubricTip: 'Ensure label has a matching for="id" attribute and input has proper type="email".',
            },
            assessment: {
              questions: [
                {
                  id: 'q-web-1',
                  type: 'mcq',
                  prompt: 'Why is placeholder text insufficient as a replacement for a form label?',
                  options: [
                    'Placeholders disappear as soon as the user starts typing, eliminating context, and have low contrast',
                    'Placeholders are only supported on mobile devices',
                    'Browsers do not support placeholders in HTML5',
                    'Placeholders cause forms to submit automatically',
                  ],
                  correctAnswer: 0,
                  explanation:
                    'Placeholders vanish upon typing and typically fail WCAG contrast minimums, leading to errors.',
                },
              ],
            },
          },
        ],
      },
    ],
    projects: [
      {
        id: 'web-proj-1',
        careerId: 'web-developer',
        title: 'Interactive Collaborative Task Manager',
        summary:
          'Architect and code a responsive Kanban-style task management web application with local persistence, drag-and-drop mechanics, and keyboard accessibility.',
        skillsCovered: ['React', 'TypeScript', 'Tailwind CSS', 'State Management', 'Accessibility'],
        difficulty: 'Standard',
        estimatedTime: '6–8 hours',
        sampleDataOrScenario:
          'A distributed product team needs a lightweight, keyboard-accessible task board to track sprint items without the bloat of heavy enterprise software.',
        steps: [
          {
            title: '1. Component Hierarchy & State Design',
            description: 'Define TypeScript interfaces for tasks, columns, and users. Design modular component tree.',
            deliverable: 'Typed architecture outline.',
          },
          {
            title: '2. Responsive Board Layout',
            description: 'Build responsive columns using Tailwind CSS that collapse gracefully on mobile viewports.',
            deliverable: 'Fluid layout with mobile horizontal swipe or stack view.',
          },
          {
            title: '3. State Transitions & Persistence',
            description: 'Implement task creation, editing, status change, and localStorage persistence.',
            deliverable: 'Functional state engine with optimistic UI updates.',
          },
        ],
        rubric: [
          'No TypeScript compile warnings or `any` types',
          'Accessible keyboard navigation across all controls',
          'Responsive design tested across mobile and desktop breakpoints',
        ],
      },
    ],
  },
  {
    id: 'ui-ux-designer',
    title: 'UI/UX Designer',
    tagline: 'Design intuitive, human-centered digital experiences that solve real user friction.',
    category: 'Design',
    icon: 'Figma',
    difficulty: 'Beginner Friendly',
    estimatedHours: '50–70 hours of hands-on design',
    summary:
      'UI/UX designers bridge user psychology and digital products. They conduct user research, uncover friction points, structure intuitive information architectures, prototype interactive user flows, and construct scalable design systems.',
    responsibilities: [
      'Conducting user interviews and mapping customer journey pain points',
      'Creating low-fidelity wireframes to rapidly validate layout and user flow logic',
      'Designing cohesive visual design systems with consistent typography and spacing scales',
      'Building interactive Figma prototypes for stakeholder alignment and usability testing',
      'Collaborating closely with engineering teams to ensure design fidelity in production',
    ],
    prerequisites: [
      'Empathy for people struggling with confusing software interfaces',
      'Keen eye for visual balance, typography, and optical alignment',
      'Curiosity about why users abandon certain apps or sign-up flows',
    ],
    coreSkills: [
      { name: 'User Research & Journey Mapping', proficiencyTarget: 80, description: 'Interviews, personas, pain-point discovery' },
      { name: 'Information Architecture', proficiencyTarget: 85, description: 'Sitemaps, navigation hierarchies, content prioritization' },
      { name: 'Wireframing & Prototyping', proficiencyTarget: 85, description: 'Rapid wireframes, Figma components, interactive flows' },
      { name: 'Design Systems & Tokens', proficiencyTarget: 80, description: 'Colors, typography scales, spacing math, component variants' },
      { name: 'Usability Testing', proficiencyTarget: 75, description: 'Task completion rates, think-aloud protocols, heuristic evaluation' },
    ],
    assessmentOverview:
      'Design critique exercises, information architecture restructuring, usability heuristic audits, and publishing a comprehensive case study.',
    realWorldOutcome:
      'A design portfolio case study documenting problem discovery, user research, wireframes, design system tokens, and usability test results.',
    skillTree: [
      {
        id: 'ui-found',
        title: 'Human-Centered Design Fundamentals',
        shortDesc: 'Empathy mapping, visual hierarchy, and Nielsen Norman heuristics.',
        category: 'foundation',
        prerequisites: [],
        estimatedMinutes: 20,
        icon: 'Palette',
        modules: [
          {
            id: 'ui-found-1',
            skillId: 'ui-found',
            title: 'Visual Hierarchy & Negative Space',
            estimatedMinutes: 20,
            goal: 'Structure screen layouts so users instantly perceive the most important action without cognitive overload.',
            learnContent: {
              keyConcepts: [
                'F-pattern and Z-pattern reading behaviors',
                'Typographic contrast (size, weight, and line height)',
                'Whitespace as an active design tool to group related elements',
              ],
              explanation:
                'Visual hierarchy directs the user eye naturally. When every button is bright red or oversized, nothing stands out. Design restraint and deliberate contrast reduce user anxiety.',
              workplaceContext:
                'A mobile checkout screen suffered high drop-off because the "Apply Coupon" field had equal visual weight to the primary "Place Order" button.',
            },
            example: {
              title: 'Fixing Competing Call-to-Actions',
              description: 'Before vs After checkout hierarchy:',
              sampleData: {
                headers: ['Element', 'Bad Design', 'Engineered Hierarchy'],
                rows: [
                  ['Place Order Button', 'Blue 14px button', 'High-contrast Solid Primary 48px Touch Target'],
                  ['Cancel Order', 'Red 14px button (competing)', 'Subtle Text Link or Ghost Button'],
                  ['Security Badge', 'Bright blinking badge', 'Subtle grayscale lock icon with muted text'],
                ],
              },
              keyTakeaway: 'Only one primary button should compete for user attention per viewport state.',
            },
            practice: {
              question: 'What is the primary purpose of negative space (whitespace) in UI design?',
              options: [
                'To make web pages take longer to scroll',
                'To create breathing room and visually group related elements while reducing cognitive load',
                'To make up for a lack of visual assets',
                'To increase advertising impression space',
              ],
              correctIndex: 1,
              explanation:
                'Whitespace is active functional space that establishes proximity relationships and clarifies relationships between elements.',
              hint: 'Think about Gestalt principles of proximity.',
            },
            apply: {
              title: 'Heuristic Evaluation of a SaaS Pricing Card',
              scenario:
                'A B2B SaaS pricing page has three identical cards with no recommended tier, 12 bullet points each in tiny 11px gray text, and 3 identical "Buy" buttons. Propose 3 concrete UX improvements.',
              starterQueryOrText: '1. Highlight the most popular tier...\n2. Reduce bullet clutter...\n3....',
              modelSolution:
                '1. Visually elevate the most popular tier with a subtle accent border and "Recommended for Growth Teams" badge. 2. Truncate bullet points to the 4 critical differentiator features per tier with standard 16px legible body text. 3. Use primary solid button for recommended plan and outline buttons for others to establish visual hierarchy.',
              rubricTip: 'Focus on visual hierarchy, typography readability, and decision-making clarity.',
            },
            assessment: {
              questions: [
                {
                  id: 'q-ui-1',
                  type: 'mcq',
                  prompt: 'According to Fitts Law in UX, how can you make a crucial button easier for users to click or tap?',
                  options: [
                    'Make it larger and position it closer to the users expected cursor/thumb resting position',
                    'Hide it behind a hamburger dropdown menu',
                    'Make the text italicized and neon colored',
                    'Place it in the extreme top-left corner on mobile phones',
                  ],
                  correctAnswer: 0,
                  explanation:
                    'Fitts Law states that time to acquire a target is a function of the distance to and width of the target.',
                },
              ],
            },
          },
        ],
      },
    ],
    projects: [
      {
        id: 'ui-proj-1',
        careerId: 'ui-ux-designer',
        title: 'Fintech Onboarding Redesign Case Study',
        summary:
          'Audit and redesign an onboarding flow for a personal budgeting application to reduce user abandonment during bank account connection.',
        skillsCovered: ['User Research', 'Figma Prototyping', 'Design Systems', 'Usability Testing'],
        difficulty: 'Standard',
        estimatedTime: '6–8 hours',
        sampleDataOrScenario:
          'Users drop off at a 64% rate on Step 3 of account verification because they do not understand why sensitive credentials are required or how their data is encrypted.',
        steps: [
          {
            title: '1. Empathy & Friction Audit',
            description: 'Map user anxiety points and analyze competing fintech onboarding flows.',
            deliverable: 'Journey map identifying 3 core friction points.',
          },
          {
            title: '2. Low-Fidelity Wireframing',
            description: 'Sketch 3 alternate onboarding progressions with progressive disclosure.',
            deliverable: 'Low-fi wireframe flow showing permission explanations.',
          },
          {
            title: '3. Design System & High-Fi Prototype',
            description: 'Build reusable component tokens and a clickable Figma-ready prototype.',
            deliverable: 'Polished prototype with micro-interactions and clear copy.',
          },
        ],
        rubric: [
          'Demonstrates user-centered problem solving rather than purely aesthetic decorations',
          'Follows WCAG AA color contrast standards',
          'Clear rationale provided for every UI decision',
        ],
      },
    ],
  },
  {
    id: 'digital-marketer',
    title: 'Digital Marketing Strategist',
    tagline: 'Drive sustainable customer growth through targeted campaigns, content, and data analytics.',
    category: 'Marketing',
    icon: 'Megaphone',
    difficulty: 'Beginner Friendly',
    estimatedHours: '50–65 hours of practical campaign building',
    summary:
      'Digital marketers design, execute, and optimize multi-channel growth campaigns. They analyze customer acquisition costs (CAC), target ideal personas, write compelling copy, manage performance advertising channels, and conduct A/B tests to maximize return on investment.',
    responsibilities: [
      'Defining customer persona profiles, value propositions, and messaging matrices',
      'Planning and executing search engine optimization (SEO) and content strategies',
      'Configuring performance campaigns across Google Ads, Meta, and LinkedIn',
      'Analyzing marketing funnels: Impressions -> Clicks -> Leads -> Customers',
      'Running split tests on landing page headlines, calls-to-action, and email sequences',
    ],
    prerequisites: [
      'Strong written communication and storytelling skills',
      'Curiosity about why people buy products and services',
      'Basic comfort evaluating marketing numbers and return on ad spend (ROAS)',
    ],
    coreSkills: [
      { name: 'Target Audience Segmentation', proficiencyTarget: 85, description: 'Personas, psychographics, customer pain discovery' },
      { name: 'Content Marketing & SEO', proficiencyTarget: 80, description: 'Keyword research, search intent, content architecture' },
      { name: 'Paid Advertising (PPC)', proficiencyTarget: 75, description: 'Bidding strategies, ad creative testing, ROAS calculation' },
      { name: 'Email & Lifecycle Marketing', proficiencyTarget: 80, description: 'Drip sequences, segmentation, retention triggers' },
      { name: 'Marketing Analytics & Funnels', proficiencyTarget: 80, description: 'CAC, LTV, conversion rate optimization (CRO)' },
    ],
    assessmentOverview:
      'Campaign budget allocations, A/B test analysis scenarios, persona positioning briefs, and multi-channel launch projects.',
    realWorldOutcome:
      'Demonstrate a verified go-to-market campaign plan with documented keyword research, ad copy tests, and unit economics calculations.',
    skillTree: [
      {
        id: 'dm-found',
        title: 'Audience Targeting & Positioning',
        shortDesc: 'Understand search intent, customer personas, and value positioning.',
        category: 'foundation',
        prerequisites: [],
        estimatedMinutes: 20,
        icon: 'Target',
        modules: [
          {
            id: 'dm-found-1',
            skillId: 'dm-found',
            title: 'Customer Personas & Real-World Targeting',
            estimatedMinutes: 20,
            goal: 'Define a focused target audience and craft value propositions that resonate with specific customer pains.',
            learnContent: {
              keyConcepts: [
                'Target audience vs "everyone with an internet connection"',
                'Demographics vs Psychographics (pain points, triggers, objections)',
                'Jobs To Be Done (JTBD) framework in marketing',
              ],
              explanation:
                'When you market to everyone, you appeal to no one. Effective campaigns isolate the exact moment someone encounters an unbearable problem and present a specific, credible solution.',
              workplaceContext:
                'A sustainable apparel startup launches a line of water-resistant jackets. Targeting "all men aged 18-65" burns their modest $2,000 ad budget with 0 sales.',
            },
            example: {
              title: 'Broad Marketing vs Focused Persona',
              description: 'Apparel campaign targeting comparison:',
              sampleData: {
                headers: ['Dimension', 'Generic Campaign', 'High-Converting Focused Persona'],
                rows: [
                  ['Audience', 'All adults who like clothing', 'Urban bicycle commuters aged 24-38 in rainy metro areas'],
                  ['Core Pain', 'Need a jacket', 'Arriving at morning office meetings with soaked shirts and ruined laptop bags'],
                  ['Hook', 'Best jackets online', 'Engineered for rainy morning commutes: 100% dry, breathable in boardrooms'],
                ],
              },
              keyTakeaway: 'The specific hook solves an immediate everyday frustration.',
            },
            practice: {
              question: 'Why does defining a tight customer persona improve paid advertising efficiency?',
              options: [
                'Because it guarantees ads will be shown 100% free of charge',
                'It prevents wasting ad spend on uninterested clicks and enables messaging tailored to specific buying triggers',
                'Because search engines block ads that target broad categories',
                'It allows you to bypass all advertising regulations',
              ],
              correctIndex: 1,
              explanation:
                'Focused targeting increases relevance score, lowers cost-per-click (CPC), and elevates conversion rates.',
              hint: 'Think about where ad budget gets wasted.',
            },
            apply: {
              title: 'Apparel Campaign Audience Definition',
              scenario:
                'You work for a small direct-to-consumer clothing company launching a new moisture-wicking business shirt. Which audience would you target first and why? Outline 2 specific customer triggers.',
              starterQueryOrText: 'Target Audience: Business professionals who...\nTrigger 1: ...\nTrigger 2: ...',
              modelSolution:
                'Target Audience: Hybrid office professionals who walk, bike, or take public transit to work in warm humid regions. Trigger 1: Arriving at in-person client presentations with visible sweat stains. Trigger 2: Frustration with traditional stiff cotton shirts that wrinkle after 2 hours of sitting.',
              rubricTip: 'Connect the specific product feature to emotional and practical workplace stakes.',
            },
            assessment: {
              questions: [
                {
                  id: 'q-dm-1',
                  type: 'mcq',
                  prompt: 'What does Cost Per Acquisition (CPA) measure in digital marketing?',
                  options: [
                    'The total cost spent on ads divided by the number of customers acquired through those ads',
                    'The retail price of the physical product on the shelf',
                    'The salary paid to the marketing agency',
                    'The amount of money left over in the bank at month-end',
                  ],
                  correctAnswer: 0,
                  explanation:
                    'CPA (or CAC) is total marketing spend divided by new customers acquired, defining unit profitability.',
                },
              ],
            },
          },
        ],
      },
    ],
    projects: [
      {
        id: 'dm-proj-1',
        careerId: 'digital-marketer',
        title: 'B2B SaaS Go-To-Market & Growth Campaign',
        summary:
          'Plan an end-to-end customer acquisition strategy for a team collaboration software startup with a $5,000 monthly ad budget.',
        skillsCovered: ['Persona Design', 'SEO Keyword Strategy', 'Google Ads Plan', 'Email Funnel Design', 'CAC Modeling'],
        difficulty: 'Standard',
        estimatedTime: '5–7 hours',
        sampleDataOrScenario:
          'The founder developed an automated invoice processing tool for freelance design agencies. You need to generate the first 50 paying customers.',
        steps: [
          {
            title: '1. Customer Persona & Positioning Document',
            description: 'Map out 2 core buyer personas, their chief objections, and competitive differentiators.',
            deliverable: 'Positioning matrix.',
          },
          {
            title: '2. High-Intent Keyword Map',
            description: 'Identify 15 commercial-intent search keywords with estimated CPCs and search volumes.',
            deliverable: 'Keyword spreadsheet with negative keyword list.',
          },
          {
            title: '3. 3-Part Email Onboarding Sequence',
            description: 'Draft the automated welcome email, social proof case study, and trial conversion trigger.',
            deliverable: 'Email copy ready for deployment in email marketing platforms.',
          },
        ],
        rubric: [
          'Demonstrates realistic CAC and conversion benchmarks',
          'Avoids generic copy clichés, focusing on concrete buyer pains',
          'Includes clear tracking metrics and KPIs for each campaign stage',
        ],
      },
    ],
  },
  {
    id: 'business-analyst',
    title: 'Business Systems Analyst',
    tagline: 'Bridge business objectives and technology solutions through structured requirements and process modeling.',
    category: 'Business',
    icon: 'Briefcase',
    difficulty: 'Beginner Friendly',
    estimatedHours: '55–70 hours of applied case studies',
    summary:
      'Business analysts evaluate operational bottlenecks, elicit requirements from diverse business stakeholders, draft unambiguous specifications for engineering teams, model workflow diagrams, and facilitate change management.',
    responsibilities: [
      'Facilitating stakeholder discovery sessions to document current vs future state workflows',
      'Translating ambiguous business demands into structured user stories with acceptance criteria',
      'Creating BPMN (Business Process Model and Notation) swimlane flowcharts',
      'Conducting gap analysis and feasibility studies for prospective software tools',
      'Validating that engineering deliveries meet original business intent during UAT',
    ],
    prerequisites: [
      'Exceptional listening and structured questioning skills',
      'Ability to organize disorganized information logically',
      'Interest in understanding how modern enterprises operate',
    ],
    coreSkills: [
      { name: 'Requirements Elicitation', proficiencyTarget: 85, description: 'Interviews, workshops, user story mapping' },
      { name: 'Process Flow Modeling', proficiencyTarget: 80, description: 'BPMN 2.0, swimlane diagrams, state transitions' },
      { name: 'Agile User Stories & Acceptance Criteria', proficiencyTarget: 85, description: 'Given-When-Then, INVEST criteria' },
      { name: 'Stakeholder Management', proficiencyTarget: 80, description: 'Conflict resolution, executive presentations, change management' },
      { name: 'Data-Driven Feasibility Analysis', proficiencyTarget: 70, description: 'Cost-benefit analysis, gap analysis' },
    ],
    assessmentOverview:
      'Requirements gap analysis exercises, process flow debugging, writing robust acceptance criteria, and presenting a business case.',
    realWorldOutcome:
      'Complete a professional Business Requirements Document (BRD) and process workflow specification ready for technical architecture review.',
    skillTree: [
      {
        id: 'ba-found',
        title: 'Requirements Engineering & User Stories',
        shortDesc: 'Master the art of writing precise, testable user stories and acceptance criteria.',
        category: 'foundation',
        prerequisites: [],
        estimatedMinutes: 20,
        icon: 'FileText',
        modules: [
          {
            id: 'ba-found-1',
            skillId: 'ba-found',
            title: 'User Stories & Given-When-Then Acceptance Criteria',
            estimatedMinutes: 20,
            goal: 'Transform vague requests into unambiguous, developer-ready user stories with testable criteria.',
            learnContent: {
              keyConcepts: [
                'The standard user story format: As a [role], I want [action], So that [business benefit]',
                'The INVEST criteria (Independent, Negotiable, Valuable, Estimable, Small, Testable)',
                'Gherkin syntax: Given [precondition], When [action triggered], Then [expected outcome]',
              ],
              explanation:
                'Ambiguous requirements cause over 60% of software project failures. Writing precise user stories ensures engineers, QA testers, and business sponsors share the exact same definition of done.',
              workplaceContext:
                'A sales director says: "I need the CRM to automatically notify reps when big deals come in." A business analyst must define what "big" means, what "notify" means, and edge cases.',
            },
            example: {
              title: 'De-risking an Ambiguous Requirement',
              description: 'Vague vs Production-Ready requirement:',
              codeSnippet: `// BAD: "Make search faster and better"

// GOOD:
As an inventory clerk,
I want to search warehouse stock by barcode or SKU name,
So that I can locate replacement parts during customer calls.

Acceptance Criteria:
Scenario 1: Exact SKU match found
  Given the warehouse inventory database is online
  When the clerk enters an 8-character SKU "SKU-9921"
  Then the system displays the shelf location within 500ms.

Scenario 2: Out of stock SKU entered
  Given the SKU exists with quantity 0
  When searched
  Then display "Out of Stock - Next Shipment [Date]" with a backorder button.`,
              keyTakeaway: 'Scenarios must cover both the happy path and critical edge cases.',
            },
            practice: {
              question: 'What is the primary danger of writing a user story without acceptance criteria?',
              options: [
                'The user story cannot be saved in Jira',
                'Developers and QA have to guess what behavior is expected, leading to bugs, rework, and missed deadlines',
                'The story will automatically execute in production',
                'Stakeholders will not be allowed to attend sprint demos',
              ],
              correctIndex: 1,
              explanation:
                'Without clear acceptance criteria, teams disagree on when the feature is complete and test cases cannot be verified objectively.',
              hint: 'Think about how QA engineers verify software.',
            },
            apply: {
              title: 'Delayed Project Status Response',
              scenario:
                'Your engineering manager notifies you that the payment gateway integration will be delayed by 2 weeks due to third-party API rate limits. Draft a professional, solution-oriented 3-sentence update email to your project sponsor.',
              starterQueryOrText: 'Hi Sponsor,\nI am writing to provide an update regarding our payment integration...',
              modelSolution:
                'Hi Team, During testing we identified third-party API rate constraints on the payment integration that require an additional 2 weeks of engineering to implement reliable queuing. To protect our launch milestone, we have reprioritized frontend reporting tasks to continue on schedule while the vendor resolves our tier limits. We will review the revised testing timeline in Thursday’s standup.',
              rubricTip: 'Acknowledge reality directly, explain the root cause, and offer an immediate mitigation plan.',
            },
            assessment: {
              questions: [
                {
                  id: 'q-ba-1',
                  type: 'mcq',
                  prompt: 'In the INVEST acronym for user stories, what does the "T" stand for?',
                  options: ['Testable', 'Technical', 'Theoretical', 'Temporary'],
                  correctAnswer: 0,
                  explanation:
                    'A user story must be Testable so QA and stakeholders can definitively confirm whether it functions as expected.',
                },
              ],
            },
          },
        ],
      },
    ],
    projects: [
      {
        id: 'ba-proj-1',
        careerId: 'business-analyst',
        title: 'Customer Onboarding Workflow Optimization',
        summary:
          'Conduct a business process re-engineering analysis for a commercial bank whose loan approvals take 14 days on average.',
        skillsCovered: ['BPMN Flowcharts', 'Root Cause Analysis', 'User Stories', 'Cost-Benefit Analysis'],
        difficulty: 'Standard',
        estimatedTime: '5–7 hours',
        sampleDataOrScenario:
          'Commercial loan applicants report repetitive manual paperwork, lost PDF attachments, and lack of status tracking. The bank risks losing 35% of applicants to modern fintech competitors.',
        steps: [
          {
            title: '1. As-Is vs To-Be Process Map',
            description: 'Diagram current multi-department handoffs and specify streamlined automated routing.',
            deliverable: 'BPMN swimlane flowchart.',
          },
          {
            title: '2. Functional Requirements Specification',
            description: 'Author 6 detailed user stories with Given-When-Then acceptance criteria for the new portal.',
            deliverable: 'Requirements backlog specification.',
          },
        ],
        rubric: [
          'Accurately identifies process bottlenecks causing the 14-day delay',
          'User stories adhere strictly to INVEST principles',
          'Feasible implementation plan presented with risk mitigation',
        ],
      },
    ],
  },
  {
    id: 'cybersecurity-analyst',
    title: 'Cybersecurity Analyst',
    tagline: 'Defend systems, monitor security operations, and mitigate vulnerabilities before breaches occur.',
    category: 'Security',
    icon: 'ShieldCheck',
    difficulty: 'Intermediate',
    estimatedHours: '65–85 hours of security labs',
    summary:
      'Cybersecurity analysts monitor organizational infrastructure, analyze telemetry alerts, investigate security anomalies, identify network vulnerabilities, enforce access controls, and coordinate incident response protocols.',
    responsibilities: [
      'Triaging security alerts and telemetry logs inside SIEM platforms',
      'Conducting vulnerability scans and prioritizing remediation based on CVSS scores',
      'Analyzing phishing emails, malware attachments, and unauthorized access attempts',
      'Enforcing multi-factor authentication and Principle of Least Privilege across identity systems',
      'Documenting security incident response playbooks and post-mortem reports',
    ],
    prerequisites: [
      'Basic understanding of operating systems (Linux/Windows) and networking (IP, TCP/UDP, DNS)',
      'High attention to detail and calm methodical problem-solving under pressure',
    ],
    coreSkills: [
      { name: 'Networking & Protocols', proficiencyTarget: 85, description: 'TCP/IP, DNS, TLS/SSL, firewalls, ports' },
      { name: 'SIEM & Log Analysis', proficiencyTarget: 80, description: 'Splunk, Elastic, alert triage, correlation rules' },
      { name: 'Threat Hunting & CVE Assessment', proficiencyTarget: 75, description: 'CVSS scores, MITRE ATT&CK framework' },
      { name: 'Identity & Access Management', proficiencyTarget: 80, description: 'Least privilege, RBAC, MFA, zero trust' },
      { name: 'Incident Response', proficiencyTarget: 75, description: 'Containment, eradication, recovery, post-mortems' },
    ],
    assessmentOverview:
      'Network log forensic scenarios, threat triage simulations, vulnerability prioritization rubrics, and incident containment case studies.',
    realWorldOutcome:
      'Demonstrate a verified incident response report analyzing attack telemetry, containment steps, and hardened firewall configurations.',
    skillTree: [
      {
        id: 'sec-found',
        title: 'Security Operations & Telemetry',
        shortDesc: 'Understand threat landscapes, network ports, and alert triage frameworks.',
        category: 'foundation',
        prerequisites: [],
        estimatedMinutes: 25,
        icon: 'Lock',
        modules: [
          {
            id: 'sec-found-1',
            skillId: 'sec-found',
            title: 'Triaging Suspicious Authentication Alerts',
            estimatedMinutes: 20,
            goal: 'Investigate anomalous sign-in logs to differentiate between legitimate user travel and credential stuffing.',
            learnContent: {
              keyConcepts: [
                'Impossible travel alerts (e.g. login from London 10 minutes after login from Tokyo)',
                'User-Agent and IP reputation checks (Tor exit nodes, residential proxies)',
                'Principle of Least Privilege and immediate account containment',
              ],
              explanation:
                'Security analysts do not panic; they follow verified triage procedures. Checking timestamp deltas, IP geolocations, and MFA prompt responses determines whether an alert is a benign VPN or a compromised credential.',
              workplaceContext:
                'At 2:15 AM on a Saturday, an alert flags an executive account attempting 40 SSH logins from an unknown subnet.',
            },
            example: {
              title: 'Anatomy of an Impossible Travel Log',
              description: 'Authentication record snippet:',
              sampleData: {
                headers: ['Timestamp (UTC)', 'User', 'IP Address', 'Country', 'Auth Method', 'Result'],
                rows: [
                  ['14:02:11', 'cfo@company.com', '194.26.29.1', 'France', 'Password + Push MFA', 'Success'],
                  ['14:14:48', 'cfo@company.com', '45.154.255.8', 'Russia', 'Password Only', 'Failed (No MFA)'],
                  ['14:15:02', 'cfo@company.com', '45.154.255.8', 'Russia', 'Session Cookie Replay', 'Suspicious Success'],
                ],
              },
              keyTakeaway: 'The session cookie replay indicates token theft; immediately revoke active sessions.',
            },
            practice: {
              question: 'When investigating a suspected compromised user account, what is the FIRST containment step?',
              options: [
                'Send an angry email to the user',
                'Immediately terminate all active sessions, revoke tokens, and reset credentials',
                'Delete the user account from the Active Directory permanently',
                'Wait until Monday morning to notify the user',
              ],
              correctIndex: 1,
              explanation:
                'Revoking active session tokens and resetting credentials halts ongoing attacker activity without destroying audit log history.',
              hint: 'Think about stopping active attacker access immediately.',
            },
            apply: {
              title: 'Phishing Incident Response Triage',
              scenario:
                'An employee reports clicking an urgent email link titled "Urgent Payroll Review" and entering their corporate credentials on an external site. Outline your immediate 3-step containment action plan.',
              starterQueryOrText: 'Step 1: Revoke active session tokens...\nStep 2: ...\nStep 3: ...',
              modelSolution:
                '1. Immediately revoke active session tokens, invalidate cookies, and force an out-of-band password reset. 2. Inspect mail server logs to identify all other employees who received the malicious email, quarantine the message, and block the attacker domain on firewall/DNS. 3. Check endpoint EDR logs on the employees laptop for suspicious child processes or malware drops.',
              rubricTip: 'Covers user account containment, enterprise-wide blast radius search, and endpoint verification.',
            },
            assessment: {
              questions: [
                {
                  id: 'q-sec-1',
                  type: 'mcq',
                  prompt: 'What is the Principle of Least Privilege in enterprise security?',
                  options: [
                    'Users and services are granted only the minimum access rights necessary to perform their required job functions',
                    'Every employee receives full administrator rights so they are not blocked',
                    'Only the CEO is allowed to log into computers',
                    'Passwords must have fewer than 6 characters',
                  ],
                  correctAnswer: 0,
                  explanation:
                    'Least privilege limits damage if any single account or service is compromised.',
                },
              ],
            },
          },
        ],
      },
    ],
    projects: [
      {
        id: 'sec-proj-1',
        careerId: 'cybersecurity-analyst',
        title: 'SOC Incident Investigation & Post-Mortem',
        summary:
          'Analyze an end-to-end simulated ransomware intrusion across network logs, write an incident timeline, and draft security hardening recommendations.',
        skillsCovered: ['Log Analysis', 'Incident Containment', 'MITRE ATT&CK', 'Post-Mortem Documentation'],
        difficulty: 'Standard',
        estimatedTime: '6–8 hours',
        sampleDataOrScenario:
          'A hospital network alert detected abnormal outbound encrypted traffic from an internal workstation to a known command-and-control server at 3:00 AM.',
        steps: [
          {
            title: '1. Forensic Timeline Construction',
            description: 'Analyze firewall and DNS logs to pinpoint initial entry vector and lateral movement.',
            deliverable: 'Chronological intrusion timeline.',
          },
          {
            title: '2. Blast Radius Assessment',
            description: 'Determine which internal IP subnets and databases were reached by the attacker IP.',
            deliverable: 'Network topology impact diagram.',
          },
          {
            title: '3. Security Hardening Brief',
            description: 'Provide 4 actionable remediation items to prevent identical ingress paths.',
            deliverable: 'Executive post-mortem report.',
          },
        ],
        rubric: [
          'Accurately identifies the initial access vector from logs',
          'Follows standard incident response phases (Preparation, Detection, Containment, Eradication, Recovery)',
          'Clear, actionable defense-in-depth recommendations',
        ],
      },
    ],
  },
];
