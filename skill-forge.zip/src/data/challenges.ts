import { DailyChallenge } from '../types';

export const DAILY_CHALLENGES: DailyChallenge[] = [
  {
    id: 'ch-data-1',
    title: "Today's Practical Challenge: Detect the Sales Anomaly",
    careerCategory: 'Data & AI',
    skill: 'Data Interpretation',
    taskType: 'analysis',
    xpReward: 60,
    sampleContext: `A national retail chain has 4 regions. Here are last month's performance numbers:
- North Region: 1,420 orders, $142,000 revenue, return rate: 3.1%
- South Region: 1,980 orders, $194,000 revenue, return rate: 2.8%
- East Region: 820 orders, $81,000 revenue, return rate: 3.4%
- West Region: 2,100 orders, $94,000 revenue, return rate: 18.9%`,
    prompt:
      'Identify which region shows a critical operational anomaly, compute its average order value versus the other regions, and state the most likely business root cause to investigate.',
    starterInput:
      'The critical anomaly is in the West Region because...\nAverage order value in West is $...\nPotential root cause to investigate is...',
    solutionGuide:
      'West Region has an average order value of only ~$44.76 (compared to ~$100 in others) and an alarming 18.9% return rate (6x higher than average). This indicates either heavy discounted clearance items with defective merchandise, or a localized shipping/fulfillment problem causing damaged goods.',
  },
  {
    id: 'ch-sql-1',
    title: 'Workplace SQL: High-Spenders in Tamil Nadu',
    careerCategory: 'Data & AI',
    skill: 'SQL Querying',
    taskType: 'code',
    xpReward: 50,
    sampleContext: `Table: customers (customer_id, full_name, state, total_spent_usd, created_year)
Table: transactions (txn_id, customer_id, txn_date, amount, status)`,
    prompt:
      'A regional campaign manager wants to send exclusive festival invitations. Write a SQL query returning the full name, state, and total spent for all customers located in "Tamil Nadu" whose total_spent_usd is greater than $300, sorted descending by total spent.',
    starterInput: `SELECT full_name, state, total_spent_usd
FROM customers
WHERE ...`,
    solutionGuide: `SELECT full_name, state, total_spent_usd
FROM customers
WHERE state = 'Tamil Nadu'
  AND total_spent_usd > 300
ORDER BY total_spent_usd DESC;`,
  },
  {
    id: 'ch-comm-1',
    title: 'Workplace Communication: Delayed Delivery Escalation',
    careerCategory: 'Management',
    skill: 'Stakeholder Communication',
    taskType: 'writing',
    xpReward: 55,
    sampleContext: `You are leading an internal analytics dashboard rollout. The database migration team encountered corrupted legacy schemas, pushing your promised Friday demo back by 5 days. Your VP of Operations is expecting to see it Friday.`,
    prompt:
      'Draft a professional, solution-oriented 3-sentence update email to your VP of Operations. Acknowledge the delay directly without blaming others, state what is being done, and provide the exact revised delivery time.',
    starterInput: `Hi [VP Name],\nI am writing to share an update on the dashboard launch...`,
    solutionGuide:
      'Dear Sarah, During our pre-launch validation we identified legacy schema discrepancies that require 5 additional days of data sanitization to ensure absolute reporting accuracy. To maintain project velocity, we have staged frontend mockups for your team to test this Thursday while the data pipeline completes next Tuesday. We will hold our live demo next Wednesday at 10 AM.',
  },
  {
    id: 'ch-ux-1',
    title: 'UX Heuristic Audit: The Confusing Mobile Checkout',
    careerCategory: 'Design',
    skill: 'Information Architecture',
    taskType: 'decision',
    xpReward: 45,
    sampleContext: `A grocery delivery app has a mobile checkout screen with:
1. A bright red "Clear All Items" button directly next to "Confirm Order" (both 14px text)
2. 8 separate checkboxes asking if the user accepts promotional newsletters, marketing SMS, partner emails, and cookie types
3. Delivery address displayed as plain un-editable text with no edit pencil icon`,
    prompt:
      'List the 3 specific UX violations in this checkout screen and specify how you would redesign each element to prevent accidental order abandonment.',
    starterInput:
      '1. Violation: Competing destructive action...\nFix: ...\n2. Violation: ...\nFix: ...\n3. Violation: ...\nFix: ...',
    solutionGuide:
      '1. Separate destructive "Clear All Items" from primary "Confirm Order", demoting it to a secondary text link with confirmation modal. 2. Collapse marketing consents into a single opt-in toggle with progressive disclosure. 3. Make the delivery address a clear card with a prominent "Edit" button to give users control before payment.',
  },
];
