import React, { useState } from 'react';
import {
  X,
  Target,
  Sparkles,
  CheckCircle2,
  Lightbulb,
  Bot,
  ArrowRight,
  Code,
  FileText,
} from 'lucide-react';
import { DailyChallenge } from '../types';

interface ChallengeSolverModalProps {
  challenge: DailyChallenge;
  onClose: () => void;
  onComplete: (xp: number) => void;
  onOpenAIWithPrompt: (prompt: string) => void;
}

export const ChallengeSolverModal: React.FC<ChallengeSolverModalProps> = ({
  challenge,
  onClose,
  onComplete,
  onOpenAIWithPrompt,
}) => {
  const [userInput, setUserInput] = useState(challenge.starterInput);
  const [submitted, setSubmitted] = useState(false);
  const [showSolution, setShowSolution] = useState(false);

  const handleSubmit = () => {
    setSubmitted(true);
    setShowSolution(true);
    onComplete(challenge.xpReward);
  };

  return (
    <div
      id="challenge-solver-modal"
      className="fixed inset-0 z-50 bg-slate-900/70 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto"
    >
      <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 max-w-2xl w-full max-h-[92vh] overflow-y-auto shadow-2xl p-6 sm:p-8 space-y-6">
        <div className="flex items-start justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-xs font-bold uppercase tracking-wider text-orange-600 dark:text-orange-400">
                Workplace Simulation Challenge
              </span>
              <span className="text-xs font-bold text-amber-600 dark:text-amber-400">
                +{challenge.xpReward} XP
              </span>
            </div>
            <h3 className="text-xl font-black text-slate-900 dark:text-white">
              {challenge.title}
            </h3>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Workplace Context */}
        <div className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-850 font-mono text-xs text-slate-800 dark:text-slate-200 whitespace-pre-wrap leading-relaxed">
          {challenge.sampleContext}
        </div>

        {/* Prompt */}
        <div className="space-y-1">
          <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
            Workplace Assignment
          </h4>
          <p className="text-xs sm:text-sm text-slate-800 dark:text-slate-200 font-medium leading-relaxed">
            {challenge.prompt}
          </p>
        </div>

        {/* Workspace Input */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
            <span className="font-semibold">Your Practical Response:</span>
            <button
              onClick={() =>
                onOpenAIWithPrompt(
                  `I am working on this practical workplace challenge: "${challenge.prompt}". Context: "${challenge.sampleContext}". Can you give me a subtle hint on how to think about this?`
                )
              }
              className="inline-flex items-center gap-1 text-indigo-600 dark:text-indigo-400 font-bold hover:underline"
            >
              <Bot className="w-3.5 h-3.5" />
              <span>Ask Forge AI for a Hint</span>
            </button>
          </div>

          <textarea
            id="challenge-input-textarea"
            rows={6}
            value={userInput}
            onChange={(e) => setUserInput(e.target.value)}
            disabled={submitted}
            className="w-full p-4 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 font-mono text-xs text-slate-900 dark:text-slate-100 focus:ring-2 focus:ring-orange-500 focus:outline-none"
          />
        </div>

        {/* Solution Guide (if submitted or revealed) */}
        {showSolution && (
          <div className="p-5 rounded-2xl border border-emerald-200 dark:border-emerald-900/60 bg-emerald-50/40 dark:bg-emerald-950/30 space-y-2">
            <div className="flex items-center gap-2 text-xs font-bold text-emerald-800 dark:text-emerald-300 uppercase tracking-wider">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <span>Model Solution & Business Impact</span>
            </div>
            <div className="text-xs text-slate-800 dark:text-slate-200 font-mono whitespace-pre-wrap leading-relaxed">
              {challenge.solutionGuide}
            </div>
          </div>
        )}

        {/* Footer Actions */}
        <div className="flex items-center justify-between pt-3 border-t border-slate-100 dark:border-slate-800">
          {!submitted ? (
            <>
              <button
                type="button"
                onClick={() => setShowSolution(!showSolution)}
                className="text-xs text-slate-500 hover:text-slate-900 dark:hover:text-slate-300 underline"
              >
                {showSolution ? 'Hide Solution' : 'Peek Reference Solution'}
              </button>

              <button
                id="submit-challenge-btn"
                onClick={handleSubmit}
                className="inline-flex items-center gap-2 px-6 py-2.5 rounded-xl bg-orange-600 hover:bg-orange-700 text-white text-xs font-bold transition-colors shadow-sm"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>Submit & Earn +{challenge.xpReward} XP</span>
              </button>
            </>
          ) : (
            <div className="w-full flex items-center justify-between">
              <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400 flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4" /> Challenge Completed! +{challenge.xpReward} XP added.
              </span>
              <button
                onClick={onClose}
                className="px-5 py-2 rounded-xl bg-slate-900 dark:bg-white text-white dark:text-slate-900 text-xs font-bold"
              >
                Close
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
