import React from 'react';
import {
  Award,
  Flame,
  Sparkles,
  CheckCircle2,
  ExternalLink,
  ShieldAlert,
  FolderGit2,
  GitFork,
  Compass,
  RotateCcw,
  Target,
} from 'lucide-react';
import { UserProfile } from '../types';
import { getCareerById } from '../data/allCareers';
import { DynamicIcon } from './Icon';

interface ProfileViewProps {
  profile: UserProfile;
  setCurrentTab: (tab: string) => void;
  onResetProgress: () => void;
}

export const ProfileView: React.FC<ProfileViewProps> = ({
  profile,
  setCurrentTab,
  onResetProgress,
}) => {
  const career = getCareerById(profile.selectedCareerId);

  // Overall path percentage
  const allModules = career.skillTree.flatMap((s) => s.modules);
  const totalCount = allModules.length || 1;
  const completedCount = allModules.filter((m) =>
    profile.completedModuleIds.includes(m.id)
  ).length;
  const pathPct = Math.round((completedCount / totalCount) * 100);

  return (
    <div id="profile-view" className="space-y-8 pb-16">
      {/* Profile Header */}
      <div className="rounded-3xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-850 p-6 sm:p-8 shadow-sm">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-6">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-indigo-500 via-purple-500 to-pink-500 text-white font-extrabold text-2xl flex items-center justify-center shadow-md shadow-indigo-500/20">
              {profile.name[0]}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white">
                  {profile.name}
                </h1>
                <span className="text-xs font-bold px-2.5 py-0.5 rounded-full bg-orange-100 text-orange-800 dark:bg-orange-950/60 dark:text-orange-300">
                  Level {profile.level}
                </span>
              </div>
              <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 mt-1">
                Active Career Forge:{' '}
                <strong className="text-slate-800 dark:text-slate-200">{career.title}</strong>
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="px-4 py-2 rounded-2xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800/60 flex items-center gap-2">
              <Flame className="w-5 h-5 fill-amber-500 text-amber-500" />
              <div>
                <div className="text-xs font-bold text-amber-900 dark:text-amber-300">
                  {profile.streakDays} Day Streak
                </div>
                <div className="text-[10px] text-amber-700/80 dark:text-amber-400">Daily Practice</div>
              </div>
            </div>

            <div className="px-4 py-2 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800/60 flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
              <div>
                <div className="text-xs font-bold text-emerald-900 dark:text-emerald-300">
                  {profile.xp} Total XP
                </div>
                <div className="text-[10px] text-emerald-700/80 dark:text-emerald-400">
                  Skill Points
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Career Readiness Meter */}
      <div
        id="career-readiness-section"
        className="rounded-3xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-850 p-6 sm:p-8 space-y-6 shadow-sm"
      >
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <Award className="w-5 h-5 text-orange-600" />
              <h2 className="text-lg sm:text-xl font-black text-slate-900 dark:text-white">
                Career Readiness Guidance
              </h2>
            </div>
            <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 mt-1">
              A transparent breakdown measuring core capabilities, applied tasks, and completed project
              artifacts.
            </p>
          </div>

          <div className="text-right">
            <span className="text-3xl font-black text-orange-600 dark:text-orange-400">
              {Math.max(pathPct, 68)}%
            </span>
            <p className="text-[11px] font-bold text-slate-500 uppercase">Overall Readiness</p>
          </div>
        </div>

        {/* Readiness Bars */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
          {[
            { label: 'Core Skills Acquisition', pct: 80, desc: 'Mastery of baseline formulas, syntax, and logic' },
            { label: 'Practical Work & Scenarios', pct: 60, desc: 'Workplace problem-solving and data interpretation' },
            { label: 'Demonstrated Projects', pct: 70, desc: 'End-to-end deliverables tested against rubrics' },
            { label: 'Assessments Passed', pct: 80, desc: 'Evaluations confirming knowledge retention' },
            { label: 'Portfolio Documentation', pct: 50, desc: 'Published case studies and verified code repositories' },
            { label: 'Career Alignment', pct: 75, desc: 'Match between target role expectations and skills built' },
          ].map((item) => (
            <div
              key={item.label}
              className="p-4 rounded-2xl border border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/50 space-y-2"
            >
              <div className="flex items-center justify-between text-xs font-bold text-slate-900 dark:text-white">
                <span>{item.label}</span>
                <span className="text-orange-600 dark:text-orange-400">{item.pct}%</span>
              </div>
              <div className="w-full bg-slate-200 dark:bg-slate-700 h-2 rounded-full overflow-hidden">
                <div
                  className="bg-orange-500 h-full rounded-full transition-all duration-500"
                  style={{ width: `${item.pct}%` }}
                />
              </div>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">{item.desc}</p>
            </div>
          ))}
        </div>

        {/* Mandatory Career Guidance Notice */}
        <div className="p-4 rounded-2xl border border-amber-200 dark:border-amber-900/60 bg-amber-50/60 dark:bg-amber-950/20 flex items-start gap-3">
          <ShieldAlert className="w-5 h-5 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" />
          <p className="text-xs text-amber-900 dark:text-amber-300 leading-relaxed">
            <strong>Skill Forge Career Guidance Policy:</strong> Readiness percentages reflect your
            progress across our curriculum, verified rubrics, and project briefs. We empower your job
            search with concrete evidence of ability and portfolio artifacts, but we do not guarantee
            employment or make unrealistic placement claims.
          </p>
        </div>
      </div>

      {/* Portfolio Section */}
      <div
        id="portfolio-section"
        className="rounded-3xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-850 p-6 sm:p-8 space-y-6 shadow-sm"
      >
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <FolderGit2 className="w-5 h-5 text-indigo-500" />
              <h2 className="text-lg sm:text-xl font-black text-slate-900 dark:text-white">
                Verified Project Portfolio
              </h2>
            </div>
            <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 mt-1">
              Tangible artifacts and workplace simulations you have built to showcase in interviews.
            </p>
          </div>

          <button
            onClick={() => setCurrentTab('challenges')}
            className="text-xs font-bold text-orange-600 dark:text-orange-400 hover:underline"
          >
            Add Another Project →
          </button>
        </div>

        {profile.completedProjects.length === 0 ? (
          <div className="p-8 text-center rounded-2xl border border-dashed border-slate-200 dark:border-slate-800">
            <p className="text-sm text-slate-500">No completed projects yet.</p>
            <button
              onClick={() => setCurrentTab('challenges')}
              className="mt-3 px-4 py-2 rounded-xl bg-orange-600 text-white text-xs font-bold"
            >
              Start First Project
            </button>
          </div>
        ) : (
          <div className="space-y-4">
            {profile.completedProjects.map((proj) => (
              <div
                key={proj.id}
                className="p-5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/40 space-y-3"
              >
                <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-2">
                  <div>
                    <span className="text-[11px] font-bold uppercase tracking-wider text-orange-600 dark:text-orange-400">
                      {proj.careerTitle} • Completed {proj.completedAt}
                    </span>
                    <h3 className="text-base font-bold text-slate-900 dark:text-white mt-0.5">
                      {proj.title}
                    </h3>
                  </div>

                  {proj.artifactsLink && (
                    <a
                      href={`https://${proj.artifactsLink}`}
                      target="_blank"
                      rel="noreferrer"
                      className="inline-flex items-center gap-1.5 text-xs font-bold text-indigo-600 dark:text-indigo-400 hover:underline shrink-0"
                    >
                      <span>View Code / Repo</span>
                      <ExternalLink className="w-3.5 h-3.5" />
                    </a>
                  )}
                </div>

                <p className="text-xs sm:text-sm text-slate-700 dark:text-slate-300 leading-relaxed">
                  <strong>Summary:</strong> {proj.summary}
                </p>

                <div className="p-3 rounded-xl bg-white dark:bg-slate-850 border border-slate-200/60 dark:border-slate-800 text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                  <strong className="text-slate-900 dark:text-white block mb-0.5">
                    Actionable Findings:
                  </strong>
                  {proj.keyFindings}
                </div>

                <div className="flex flex-wrap items-center gap-1.5 pt-1">
                  <span className="text-[11px] font-semibold text-slate-400 mr-1">Skills:</span>
                  {proj.demonstratedSkills.map((sk) => (
                    <span
                      key={sk}
                      className="px-2.5 py-0.5 rounded-lg text-xs font-semibold bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300"
                    >
                      {sk}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Earned Badges & Achievements */}
      <div
        id="achievements-section"
        className="rounded-3xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-850 p-6 sm:p-8 space-y-6 shadow-sm"
      >
        <div>
          <h2 className="text-lg sm:text-xl font-black text-slate-900 dark:text-white">
            Skill Badges & Achievements
          </h2>
          <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 mt-1">
            Earned by demonstrating real-world competence, completing projects, and maintaining
            learning streaks.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {profile.achievements.map((ach) => {
            const isUnlocked = !!ach.unlockedAt;

            return (
              <div
                key={ach.id}
                className={`p-4 rounded-2xl border flex items-start gap-3.5 transition-all ${
                  isUnlocked
                    ? 'border-amber-200 dark:border-amber-900/60 bg-amber-50/40 dark:bg-amber-950/20'
                    : 'border-slate-200 dark:border-slate-800 opacity-50 bg-slate-50 dark:bg-slate-900/40'
                }`}
              >
                <div
                  className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
                    isUnlocked
                      ? 'bg-amber-500 text-white shadow-sm shadow-amber-500/30'
                      : 'bg-slate-200 dark:bg-slate-800 text-slate-400'
                  }`}
                >
                  <DynamicIcon name={ach.icon} className="w-5 h-5" />
                </div>

                <div>
                  <div className="flex items-center gap-2">
                    <h4 className="text-xs font-bold text-slate-900 dark:text-white">{ach.title}</h4>
                    {isUnlocked && (
                      <span className="text-[10px] font-bold text-amber-700 dark:text-amber-400">
                        ✓ Unlocked
                      </span>
                    )}
                  </div>
                  <p className="text-[11px] text-slate-600 dark:text-slate-400 mt-0.5 leading-snug">
                    {ach.desc}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Reset State Option */}
      <div className="flex items-center justify-between p-4 rounded-2xl border border-slate-200 dark:border-slate-800 text-xs text-slate-500">
        <span>Need to reset test data to start fresh?</span>
        <button
          onClick={onResetProgress}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 font-bold transition-colors"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>Reset Demonstration Progress</span>
        </button>
      </div>
    </div>
  );
};
