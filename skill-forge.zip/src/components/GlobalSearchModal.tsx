import React, { useState, useEffect } from 'react';
import { Search, X, Compass, GitFork, BookOpen, Target, ArrowRight } from 'lucide-react';
import { ALL_CAREERS } from '../data/allCareers';
import { DAILY_CHALLENGES } from '../data/challenges';

interface GlobalSearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectCareer: (id: string) => void;
  onOpenModule: (moduleId: string) => void;
  onOpenChallenge: (challengeId: string) => void;
  setCurrentTab: (tab: string) => void;
}

export const GlobalSearchModal: React.FC<GlobalSearchModalProps> = ({
  isOpen,
  onClose,
  onSelectCareer,
  onOpenModule,
  onOpenChallenge,
  setCurrentTab,
}) => {
  const [query, setQuery] = useState('');

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
      if ((e.key === '/' || (e.ctrlKey && e.key === 'k')) && !isOpen) {
        e.preventDefault();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const cleanQuery = query.toLowerCase().trim();

  const matchingCareers = ALL_CAREERS.filter(
    (c) =>
      !cleanQuery ||
      c.title.toLowerCase().includes(cleanQuery) ||
      c.category.toLowerCase().includes(cleanQuery) ||
      c.coreSkills.some((s) => s.name.toLowerCase().includes(cleanQuery))
  ).slice(0, 4);

  const matchingModules: Array<{
    careerTitle: string;
    moduleId: string;
    title: string;
    goal: string;
  }> = [];

  for (const c of ALL_CAREERS) {
    for (const s of c.skillTree) {
      for (const m of s.modules) {
        if (
          !cleanQuery ||
          m.title.toLowerCase().includes(cleanQuery) ||
          m.goal.toLowerCase().includes(cleanQuery) ||
          s.title.toLowerCase().includes(cleanQuery)
        ) {
          matchingModules.push({
            careerTitle: c.title,
            moduleId: m.id,
            title: m.title,
            goal: m.goal,
          });
        }
      }
    }
  }

  const matchingChallenges = DAILY_CHALLENGES.filter(
    (ch) =>
      !cleanQuery ||
      ch.title.toLowerCase().includes(cleanQuery) ||
      ch.skill.toLowerCase().includes(cleanQuery)
  );

  return (
    <div
      id="global-search-modal"
      className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-start justify-center pt-20 p-4"
    >
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 max-w-xl w-full shadow-2xl overflow-hidden flex flex-col max-h-[80vh]">
        {/* Search Input */}
        <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex items-center gap-3">
          <Search className="w-5 h-5 text-slate-400" />
          <input
            autoFocus
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search careers, skills, modules, or challenges..."
            className="flex-1 bg-transparent text-sm text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none"
          />
          <kbd className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-400 border border-slate-200 dark:border-slate-700">
            ESC
          </kbd>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Results List */}
        <div className="p-4 overflow-y-auto space-y-4 flex-1">
          {/* Careers */}
          {matchingCareers.length > 0 && (
            <div>
              <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block mb-2">
                Career Paths
              </span>
              <div className="space-y-1">
                {matchingCareers.map((c) => (
                  <button
                    key={c.id}
                    onClick={() => {
                      onSelectCareer(c.id);
                      setCurrentTab('careers');
                      onClose();
                    }}
                    className="w-full p-2.5 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center justify-between text-left text-xs transition-colors"
                  >
                    <div className="flex items-center gap-2.5">
                      <Compass className="w-4 h-4 text-orange-500 shrink-0" />
                      <span className="font-bold text-slate-900 dark:text-white">{c.title}</span>
                      <span className="text-[11px] text-slate-500">({c.category})</span>
                    </div>
                    <ArrowRight className="w-3.5 h-3.5 text-slate-400" />
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Modules */}
          {matchingModules.length > 0 && (
            <div>
              <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block mb-2">
                Learning Modules
              </span>
              <div className="space-y-1">
                {matchingModules.slice(0, 4).map((m) => (
                  <button
                    key={m.moduleId}
                    onClick={() => {
                      onOpenModule(m.moduleId);
                      onClose();
                    }}
                    className="w-full p-2.5 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center justify-between text-left text-xs transition-colors"
                  >
                    <div className="flex items-center gap-2.5 truncate">
                      <BookOpen className="w-4 h-4 text-blue-500 shrink-0" />
                      <div className="truncate">
                        <span className="font-bold text-slate-900 dark:text-white block truncate">
                          {m.title}
                        </span>
                        <span className="text-[11px] text-slate-500 truncate block">
                          {m.careerTitle} • {m.goal}
                        </span>
                      </div>
                    </div>
                    <ArrowRight className="w-3.5 h-3.5 text-slate-400 shrink-0 ml-2" />
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Challenges */}
          {matchingChallenges.length > 0 && (
            <div>
              <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block mb-2">
                Workplace Challenges
              </span>
              <div className="space-y-1">
                {matchingChallenges.slice(0, 3).map((ch) => (
                  <button
                    key={ch.id}
                    onClick={() => {
                      onOpenChallenge(ch.id);
                      onClose();
                    }}
                    className="w-full p-2.5 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center justify-between text-left text-xs transition-colors"
                  >
                    <div className="flex items-center gap-2.5">
                      <Target className="w-4 h-4 text-emerald-500 shrink-0" />
                      <span className="font-bold text-slate-900 dark:text-white">{ch.title}</span>
                    </div>
                    <ArrowRight className="w-3.5 h-3.5 text-slate-400" />
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
