import React, { useState } from 'react';
import {
  Target,
  FolderGit2,
  CheckCircle2,
  Clock,
  Sparkles,
  ArrowRight,
  ExternalLink,
  Code,
  FileText,
  HelpCircle,
  Award,
  Send,
  X,
} from 'lucide-react';
import { DailyChallenge, CareerProject, UserProfile } from '../types';
import { DAILY_CHALLENGES } from '../data/challenges';
import { getCareerById } from '../data/allCareers';

interface ChallengesProjectsViewProps {
  profile: UserProfile;
  onOpenChallenge: (challenge: DailyChallenge) => void;
  onSubmitProject: (project: {
    projectId: string;
    title: string;
    careerTitle: string;
    summary: string;
    artifactsLink?: string;
    keyFindings: string;
    demonstratedSkills: string[];
  }) => void;
}

export const ChallengesProjectsView: React.FC<ChallengesProjectsViewProps> = ({
  profile,
  onOpenChallenge,
  onSubmitProject,
}) => {
  const [activeTab, setActiveTab] = useState<'challenges' | 'projects'>('challenges');
  const career = getCareerById(profile.selectedCareerId);

  // Selected project for submission
  const [submittingProject, setSubmittingProject] = useState<CareerProject | null>(null);
  const [projectSummary, setProjectSummary] = useState('');
  const [projectArtifacts, setProjectArtifacts] = useState('');
  const [projectKeyFindings, setProjectKeyFindings] = useState('');

  const handleProjectSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!submittingProject || !projectSummary.trim() || !projectKeyFindings.trim()) return;

    onSubmitProject({
      projectId: submittingProject.id,
      title: submittingProject.title,
      careerTitle: career.title,
      summary: projectSummary,
      artifactsLink: projectArtifacts,
      keyFindings: projectKeyFindings,
      demonstratedSkills: submittingProject.skillsCovered,
    });

    setSubmittingProject(null);
    setProjectSummary('');
    setProjectArtifacts('');
    setProjectKeyFindings('');
  };

  return (
    <div id="challenges-projects-view" className="space-y-8 pb-16">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-6">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold uppercase tracking-wider bg-orange-100 dark:bg-orange-950/60 text-orange-700 dark:text-orange-300">
              Hands-on Workplace Practice
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight mt-1">
            Challenges & Projects
          </h1>
          <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 mt-1 max-w-2xl">
            Move beyond theoretical tests. Complete practical workplace micro-tasks or build
            end-to-end projects to prove your readiness in real business environments.
          </p>
        </div>

        {/* Tab switcher */}
        <div className="flex items-center p-1 rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 self-start sm:self-auto">
          <button
            id="challenges-tab-btn"
            onClick={() => setActiveTab('challenges')}
            className={`px-4 py-1.5 rounded-lg text-xs font-bold transition-all ${
              activeTab === 'challenges'
                ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-sm'
                : 'text-slate-600 dark:text-slate-400'
            }`}
          >
            Practical Challenges
          </button>

          <button
            id="projects-tab-btn"
            onClick={() => setActiveTab('projects')}
            className={`px-4 py-1.5 rounded-lg text-xs font-bold transition-all ${
              activeTab === 'projects'
                ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-sm'
                : 'text-slate-600 dark:text-slate-400'
            }`}
          >
            Career Projects ({career.projects.length})
          </button>
        </div>
      </div>

      {/* SUB-TAB 1: CHALLENGES */}
      {activeTab === 'challenges' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {DAILY_CHALLENGES.map((ch) => (
              <div
                key={ch.id}
                id={`challenge-card-${ch.id}`}
                className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-850 p-6 flex flex-col justify-between shadow-sm hover:shadow-md transition-shadow"
              >
                <div>
                  <div className="flex items-center justify-between gap-2 mb-3">
                    <span className="text-xs font-bold px-2.5 py-0.5 rounded-full bg-indigo-50 text-indigo-700 dark:bg-indigo-950/60 dark:text-indigo-300">
                      {ch.careerCategory} • {ch.skill}
                    </span>
                    <span className="text-xs font-bold text-amber-600 dark:text-amber-400 flex items-center gap-1">
                      <Sparkles className="w-3.5 h-3.5" />+{ch.xpReward} XP
                    </span>
                  </div>

                  <h3 className="text-base font-bold text-slate-900 dark:text-white mb-2">
                    {ch.title}
                  </h3>

                  <p className="text-xs text-slate-600 dark:text-slate-400 line-clamp-3 mb-4 leading-relaxed">
                    {ch.prompt}
                  </p>
                </div>

                <div className="pt-4 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
                  <span className="text-[11px] font-semibold text-slate-500 uppercase">
                    Task Type: {ch.taskType}
                  </span>

                  <button
                    id={`open-challenge-${ch.id}`}
                    onClick={() => onOpenChallenge(ch)}
                    className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-orange-600 hover:bg-orange-700 text-white text-xs font-bold transition-colors shadow-sm"
                  >
                    <span>Solve Challenge</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* SUB-TAB 2: PROJECTS */}
      {activeTab === 'projects' && (
        <div className="space-y-6">
          <div className="p-4 rounded-2xl bg-orange-50/60 dark:bg-orange-950/20 border border-orange-200 dark:border-orange-900/40 flex items-start gap-3">
            <Award className="w-5 h-5 text-orange-600 dark:text-orange-400 shrink-0 mt-0.5" />
            <div>
              <h4 className="text-xs font-bold uppercase tracking-wider text-orange-900 dark:text-orange-300">
                Portfolio-Grade Projects for {career.title}
              </h4>
              <p className="text-xs text-orange-950 dark:text-orange-200 mt-0.5">
                Complete these realistic workplace simulations and publish your findings. Submitted
                projects are saved directly into your verified Portfolio tab.
              </p>
            </div>
          </div>

          <div className="space-y-6">
            {career.projects.map((proj) => {
              const isCompleted = profile.completedProjects.some((p) => p.projectId === proj.id);

              return (
                <div
                  key={proj.id}
                  id={`project-card-${proj.id}`}
                  className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-850 p-6 sm:p-8 space-y-6 shadow-sm"
                >
                  <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
                    <div>
                      <div className="flex items-center gap-2 mb-1.5">
                        <span className="text-xs font-bold px-2.5 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
                          {proj.difficulty}
                        </span>
                        <span className="text-xs font-medium text-slate-500">
                          Est. {proj.estimatedTime}
                        </span>
                        {isCompleted && (
                          <span className="text-xs font-bold px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300 flex items-center gap-1">
                            <CheckCircle2 className="w-3.5 h-3.5" /> Published in Portfolio
                          </span>
                        )}
                      </div>

                      <h3 className="text-xl font-bold text-slate-900 dark:text-white">
                        {proj.title}
                      </h3>
                      <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 mt-1 max-w-3xl leading-relaxed">
                        {proj.summary}
                      </p>
                    </div>

                    <button
                      id={`start-project-btn-${proj.id}`}
                      onClick={() => setSubmittingProject(proj)}
                      className="px-5 py-2.5 rounded-xl bg-orange-600 hover:bg-orange-700 text-white text-xs font-bold transition-colors shadow-sm shrink-0 self-start inline-flex items-center gap-2"
                    >
                      <span>{isCompleted ? 'Update Project' : 'Submit & Add to Portfolio'}</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  {/* Workplace Scenario */}
                  <div className="p-4 rounded-xl border border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/40">
                    <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-1">
                      Workplace Business Scenario
                    </h4>
                    <p className="text-xs text-slate-700 dark:text-slate-300 leading-relaxed">
                      {proj.sampleDataOrScenario}
                    </p>
                  </div>

                  {/* Project Deliverable Steps */}
                  <div>
                    <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-3">
                      Required Deliverables
                    </h4>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {proj.steps.map((st, sIdx) => (
                        <div
                          key={sIdx}
                          className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900"
                        >
                          <span className="text-xs font-bold text-slate-900 dark:text-white">
                            {st.title}
                          </span>
                          <p className="text-xs text-slate-600 dark:text-slate-400 mt-1">
                            {st.description}
                          </p>
                          <div className="mt-2 text-[11px] font-semibold text-orange-600 dark:text-orange-400">
                            Deliverable: {st.deliverable}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Skills Demonstrated */}
                  <div className="flex flex-wrap items-center gap-2 pt-2">
                    <span className="text-xs font-bold text-slate-500 dark:text-slate-400 mr-1">
                      Skills Demonstrated:
                    </span>
                    {proj.skillsCovered.map((s) => (
                      <span
                        key={s}
                        className="px-2.5 py-1 rounded-lg text-xs font-semibold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300"
                      >
                        {s}
                      </span>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Project Submission Modal */}
      {submittingProject && (
        <div
          id="project-submit-modal"
          className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto"
        >
          <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 max-w-xl w-full shadow-2xl p-6 sm:p-8 space-y-5">
            <div className="flex items-start justify-between gap-4">
              <div>
                <span className="text-xs font-bold uppercase tracking-wider text-orange-600 dark:text-orange-400">
                  Add to Portfolio
                </span>
                <h3 className="text-xl font-black text-slate-900 dark:text-white mt-0.5">
                  {submittingProject.title}
                </h3>
              </div>

              <button
                onClick={() => setSubmittingProject(null)}
                className="p-2 rounded-xl text-slate-400 hover:text-slate-900 dark:hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleProjectSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Executive Summary of Work
                </label>
                <textarea
                  required
                  rows={3}
                  value={projectSummary}
                  onChange={(e) => setProjectSummary(e.target.value)}
                  placeholder="Summarize the business problem you solved, the methodology applied, and results achieved..."
                  className="w-full p-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-xs text-slate-900 dark:text-white focus:ring-2 focus:ring-orange-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Key Findings & Strategic Recommendations
                </label>
                <textarea
                  required
                  rows={3}
                  value={projectKeyFindings}
                  onChange={(e) => setProjectKeyFindings(e.target.value)}
                  placeholder="What actionable insights did you uncover from the data/prototype? (e.g. 73% drop occurred in...)"
                  className="w-full p-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-xs text-slate-900 dark:text-white focus:ring-2 focus:ring-orange-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Link to Artifacts (GitHub, Figma, Google Drive, or Demo URL)
                </label>
                <input
                  type="text"
                  value={projectArtifacts}
                  onChange={(e) => setProjectArtifacts(e.target.value)}
                  placeholder="github.com/username/project-repo"
                  className="w-full p-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-xs text-slate-900 dark:text-white focus:ring-2 focus:ring-orange-500 focus:outline-none"
                />
              </div>

              <div className="pt-3 flex items-center justify-end gap-3 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setSubmittingProject(null)}
                  className="px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-600 dark:text-slate-400"
                >
                  Cancel
                </button>

                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-orange-600 hover:bg-orange-700 text-white text-xs font-bold shadow-sm transition-colors"
                >
                  Publish to Portfolio (+150 XP)
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
