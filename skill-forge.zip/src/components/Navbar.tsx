import React from 'react';
import { Flame, Sparkles, Search, Moon, Sun, Compass, Bot, CheckCircle2 } from 'lucide-react';
import { UserProfile } from '../types';
import { getCareerById } from '../data/allCareers';

interface NavbarProps {
  currentTab: string;
  setCurrentTab: (tab: string) => void;
  profile: UserProfile;
  darkMode: boolean;
  setDarkMode: (val: boolean | ((prev: boolean) => boolean)) => void;
  onOpenSearch: () => void;
  onOpenAI: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentTab,
  setCurrentTab,
  profile,
  darkMode,
  setDarkMode,
  onOpenSearch,
  onOpenAI,
}) => {
  const activeCareer = getCareerById(profile.selectedCareerId);

  return (
    <header
      id="main-navbar"
      className="sticky top-0 z-40 w-full border-b transition-colors duration-200 backdrop-blur-md bg-white/90 border-slate-200 dark:bg-slate-900/90 dark:border-slate-800"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4">
        {/* Logo & Tagline */}
        <div className="flex items-center gap-4 lg:gap-6 shrink-0">
          <button
            id="brand-logo-btn"
            onClick={() => setCurrentTab('home')}
            className="flex items-center gap-3 text-left group focus:outline-none shrink-0"
            aria-label="Skill Forge Home"
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-amber-500 via-orange-500 to-red-600 flex items-center justify-center text-white shadow-md shadow-orange-500/25 group-hover:scale-105 transition-transform border border-amber-300/30 shrink-0">
              <Flame className="w-5 h-5 text-white" strokeWidth={2.3} fill="#fed7aa" />
            </div>
            <div className="flex flex-col shrink-0">
              <div className="flex items-center gap-1.5 leading-none">
                <span className="font-black text-xl tracking-tight text-slate-900 dark:text-white whitespace-nowrap">
                  SKILL
                </span>
                <span className="font-black text-xl tracking-tight bg-gradient-to-r from-orange-600 via-amber-500 to-orange-500 bg-clip-text text-transparent whitespace-nowrap">
                  FORGE
                </span>
              </div>
              <p className="hidden sm:block text-[10px] font-semibold text-slate-500 dark:text-slate-400 tracking-wider uppercase mt-1 whitespace-nowrap">
                Build Skills • Shape Future
              </p>
            </div>
          </button>

          {/* Desktop Navigation Links */}
          <nav id="desktop-nav-links" className="hidden xl:flex items-center gap-1 pl-2 shrink-0">
            {[
              { id: 'home', label: 'Home' },
              { id: 'careers', label: 'Careers' },
              { id: 'skills', label: 'Skill Tree' },
              { id: 'challenges', label: 'Challenges & Projects' },
              { id: 'forge-ai', label: 'Forge AI' },
              { id: 'profile', label: 'Profile' },
            ].map((item) => (
              <button
                key={item.id}
                id={`nav-link-${item.id}`}
                onClick={() => setCurrentTab(item.id)}
                className={`px-3 py-1.5 rounded-lg text-sm font-semibold transition-colors ${
                  currentTab === item.id
                    ? 'bg-slate-100 text-slate-900 dark:bg-slate-800 dark:text-white'
                    : 'text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-100'
                }`}
              >
                {item.label}
              </button>
            ))}
          </nav>
        </div>

        {/* Right Section: Career Pill, Search, Streak, Level, Theme, Profile */}
        <div className="flex items-center gap-2 sm:gap-2.5 shrink-0">
          {/* Active Career Indicator */}
          <button
            id="active-career-pill"
            onClick={() => setCurrentTab('careers')}
            className="hidden 2xl:flex items-center gap-2 px-3 py-1.5 rounded-full border border-orange-200 bg-orange-50/70 text-orange-900 dark:border-orange-900/50 dark:bg-orange-950/40 dark:text-orange-300 text-xs font-semibold hover:bg-orange-100 transition-colors"
            title="Click to view or switch careers"
          >
            <Compass className="w-3.5 h-3.5 text-orange-600 dark:text-orange-400" />
            <span className="truncate max-w-[140px]">{activeCareer.title}</span>
          </button>

          {/* Search Trigger */}
          <button
            id="global-search-btn"
            onClick={onOpenSearch}
            className="flex items-center gap-2 px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-800 text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white bg-slate-50 dark:bg-slate-800/50 text-xs font-medium transition-colors"
            title="Search careers, skills, and projects (Ctrl+K or /)"
          >
            <Search className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Search</span>
            <kbd className="hidden sm:inline-block px-1.5 py-0.5 text-[10px] font-mono bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded text-slate-400">
              /
            </kbd>
          </button>

          {/* Streak Indicator */}
          <div
            id="streak-badge"
            className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800/60 text-amber-700 dark:text-amber-300 text-xs font-bold"
            title={`${profile.streakDays} Day Learning Streak! Keep practicing daily.`}
          >
            <Flame className="w-4 h-4 fill-amber-500 text-amber-500" />
            <span>{profile.streakDays}d</span>
          </div>

          {/* XP & Level Indicator */}
          <div
            id="level-badge"
            className="hidden sm:flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800/60 text-emerald-700 dark:text-emerald-300 text-xs font-bold"
            title={`Level ${profile.level} (${profile.xp} Total XP earned)`}
          >
            <Sparkles className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
            <span>Lvl {profile.level}</span>
          </div>

          {/* Quick AI Trigger */}
          <button
            id="quick-ai-btn"
            onClick={onOpenAI}
            className="p-2 rounded-lg border border-indigo-200 dark:border-indigo-900/60 bg-indigo-50 dark:bg-indigo-950/40 text-indigo-600 dark:text-indigo-400 hover:bg-indigo-100 dark:hover:bg-indigo-900/60 transition-colors"
            title="Ask Forge AI"
          >
            <Bot className="w-4 h-4" />
          </button>

          {/* Dark / Light Mode Toggle */}
          <button
            id="theme-toggle-btn"
            onClick={() => setDarkMode((prev) => !prev)}
            className="p-2 rounded-lg border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            title={darkMode ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
          >
            {darkMode ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4" />}
          </button>

          {/* Profile Shortcut */}
          <button
            id="user-avatar-btn"
            onClick={() => setCurrentTab('profile')}
            className="w-8 h-8 rounded-full bg-gradient-to-br from-indigo-500 to-purple-600 text-white font-bold text-xs flex items-center justify-center border-2 border-white dark:border-slate-800 shadow-sm hover:ring-2 hover:ring-indigo-400 transition-all"
            title="View Profile & Portfolio"
          >
            {profile.name[0]}
          </button>
        </div>
      </div>
    </header>
  );
};
