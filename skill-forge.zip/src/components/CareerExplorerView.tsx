import React, { useState } from 'react';
import {
  Search,
  CheckCircle2,
  Clock,
  Compass,
  ArrowRight,
  ShieldAlert,
  FolderGit2,
  Sparkles,
  GitFork,
  X,
  Target,
} from 'lucide-react';
import { Career, UserProfile } from '../types';
import { ALL_CAREERS } from '../data/allCareers';
import { DynamicIcon } from './Icon';

interface CareerExplorerViewProps {
  profile: UserProfile;
  onSelectCareer: (careerId: string) => void;
  onOpenSkillTree: (careerId: string) => void;
}

export const CareerExplorerView: React.FC<CareerExplorerViewProps> = ({
  profile,
  onSelectCareer,
  onOpenSkillTree,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [detailCareer, setDetailCareer] = useState<Career | null>(null);

  const categories = [
    'All',
    'Data & AI',
    'Technology',
    'Business',
    'Design',
    'Marketing',
    'Finance',
    'Security',
    'Management',
    'Content',
    'Entrepreneurship',
  ];

  const filteredCareers = ALL_CAREERS.filter((c) => {
    const matchesCat = selectedCategory === 'All' || c.category === selectedCategory;
    const query = searchQuery.toLowerCase().trim();
    const matchesQuery =
      !query ||
      c.title.toLowerCase().includes(query) ||
      c.tagline.toLowerCase().includes(query) ||
      c.summary.toLowerCase().includes(query) ||
      c.coreSkills.some((s) => s.name.toLowerCase().includes(query));
    return matchesCat && matchesQuery;
  });

  return (
    <div id="career-explorer-view" className="space-y-8 pb-16">
      {/* Header */}
      <div>
        <div className="flex items-center gap-2">
          <span className="px-2.5 py-0.5 rounded-full text-xs font-bold uppercase tracking-wider bg-orange-100 dark:bg-orange-950/60 text-orange-700 dark:text-orange-300">
            Career Explorer
          </span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight mt-1">
          Explore Realistic Career Paths
        </h1>
        <p className="text-sm sm:text-base text-slate-600 dark:text-slate-400 mt-1 max-w-3xl">
          Choose a career built around practical workplace skills. Every path provides structured
          learning, real-world case studies, and portfolio-grade project briefs.
        </p>
      </div>

      {/* Search and Category Filter Bar */}
      <div className="space-y-4">
        <div className="relative">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            id="career-search-input"
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by role, tool, or skill (e.g. SQL, React, Figma, SEO, Python, Finance)..."
            className="w-full pl-10 pr-4 py-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-orange-500 text-sm shadow-sm"
          />
        </div>

        {/* Category Pills */}
        <div
          id="career-category-pills"
          className="flex items-center gap-1.5 overflow-x-auto pb-2 scrollbar-none"
        >
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition-colors ${
                selectedCategory === cat
                  ? 'bg-orange-600 text-white shadow-sm'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Career Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredCareers.map((career) => {
          const isSelected = profile.selectedCareerId === career.id;

          return (
            <div
              key={career.id}
              id={`career-card-${career.id}`}
              className={`rounded-2xl border transition-all duration-200 bg-white dark:bg-slate-850 p-6 flex flex-col justify-between shadow-sm hover:shadow-md ${
                isSelected
                  ? 'border-orange-500 ring-2 ring-orange-500/20'
                  : 'border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700'
              }`}
            >
              <div>
                <div className="flex items-center justify-between gap-2 mb-3">
                  <div className="w-10 h-10 rounded-xl bg-orange-50 dark:bg-orange-950/60 text-orange-600 dark:text-orange-400 flex items-center justify-center">
                    <DynamicIcon name={career.icon} className="w-5 h-5" />
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300">
                      {career.difficulty}
                    </span>
                    {isSelected && (
                      <span className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-orange-100 dark:bg-orange-950/60 text-orange-700 dark:text-orange-300">
                        Active
                      </span>
                    )}
                  </div>
                </div>

                <div className="mb-2">
                  <span className="text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wide">
                    {career.category}
                  </span>
                  <h3 className="text-lg font-bold text-slate-900 dark:text-white mt-0.5">
                    {career.title}
                  </h3>
                </div>

                <p className="text-xs text-slate-600 dark:text-slate-400 line-clamp-2 mb-4 leading-relaxed">
                  {career.tagline}
                </p>

                {/* Core Skills Preview */}
                <div className="space-y-1.5 mb-4">
                  <span className="text-[11px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                    Core Skills & Targets
                  </span>
                  <div className="space-y-1">
                    {career.coreSkills.slice(0, 3).map((skill) => (
                      <div
                        key={skill.name}
                        className="flex items-center justify-between text-xs text-slate-700 dark:text-slate-300"
                      >
                        <span className="truncate">{skill.name}</span>
                        <span className="font-mono text-[11px] font-semibold text-orange-600 dark:text-orange-400 ml-2">
                          {skill.proficiencyTarget}%
                        </span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400 pt-3 border-t border-slate-100 dark:border-slate-800">
                  <Clock className="w-3.5 h-3.5" />
                  <span>Est. {career.estimatedHours}</span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="mt-5 pt-4 border-t border-slate-100 dark:border-slate-800 flex items-center gap-2">
                <button
                  id={`view-details-${career.id}`}
                  onClick={() => setDetailCareer(career)}
                  className="flex-1 py-2 px-3 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 text-xs font-bold transition-colors text-center"
                >
                  View Details
                </button>

                {isSelected ? (
                  <button
                    id={`open-tree-${career.id}`}
                    onClick={() => onOpenSkillTree(career.id)}
                    className="flex-1 py-2 px-3 rounded-xl bg-orange-600 hover:bg-orange-700 text-white text-xs font-bold transition-colors text-center inline-flex items-center justify-center gap-1.5"
                  >
                    <span>Skill Tree</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                ) : (
                  <button
                    id={`select-career-${career.id}`}
                    onClick={() => onSelectCareer(career.id)}
                    className="flex-1 py-2 px-3 rounded-xl bg-slate-900 dark:bg-white hover:bg-slate-800 dark:hover:bg-slate-100 text-white dark:text-slate-900 text-xs font-bold transition-colors text-center"
                  >
                    Set as Active
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Career Details Modal */}
      {detailCareer && (
        <div
          id="career-detail-modal"
          className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto"
        >
          <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 max-w-2xl w-full max-h-[90vh] overflow-y-auto shadow-2xl p-6 sm:p-8 space-y-6">
            <div className="flex items-start justify-between gap-4">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-orange-100 dark:bg-orange-950/60 text-orange-600 dark:text-orange-400 flex items-center justify-center">
                  <DynamicIcon name={detailCareer.icon} className="w-6 h-6" />
                </div>
                <div>
                  <span className="text-xs font-bold uppercase tracking-wider text-orange-600 dark:text-orange-400">
                    {detailCareer.category}
                  </span>
                  <h2 className="text-2xl font-black text-slate-900 dark:text-white">
                    {detailCareer.title}
                  </h2>
                </div>
              </div>

              <button
                id="close-career-modal-btn"
                onClick={() => setDetailCareer(null)}
                className="p-2 rounded-xl text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Overview & Tagline */}
            <div>
              <p className="text-sm font-semibold text-slate-800 dark:text-slate-200">
                "{detailCareer.tagline}"
              </p>
              <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 mt-2 leading-relaxed">
                {detailCareer.summary}
              </p>
            </div>

            {/* Responsibilities */}
            <div>
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-2">
                Typical Day-to-Day Responsibilities
              </h4>
              <ul className="space-y-2">
                {detailCareer.responsibilities.map((resp, i) => (
                  <li key={i} className="flex items-start gap-2.5 text-xs text-slate-700 dark:text-slate-300">
                    <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
                    <span>{resp}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Core Skills & Proficiency Targets */}
            <div>
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-3">
                Core Skills Breakdown
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {detailCareer.coreSkills.map((skill) => (
                  <div
                    key={skill.name}
                    className="p-3 rounded-xl border border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/60"
                  >
                    <div className="flex items-center justify-between text-xs font-bold text-slate-900 dark:text-white mb-1">
                      <span>{skill.name}</span>
                      <span className="text-orange-600 dark:text-orange-400">
                        {skill.proficiencyTarget}%
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400 line-clamp-1">
                      {skill.description}
                    </p>
                    <div className="w-full bg-slate-200 dark:bg-slate-700 h-1.5 rounded-full overflow-hidden mt-2">
                      <div
                        className="bg-orange-500 h-full rounded-full"
                        style={{ width: `${skill.proficiencyTarget}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Practical Outcome & Project Highlights */}
            <div className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40">
              <div className="flex items-center gap-2 mb-1.5">
                <FolderGit2 className="w-4 h-4 text-indigo-500" />
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-800 dark:text-slate-200">
                  Real-World Portfolio Project
                </h4>
              </div>
              <p className="text-xs text-slate-600 dark:text-slate-400">
                {detailCareer.realWorldOutcome}
              </p>
            </div>

            {/* Responsible Career Guidance Disclaimer */}
            <div className="p-3.5 rounded-xl border border-amber-200 dark:border-amber-900/60 bg-amber-50/50 dark:bg-amber-950/20 flex items-start gap-2.5">
              <ShieldAlert className="w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" />
              <p className="text-[11px] text-amber-900 dark:text-amber-300 leading-relaxed">
                <strong className="font-semibold">Career Guidance Notice:</strong> Skill Forge prepares
                practical workplace skills, verified project artifacts, and interview problem-solving
                confidence. We do not make misleading claims or false guarantees of employment.
              </p>
            </div>

            {/* Footer Buttons */}
            <div className="flex flex-col sm:flex-row items-center justify-end gap-3 pt-4 border-t border-slate-100 dark:border-slate-800">
              <button
                onClick={() => setDetailCareer(null)}
                className="w-full sm:w-auto px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 text-xs font-bold hover:bg-slate-50 dark:hover:bg-slate-800"
              >
                Close
              </button>

              <button
                id="modal-select-and-tree-btn"
                onClick={() => {
                  onSelectCareer(detailCareer.id);
                  onOpenSkillTree(detailCareer.id);
                  setDetailCareer(null);
                }}
                className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-orange-600 hover:bg-orange-700 text-white text-xs font-bold inline-flex items-center justify-center gap-2 shadow-sm"
              >
                <span>Select & View Skill Tree</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
