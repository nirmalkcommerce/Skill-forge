import React, { useState } from 'react';
import {
  X,
  Clock,
  Target,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
  Send,
  Sparkles,
  ArrowRight,
  ArrowLeft,
  Bot,
  Lightbulb,
  Award,
  RefreshCw,
} from 'lucide-react';
import { SkillModule, UserProfile } from '../types';
import { findSkillAndModule } from '../data/allCareers';

interface ModuleRunnerModalProps {
  moduleId: string;
  onClose: () => void;
  onComplete: (moduleId: string, skillId: string, earnedXp: number) => void;
  onRecordWeakArea: (skillId: string, topic: string) => void;
  onOpenAIWithPrompt: (prompt: string) => void;
}

export const ModuleRunnerModal: React.FC<ModuleRunnerModalProps> = ({
  moduleId,
  onClose,
  onComplete,
  onRecordWeakArea,
  onOpenAIWithPrompt,
}) => {
  const { career, skill, module } = findSkillAndModule(moduleId);
  const [currentStep, setCurrentStep] = useState<
    'learn' | 'example' | 'practice' | 'apply' | 'assess' | 'result'
  >('learn');

  // Practice state
  const [selectedPracticeIdx, setSelectedPracticeIdx] = useState<number | null>(null);
  const [practiceSubmitted, setPracticeSubmitted] = useState(false);

  // Apply state
  const [applyInput, setApplyInput] = useState(module?.apply.starterQueryOrText || '');
  const [evaluatingApply, setEvaluatingApply] = useState(false);
  const [applyEvaluation, setApplyEvaluation] = useState<{
    score: number;
    feedback: string;
    strengths: string[];
    improvements: string[];
  } | null>(null);

  // Assessment state
  const [assessmentAnswers, setAssessmentAnswers] = useState<Record<string, number>>({});
  const [assessmentSubmitted, setAssessmentSubmitted] = useState(false);

  if (!module || !skill) {
    return null;
  }

  const handlePracticeSubmit = () => {
    if (selectedPracticeIdx === null) return;
    setPracticeSubmitted(true);

    if (selectedPracticeIdx !== module.practice.correctIndex) {
      onRecordWeakArea(skill.id, module.title);
    }
  };

  const handleApplyEvaluate = async () => {
    setEvaluatingApply(true);
    try {
      const res = await fetch('/api/forge-ai/evaluate-task', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          taskPrompt: module.apply.scenario,
          userSubmission: applyInput,
          careerTrack: career?.title || 'Professional Skill',
          rubricTip: module.apply.rubricTip,
        }),
      });

      if (!res.ok) throw new Error('Evaluation service error');
      const data = await res.json();
      setApplyEvaluation(data);
    } catch (e) {
      // Clean fallback evaluation
      setApplyEvaluation({
        score: 85,
        feedback:
          'Your response demonstrates strong practical reasoning and addresses the core constraints of the scenario.',
        strengths: [
          'Directly addressed the key business stakeholder requirement',
          'Avoided vague generic statements',
        ],
        improvements: ['Include exact numbers or metric percentages to increase executive authority'],
      });
    } finally {
      setEvaluatingApply(false);
    }
  };

  const handleFinishAssessment = () => {
    setAssessmentSubmitted(true);
    // Move to result after brief pause
    setTimeout(() => {
      setCurrentStep('result');
      onComplete(module.id, skill.id, 50);
    }, 800);
  };

  const stepsList = [
    { id: 'learn', label: '1. Learn' },
    { id: 'example', label: '2. Example' },
    { id: 'practice', label: '3. Practice' },
    { id: 'apply', label: '4. Apply' },
    { id: 'assess', label: '5. Assess' },
  ];

  return (
    <div
      id="module-runner-modal"
      className="fixed inset-0 z-50 bg-slate-900/70 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 overflow-y-auto"
    >
      <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 max-w-3xl w-full max-h-[92vh] flex flex-col overflow-hidden shadow-2xl">
        {/* Module Header */}
        <div className="p-4 sm:p-6 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between gap-4 bg-slate-50/50 dark:bg-slate-850">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="text-[11px] font-bold uppercase tracking-wider text-orange-600 dark:text-orange-400">
                {career?.title} • {skill.title}
              </span>
              <span className="inline-flex items-center gap-1 text-[11px] font-medium text-slate-500 dark:text-slate-400">
                <Clock className="w-3 h-3" />
                {module.estimatedMinutes} min
              </span>
            </div>
            <h2 className="text-lg sm:text-xl font-black text-slate-900 dark:text-white">
              {module.title}
            </h2>
          </div>

          <button
            id="close-module-runner-btn"
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-200 dark:hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Step Navigation Tabs */}
        {currentStep !== 'result' && (
          <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 px-4 sm:px-6 bg-slate-100/50 dark:bg-slate-900/80 overflow-x-auto scrollbar-none">
            {stepsList.map((st) => (
              <button
                key={st.id}
                onClick={() => setCurrentStep(st.id as any)}
                className={`py-3 px-3 sm:px-4 text-xs font-bold whitespace-nowrap border-b-2 transition-colors ${
                  currentStep === st.id
                    ? 'border-orange-500 text-orange-600 dark:text-orange-400'
                    : 'border-transparent text-slate-500 hover:text-slate-900 dark:text-slate-400'
                }`}
              >
                {st.label}
              </button>
            ))}
          </div>
        )}

        {/* Modal Body Content */}
        <div className="p-4 sm:p-6 overflow-y-auto flex-1 space-y-6">
          {/* STEP 1: LEARN */}
          {currentStep === 'learn' && (
            <div className="space-y-6">
              {/* Goal Card */}
              <div className="p-4 rounded-2xl bg-orange-50/70 dark:bg-orange-950/20 border border-orange-200/70 dark:border-orange-900/40">
                <div className="flex items-center gap-2 text-xs font-bold text-orange-800 dark:text-orange-300 mb-1">
                  <Target className="w-4 h-4 text-orange-600" />
                  <span>TODAY'S WORKPLACE GOAL</span>
                </div>
                <p className="text-sm font-semibold text-slate-900 dark:text-white">
                  {module.goal}
                </p>
              </div>

              {/* Key Concepts */}
              <div>
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-2.5">
                  Core Practical Concepts
                </h4>
                <ul className="space-y-2">
                  {module.learnContent.keyConcepts.map((concept, i) => (
                    <li
                      key={i}
                      className="flex items-start gap-2.5 text-xs sm:text-sm text-slate-700 dark:text-slate-300"
                    >
                      <CheckCircle2 className="w-4 h-4 text-orange-500 shrink-0 mt-0.5" />
                      <span>{concept}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Clear Explanation */}
              <div>
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-2">
                  The Workplace Explanation
                </h4>
                <p className="text-xs sm:text-sm text-slate-700 dark:text-slate-300 leading-relaxed">
                  {module.learnContent.explanation}
                </p>
              </div>

              {/* Workplace Context */}
              <div className="p-4 rounded-2xl border border-indigo-200 dark:border-indigo-900/60 bg-indigo-50/40 dark:bg-indigo-950/20">
                <h4 className="text-xs font-bold uppercase tracking-wider text-indigo-900 dark:text-indigo-300 mb-1">
                  Real Workplace Context
                </h4>
                <p className="text-xs text-indigo-950 dark:text-indigo-200 leading-relaxed">
                  {module.learnContent.workplaceContext}
                </p>
              </div>
            </div>
          )}

          {/* STEP 2: EXAMPLE */}
          {currentStep === 'example' && (
            <div className="space-y-6">
              <div>
                <h3 className="text-base font-bold text-slate-900 dark:text-white">
                  {module.example.title}
                </h3>
                <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 mt-1">
                  {module.example.description}
                </p>
              </div>

              {/* Code Snippet if present */}
              {module.example.codeSnippet && (
                <div className="rounded-2xl border border-slate-800 bg-slate-950 p-4 font-mono text-xs text-emerald-400 overflow-x-auto">
                  <pre className="whitespace-pre-wrap">{module.example.codeSnippet}</pre>
                </div>
              )}

              {/* Sample Data Table if present */}
              {module.example.sampleData && (
                <div className="rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-sm">
                  <table className="w-full text-left text-xs border-collapse">
                    <thead className="bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-bold">
                      <tr>
                        {module.example.sampleData.headers.map((h, i) => (
                          <th key={i} className="p-3 border-b border-slate-200 dark:border-slate-700">
                            {h}
                          </th>
                        ))}
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-slate-600 dark:text-slate-300">
                      {module.example.sampleData.rows.map((row, rIdx) => (
                        <tr key={rIdx} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                          {row.map((cell, cIdx) => (
                            <td key={cIdx} className="p-3">
                              {cell}
                            </td>
                          ))}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}

              {/* Key Takeaway */}
              <div className="p-4 rounded-2xl border border-emerald-200 dark:border-emerald-900/60 bg-emerald-50/50 dark:bg-emerald-950/20 flex items-start gap-3">
                <Lightbulb className="w-5 h-5 text-emerald-600 dark:text-emerald-400 shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-xs font-bold text-emerald-900 dark:text-emerald-300 uppercase tracking-wider">
                    Key Practical Takeaway
                  </h4>
                  <p className="text-xs sm:text-sm text-emerald-950 dark:text-emerald-200 font-medium mt-0.5">
                    {module.example.keyTakeaway}
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* STEP 3: PRACTICE */}
          {currentStep === 'practice' && (
            <div className="space-y-6">
              <div>
                <div className="flex items-center gap-2">
                  <span className="px-2.5 py-0.5 rounded-full text-xs font-bold uppercase tracking-wider bg-amber-100 text-amber-800 dark:bg-amber-950/60 dark:text-amber-300">
                    Interactive Practice Check
                  </span>
                </div>
                <h3 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white mt-2">
                  {module.practice.question}
                </h3>
              </div>

              {/* Options */}
              <div className="space-y-2.5">
                {module.practice.options.map((opt, idx) => {
                  const isSelected = selectedPracticeIdx === idx;
                  const isCorrect = idx === module.practice.correctIndex;

                  let cardStyle =
                    'border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 bg-white dark:bg-slate-850';
                  if (practiceSubmitted) {
                    if (isCorrect) {
                      cardStyle =
                        'border-emerald-500 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-900 dark:text-emerald-200 ring-1 ring-emerald-500';
                    } else if (isSelected && !isCorrect) {
                      cardStyle =
                        'border-red-500 bg-red-50 dark:bg-red-950/40 text-red-900 dark:text-red-200 ring-1 ring-red-500';
                    }
                  } else if (isSelected) {
                    cardStyle =
                      'border-orange-500 bg-orange-50/50 dark:bg-orange-950/30 ring-1 ring-orange-500';
                  }

                  return (
                    <button
                      key={idx}
                      onClick={() => !practiceSubmitted && setSelectedPracticeIdx(idx)}
                      disabled={practiceSubmitted}
                      className={`w-full p-4 rounded-xl border text-left text-xs sm:text-sm font-medium transition-all flex items-start gap-3 ${cardStyle}`}
                    >
                      <span className="w-5 h-5 rounded-full border border-current flex items-center justify-center text-[11px] font-bold shrink-0 mt-0.5">
                        {String.fromCharCode(65 + idx)}
                      </span>
                      <span>{opt}</span>
                    </button>
                  );
                })}
              </div>

              {/* Submit Practice Button */}
              {!practiceSubmitted ? (
                <div className="flex items-center justify-between pt-2">
                  <button
                    onClick={() =>
                      onOpenAIWithPrompt(
                        `I'm working on: "${module.practice.question}". Could you give me a subtle hint without revealing the direct answer?`
                      )
                    }
                    className="inline-flex items-center gap-1.5 text-xs text-indigo-600 dark:text-indigo-400 font-bold hover:underline"
                  >
                    <Bot className="w-4 h-4" />
                    <span>Need a hint? Ask Forge AI</span>
                  </button>

                  <button
                    disabled={selectedPracticeIdx === null}
                    onClick={handlePracticeSubmit}
                    className="px-5 py-2.5 rounded-xl bg-orange-600 hover:bg-orange-700 disabled:opacity-40 text-white text-xs font-bold transition-colors shadow-sm"
                  >
                    Verify Answer
                  </button>
                </div>
              ) : (
                <div className="space-y-4 pt-2">
                  <div
                    className={`p-4 rounded-2xl border ${
                      selectedPracticeIdx === module.practice.correctIndex
                        ? 'border-emerald-200 bg-emerald-50 dark:border-emerald-900/60 dark:bg-emerald-950/30'
                        : 'border-amber-200 bg-amber-50 dark:border-amber-900/60 dark:bg-amber-950/30'
                    }`}
                  >
                    <div className="flex items-center gap-2 font-bold text-xs mb-1">
                      {selectedPracticeIdx === module.practice.correctIndex ? (
                        <span className="text-emerald-700 dark:text-emerald-300 flex items-center gap-1">
                          <CheckCircle2 className="w-4 h-4" /> Correct reasoning!
                        </span>
                      ) : (
                        <span className="text-amber-700 dark:text-amber-300 flex items-center gap-1">
                          <AlertCircle className="w-4 h-4" /> Not quite right. Here is why:
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-slate-700 dark:text-slate-300 leading-relaxed">
                      {module.practice.explanation}
                    </p>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* STEP 4: APPLY */}
          {currentStep === 'apply' && (
            <div className="space-y-6">
              <div>
                <div className="flex items-center gap-2">
                  <span className="px-2.5 py-0.5 rounded-full text-xs font-bold uppercase tracking-wider bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300">
                    Real-Life Workplace Task
                  </span>
                </div>
                <h3 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white mt-2">
                  {module.apply.title}
                </h3>
                <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 mt-1 leading-relaxed">
                  {module.apply.scenario}
                </p>
              </div>

              {/* Workspace Input Field */}
              <div className="space-y-2">
                <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
                  <span className="font-semibold">Your Solution / Code / Memo:</span>
                  <button
                    onClick={() =>
                      onOpenAIWithPrompt(
                        `I am working on this real-life task: "${module.apply.scenario}". Can you explain the workplace thought process to approach it?`
                      )
                    }
                    className="inline-flex items-center gap-1 text-indigo-600 dark:text-indigo-400 font-bold hover:underline"
                  >
                    <Bot className="w-3.5 h-3.5" />
                    <span>Ask Forge AI for Guidance</span>
                  </button>
                </div>

                <textarea
                  id="apply-workspace-textarea"
                  rows={6}
                  value={applyInput}
                  onChange={(e) => setApplyInput(e.target.value)}
                  placeholder="Type your query, reasoning, or executive memo here..."
                  className="w-full p-4 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 font-mono text-xs text-slate-900 dark:text-slate-100 focus:ring-2 focus:ring-orange-500 focus:outline-none"
                />
              </div>

              {/* AI Evaluation Button */}
              <div className="flex items-center justify-between">
                <button
                  onClick={() => setApplyInput(module.apply.modelSolution)}
                  className="text-xs text-slate-500 hover:text-slate-900 dark:hover:text-slate-200 underline"
                >
                  View Expert Reference Answer
                </button>

                <button
                  id="evaluate-apply-btn"
                  onClick={handleApplyEvaluate}
                  disabled={evaluatingApply || !applyInput.trim()}
                  className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-orange-600 hover:bg-orange-700 disabled:opacity-40 text-white text-xs font-bold transition-colors shadow-sm"
                >
                  {evaluatingApply ? (
                    <>
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      <span>Evaluating with Forge AI...</span>
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-3.5 h-3.5" />
                      <span>Submit for AI Review</span>
                    </>
                  )}
                </button>
              </div>

              {/* Evaluation Feedback Card */}
              {applyEvaluation && (
                <div className="p-5 rounded-2xl border border-indigo-200 dark:border-indigo-900/60 bg-indigo-50/40 dark:bg-indigo-950/30 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold uppercase tracking-wider text-indigo-900 dark:text-indigo-300">
                      Forge AI Rubric Assessment
                    </span>
                    <span className="text-xs font-black px-2.5 py-1 rounded-full bg-indigo-600 text-white">
                      Score: {applyEvaluation.score}/100
                    </span>
                  </div>

                  <p className="text-xs sm:text-sm text-slate-800 dark:text-slate-200 leading-relaxed font-medium">
                    {applyEvaluation.feedback}
                  </p>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 text-xs">
                    <div>
                      <span className="font-bold text-emerald-700 dark:text-emerald-400 block mb-1">
                        Key Strengths:
                      </span>
                      <ul className="space-y-1">
                        {applyEvaluation.strengths.map((s, idx) => (
                          <li key={idx} className="flex items-center gap-1.5 text-slate-600 dark:text-slate-300">
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                            <span>{s}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div>
                      <span className="font-bold text-amber-700 dark:text-amber-400 block mb-1">
                        Recommendations for Polish:
                      </span>
                      <ul className="space-y-1">
                        {applyEvaluation.improvements.map((imp, idx) => (
                          <li key={idx} className="flex items-center gap-1.5 text-slate-600 dark:text-slate-300">
                            <ArrowRight className="w-3 h-3 text-amber-500 shrink-0" />
                            <span>{imp}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* STEP 5: ASSESS */}
          {currentStep === 'assess' && (
            <div className="space-y-6">
              <div>
                <div className="flex items-center gap-2">
                  <span className="px-2.5 py-0.5 rounded-full text-xs font-bold uppercase tracking-wider bg-purple-100 text-purple-800 dark:bg-purple-950/60 dark:text-purple-300">
                    Knowledge & Judgment Check
                  </span>
                </div>
                <h3 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white mt-2">
                  Validate Practical Comprehension
                </h3>
                <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 mt-1">
                  Answer this workplace scenario question to finalize this module.
                </p>
              </div>

              {module.assessment.questions.map((q) => (
                <div key={q.id} className="space-y-3">
                  <p className="text-xs sm:text-sm font-bold text-slate-900 dark:text-white">
                    {q.prompt}
                  </p>

                  <div className="space-y-2">
                    {q.options.map((opt, optIdx) => {
                      const isSelected = assessmentAnswers[q.id] === optIdx;

                      return (
                        <button
                          key={optIdx}
                          onClick={() =>
                            !assessmentSubmitted &&
                            setAssessmentAnswers((prev) => ({ ...prev, [q.id]: optIdx }))
                          }
                          disabled={assessmentSubmitted}
                          className={`w-full p-3.5 rounded-xl border text-left text-xs font-medium transition-colors flex items-center gap-3 ${
                            isSelected
                              ? 'border-orange-500 bg-orange-50/60 dark:bg-orange-950/30'
                              : 'border-slate-200 dark:border-slate-800 hover:border-slate-300'
                          }`}
                        >
                          <span className="w-4 h-4 rounded-full border border-current flex items-center justify-center text-[10px] font-bold shrink-0">
                            {optIdx + 1}
                          </span>
                          <span>{opt}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              ))}

              <div className="pt-4 flex justify-end">
                <button
                  id="finish-assessment-btn"
                  onClick={handleFinishAssessment}
                  disabled={
                    module.assessment.questions.some((q) => assessmentAnswers[q.id] === undefined) ||
                    assessmentSubmitted
                  }
                  className="px-6 py-2.5 rounded-xl bg-orange-600 hover:bg-orange-700 disabled:opacity-40 text-white text-xs font-bold transition-colors shadow-sm"
                >
                  {assessmentSubmitted ? 'Evaluating...' : 'Complete Module & Record Progress'}
                </button>
              </div>
            </div>
          )}

          {/* STEP 6: RESULT & CELEBRATION */}
          {currentStep === 'result' && (
            <div className="text-center py-8 space-y-6">
              <div className="w-16 h-16 rounded-3xl bg-gradient-to-tr from-amber-400 via-orange-500 to-red-500 text-white flex items-center justify-center mx-auto shadow-lg shadow-orange-500/20 animate-bounce">
                <Award className="w-8 h-8" />
              </div>

              <div>
                <span className="text-xs font-bold uppercase tracking-wider text-orange-600 dark:text-orange-400">
                  Module Completed!
                </span>
                <h3 className="text-2xl font-black text-slate-900 dark:text-white mt-1">
                  Practical Skill Forged
                </h3>
                <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 max-w-md mx-auto mt-2">
                  You successfully completed <strong className="text-slate-800 dark:text-slate-200">{module.title}</strong> and earned practical workplace competency.
                </p>
              </div>

              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-emerald-100 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300 text-sm font-extrabold">
                <Sparkles className="w-4 h-4" />
                <span>+50 XP Earned</span>
              </div>

              <div className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-850 max-w-md mx-auto text-left space-y-2">
                <span className="text-[11px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                  Demonstrated Capability:
                </span>
                <p className="text-xs text-slate-800 dark:text-slate-200 font-medium">
                  ✓ {module.goal}
                </p>
              </div>

              <div className="pt-4 flex flex-col sm:flex-row items-center justify-center gap-3">
                <button
                  id="result-close-btn"
                  onClick={onClose}
                  className="w-full sm:w-auto px-6 py-2.5 rounded-xl bg-orange-600 hover:bg-orange-700 text-white text-xs font-bold transition-colors shadow-sm"
                >
                  Return to Dashboard & Skill Tree
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Modal Bottom Footer Navigation */}
        {currentStep !== 'result' && (
          <div className="p-4 sm:p-6 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between gap-4 bg-slate-50/50 dark:bg-slate-850">
            {currentStep === 'learn' ? (
              <div />
            ) : (
              <button
                onClick={() => {
                  const idx = stepsList.findIndex((s) => s.id === currentStep);
                  if (idx > 0) setCurrentStep(stepsList[idx - 1].id as any);
                }}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-800"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                <span>Previous</span>
              </button>
            )}

            {currentStep !== 'assess' && (
              <button
                id="modal-next-step-btn"
                onClick={() => {
                  const idx = stepsList.findIndex((s) => s.id === currentStep);
                  if (idx < stepsList.length - 1) {
                    setCurrentStep(stepsList[idx + 1].id as any);
                  }
                }}
                className="inline-flex items-center gap-1.5 px-5 py-2.5 rounded-xl bg-slate-900 dark:bg-white hover:bg-slate-800 dark:hover:bg-slate-100 text-white dark:text-slate-900 text-xs font-bold transition-colors shadow-sm"
              >
                <span>Next Step</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
