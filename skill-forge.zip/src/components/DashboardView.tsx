import React from 'react';
import {
  Flame,
  ArrowRight,
  Play,
  CheckCircle2,
  Sparkles,
  Compass,
  GitFork,
  Target,
  Bot,
  AlertTriangle,
  Award,
  ChevronRight,
  BarChart2,
  Briefcase,
  Zap,
} from 'lucide-react';
import { UserProfile, DailyChallenge } from '../types';
import { getCareerById } from '../data/allCareers';
import { DAILY_CHALLENGES } from '../data/challenges';

interface DashboardViewProps {
  profile: UserProfile;
  setCurrentTab: (tab: string) => void;
  onOpenModule: (moduleId: string) => void;
  onOpenChallenge: (challenge: DailyChallenge) => void;
  onOpenAIWithPrompt: (prompt: string) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  profile,
  setCurrentTab,
  onOpenModule,
  onOpenChallenge,
  onOpenAIWithPrompt,
}) => {
  const career = getCareerById(profile.selectedCareerId);
  const todaysChallenge = DAILY_CHALLENGES[0];

  // Calculate overall career progress
  const allModules = career.skillTree.flatMap((s) => s.modules);
  const totalModulesCount = allModules.length || 1;
  const completedCount = allModules.filter((m) =>
    profile.completedModuleIds.includes(m.id)
  ).length;
  const progressPercent = Math.round((completedCount / totalModulesCount) * 100);

  // Find next module to continue
  const nextModule =
    allModules.find((m) => !profile.completedModuleIds.includes(m.id)) ||
    allModules[0];
  const nextSkill = career.skillTree.find((s) =>
    s.modules.some((m) => m.id === nextModule?.id)
  );

  // Time-of-day greeting
  const hour = new Date().getHours();
  const greeting =
    hour < 12 ? 'Good morning' : hour < 18 ? 'Good afternoon' : 'Good evening';

  return (
    <div id="dashboard-view" className="space-y-8 pb-16">
      {/* Top Welcome Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-6">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight">
              {greeting}, {profile.name}! 👋
            </h1>
          </div>
          <p className="text-sm sm:text-base text-slate-600 dark:text-slate-400 mt-1 max-w-2xl">
            Welcome back to your career forge. Focus on real-world capabilities today:
            <span className="font-semibold text-slate-800 dark:text-slate-200 ml-1">
              Learn → Practice → Apply → Assess → Build → Demonstrate
            </span>
            .
          </p>
        </div>

        {/* Action button to switch/explore career */}
        <div className="flex items-center gap-3">
          <button
            id="explore-all-careers-btn"
            onClick={() => setCurrentTab('careers')}
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-700/60 font-semibold text-sm transition-all shadow-sm"
          >
            <Compass className="w-4 h-4 text-orange-500" />
            <span>Switch Career Path</span>
          </button>

          <button
            id="view-skill-tree-btn"
            onClick={() => setCurrentTab('skills')}
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-orange-600 hover:bg-orange-700 text-white font-semibold text-sm transition-all shadow-sm shadow-orange-500/20"
          >
            <GitFork className="w-4 h-4" />
            <span>View Skill Tree</span>
          </button>
        </div>
      </div>

      {/* Weak Areas / Personalized Booster Alert (if user has any recorded weak spots) */}
      {profile.weakAreas.length > 0 && (
        <div
          id="personalization-booster-card"
          className="rounded-2xl p-5 border border-amber-200 dark:border-amber-800/70 bg-gradient-to-r from-amber-50/80 via-orange-50/40 to-white dark:from-amber-950/30 dark:via-slate-900 dark:to-slate-900 shadow-sm"
        >
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="flex items-start gap-3.5">
              <div className="w-10 h-10 rounded-xl bg-amber-100 dark:bg-amber-900/60 text-amber-600 dark:text-amber-400 flex items-center justify-center shrink-0 mt-0.5">
                <AlertTriangle className="w-5 h-5" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold uppercase tracking-wider text-amber-700 dark:text-amber-300">
                    Forge AI Adaptive Practice
                  </span>
                </div>
                <h4 className="text-sm font-bold text-slate-900 dark:text-white mt-0.5">
                  Targeted Revision: {profile.weakAreas[0].topic}
                </h4>
                <p className="text-xs text-slate-600 dark:text-slate-400 mt-1">
                  You had difficulty with this concept in recent assessments. Let's do a short 3-minute
                  practice question with Forge AI before continuing.
                </p>
              </div>
            </div>

            <button
              id="start-booster-btn"
              onClick={() =>
                onOpenAIWithPrompt(
                  `I've been struggling with "${profile.weakAreas[0].topic}". Can you give me a friendly 2-minute workplace example and a quick practice question to test my understanding?`
                )
              }
              className="inline-flex items-center justify-center gap-2 px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold shadow-sm whitespace-nowrap transition-colors"
            >
              <Zap className="w-3.5 h-3.5" />
              <span>Start 3-Min Booster</span>
            </button>
          </div>
        </div>
      )}

      {/* Primary Dashboard Bento Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Card 1: Active Career Path Progress */}
        <div
          id="career-path-progress-card"
          className="lg:col-span-2 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-850 p-6 shadow-sm relative overflow-hidden"
        >
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-5">
            <div>
              <div className="flex items-center gap-2">
                <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold tracking-wide uppercase bg-orange-100 dark:bg-orange-950/60 text-orange-700 dark:text-orange-300">
                  🎯 Active Career Path
                </span>
                <span className="text-xs text-slate-500 dark:text-slate-400">
                  {career.category}
                </span>
              </div>
              <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white mt-1">
                {career.title}
              </h2>
              <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 mt-0.5">
                {career.tagline}
              </p>
            </div>

            <div className="text-right">
              <span className="text-3xl font-black text-orange-600 dark:text-orange-400">
                {progressPercent}%
              </span>
              <p className="text-[11px] font-semibold text-slate-500 dark:text-slate-400">
                Path Completion
              </p>
            </div>
          </div>

          {/* Progress Bar */}
          <div className="w-full bg-slate-100 dark:bg-slate-800 rounded-full h-3 overflow-hidden p-0.5 mb-6">
            <div
              className="bg-gradient-to-r from-orange-500 to-amber-500 h-2 rounded-full transition-all duration-700 ease-out"
              style={{ width: `${Math.max(progressPercent, 6)}%` }}
            />
          </div>

          {/* Continue Learning Prompt */}
          <div className="rounded-xl border border-orange-200/70 dark:border-orange-900/40 bg-orange-50/50 dark:bg-orange-950/20 p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="space-y-1">
              <div className="flex items-center gap-2 text-xs font-bold text-orange-800 dark:text-orange-300">
                <Play className="w-3.5 h-3.5 fill-orange-600 text-orange-600" />
                <span>CONTINUE LEARNING</span>
              </div>
              <h3 className="text-base font-bold text-slate-900 dark:text-white">
                {nextSkill?.title || 'Core Skills'} — {nextModule?.title || 'Next Activity'}
              </h3>
              <p className="text-xs text-slate-600 dark:text-slate-400 line-clamp-1">
                {nextModule?.goal || 'Develop practical career competency.'}
              </p>
            </div>

            {nextModule && (
              <button
                id="resume-learning-btn"
                onClick={() => onOpenModule(nextModule.id)}
                className="inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl bg-orange-600 hover:bg-orange-700 text-white font-bold text-sm shadow-sm hover:shadow-md transition-all shrink-0"
              >
                <span>Resume (15 min)</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* Core Skills Snapshot */}
          <div className="mt-6 pt-5 border-t border-slate-100 dark:border-slate-800">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-3">
              Core Skills in this Path
            </h4>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              {career.coreSkills.slice(0, 6).map((skill, idx) => {
                const isCompleted = profile.completedSkillIds.includes(
                  career.skillTree[idx]?.id || ''
                );
                return (
                  <div
                    key={skill.name}
                    className="p-2.5 rounded-lg border border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900/50 text-left"
                  >
                    <div className="flex items-center justify-between gap-1 mb-1">
                      <span className="text-xs font-semibold text-slate-800 dark:text-slate-200 truncate">
                        {skill.name}
                      </span>
                      {isCompleted && (
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                      )}
                    </div>
                    <div className="w-full bg-slate-200 dark:bg-slate-700 h-1.5 rounded-full overflow-hidden">
                      <div
                        className="bg-orange-500 h-full rounded-full"
                        style={{ width: `${skill.proficiencyTarget}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Card 2: Streak & Gamification Summary */}
        <div className="space-y-6">
          {/* Daily Streak Card */}
          <div
            id="streak-summary-card"
            className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-850 p-6 shadow-sm"
          >
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-xl bg-amber-100 dark:bg-amber-950/60 flex items-center justify-center text-amber-500">
                  <Flame className="w-6 h-6 fill-amber-500" />
                </div>
                <div>
                  <h3 className="text-base font-extrabold text-slate-900 dark:text-white">
                    {profile.streakDays} Day Streak!
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    Active practice builds muscle memory
                  </p>
                </div>
              </div>
            </div>

            {/* Streak day indicators */}
            <div className="grid grid-cols-7 gap-1.5 text-center mt-3">
              {['M', 'T', 'W', 'T', 'F', 'S', 'S'].map((day, i) => (
                <div key={i} className="flex flex-col items-center gap-1">
                  <div
                    className={`w-7 h-7 rounded-lg flex items-center justify-center text-[11px] font-bold ${
                      i < 6
                        ? 'bg-amber-500 text-white'
                        : i === 6
                        ? 'bg-orange-600 text-white ring-2 ring-orange-400'
                        : 'bg-slate-100 dark:bg-slate-800 text-slate-400'
                    }`}
                  >
                    {i < 6 ? '✓' : '🔥'}
                  </div>
                  <span className="text-[10px] text-slate-500 font-medium">{day}</span>
                </div>
              ))}
            </div>

            <div className="mt-4 pt-4 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs">
              <span className="text-slate-600 dark:text-slate-400">Total XP</span>
              <span className="font-extrabold text-slate-900 dark:text-white">
                {profile.xp} XP (Level {profile.level})
              </span>
            </div>
          </div>

          {/* Card 3: Today's Practical Challenge */}
          <div
            id="todays-challenge-card"
            className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-gradient-to-br from-indigo-900 to-slate-900 text-white p-6 shadow-sm relative overflow-hidden"
          >
            <div className="flex items-center gap-2 mb-2">
              <Target className="w-4 h-4 text-indigo-400" />
              <span className="text-xs font-bold tracking-wider uppercase text-indigo-300">
                Today's Workplace Challenge
              </span>
            </div>

            <h3 className="text-base font-bold leading-snug">
              {todaysChallenge.title.replace("Today's Practical Challenge: ", '')}
            </h3>
            <p className="text-xs text-slate-300 mt-2 line-clamp-2">
              {todaysChallenge.prompt}
            </p>

            <div className="mt-4 flex items-center justify-between pt-3 border-t border-indigo-800/60">
              <span className="text-xs font-bold text-amber-300">
                +{todaysChallenge.xpReward} XP Reward
              </span>

              <button
                id="start-todays-challenge-btn"
                onClick={() => onOpenChallenge(todaysChallenge)}
                className="px-3.5 py-1.5 rounded-lg bg-indigo-500 hover:bg-indigo-600 text-white text-xs font-bold transition-colors shadow-sm"
              >
                Start Challenge
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* The 6-Step Career Engine: Learn -> Practice -> Apply -> Assess -> Build -> Demonstrate */}
      <div
        id="core-philosophy-banner"
        className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-850 p-6 shadow-sm"
      >
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
          <div>
            <h3 className="text-lg font-black text-slate-900 dark:text-white tracking-tight">
              The Skill Forge Method
            </h3>
            <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400">
              Don’t just collect certificates. Build concrete capabilities that solve real workplace problems.
            </p>
          </div>

          <button
            onClick={() => setCurrentTab('challenges')}
            className="text-xs font-bold text-orange-600 dark:text-orange-400 hover:underline flex items-center gap-1 self-start md:self-auto"
          >
            <span>Explore Projects & Portfolio</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
          {[
            {
              step: '1. Learn',
              desc: 'Short 10-20 min workplace concepts',
              color: 'border-blue-200 bg-blue-50/50 text-blue-900 dark:bg-blue-950/30 dark:border-blue-900/40 dark:text-blue-200',
            },
            {
              step: '2. Practice',
              desc: 'Interactive scenario checks with hints',
              color: 'border-amber-200 bg-amber-50/50 text-amber-900 dark:bg-amber-950/30 dark:border-amber-900/40 dark:text-amber-200',
            },
            {
              step: '3. Apply',
              desc: 'Real business tasks & case studies',
              color: 'border-emerald-200 bg-emerald-50/50 text-emerald-900 dark:bg-emerald-950/30 dark:border-emerald-900/40 dark:text-emerald-200',
            },
            {
              step: '4. Assess',
              desc: 'Practical evaluations & decisions',
              color: 'border-indigo-200 bg-indigo-50/50 text-indigo-900 dark:bg-indigo-950/30 dark:border-indigo-900/40 dark:text-indigo-200',
            },
            {
              step: '5. Build',
              desc: 'Simulated multi-step projects',
              color: 'border-purple-200 bg-purple-50/50 text-purple-900 dark:bg-purple-950/30 dark:border-purple-900/40 dark:text-purple-200',
            },
            {
              step: '6. Demonstrate',
              desc: 'Verified portfolio artifacts',
              color: 'border-orange-200 bg-orange-50/50 text-orange-900 dark:bg-orange-950/30 dark:border-orange-900/40 dark:text-orange-200',
            },
          ].map((item) => (
            <div
              key={item.step}
              className={`p-3.5 rounded-xl border ${item.color} flex flex-col justify-between`}
            >
              <span className="font-extrabold text-xs">{item.step}</span>
              <p className="text-[11px] opacity-80 mt-1 leading-snug">{item.desc}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Quick Launch Shortcuts: Forge AI Assistant & Portfolio */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Forge AI Quick Mentor Box */}
        <div
          id="forge-ai-quick-box"
          className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-850 p-6 shadow-sm flex flex-col justify-between"
        >
          <div>
            <div className="flex items-center gap-2.5 mb-2">
              <div className="w-8 h-8 rounded-lg bg-indigo-100 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center">
                <Bot className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-bold text-slate-900 dark:text-white text-base">
                  Forge AI Career Mentor
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Ready to explain concepts, suggest business examples, or give hints.
                </p>
              </div>
            </div>

            <div className="mt-4 flex flex-wrap gap-2">
              {[
                'Explain SQL joins simply',
                'Give me a real business example',
                'What skills am I missing for this career?',
                'I need a hint on my current task',
              ].map((prompt) => (
                <button
                  key={prompt}
                  onClick={() => onOpenAIWithPrompt(prompt)}
                  className="text-xs px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/70 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 font-medium transition-colors text-left"
                >
                  "{prompt}"
                </button>
              ))}
            </div>
          </div>

          <button
            id="open-full-ai-btn"
            onClick={() => setCurrentTab('forge-ai')}
            className="mt-5 inline-flex items-center gap-1.5 text-xs font-bold text-indigo-600 dark:text-indigo-400 hover:underline"
          >
            <span>Open Dedicated Forge AI Interface</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Portfolio & Career Readiness Snapshot */}
        <div
          id="readiness-snapshot-box"
          className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-850 p-6 shadow-sm flex flex-col justify-between"
        >
          <div>
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Award className="w-5 h-5 text-orange-500" />
                <h3 className="font-bold text-slate-900 dark:text-white text-base">
                  Career Readiness Guidance
                </h3>
              </div>
              <span className="text-xs font-bold px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300">
                {profile.completedProjects.length} Verified Project
              </span>
            </div>

            <p className="text-xs text-slate-600 dark:text-slate-400 mb-4">
              Progress indicator measuring skill acquisition, applied tasks, and portfolio projects.
              <span className="block text-[11px] text-slate-400 dark:text-slate-500 italic mt-0.5">
                (Learning progress guidance only — not an employment guarantee).
              </span>
            </p>

            <div className="space-y-2">
              {[
                { label: 'Core Skills', pct: 80 },
                { label: 'Practical Work & Case Studies', pct: 60 },
                { label: 'Demonstrated Projects', pct: 70 },
                { label: 'Assessments Passed', pct: 80 },
              ].map((m) => (
                <div key={m.label} className="text-xs">
                  <div className="flex justify-between font-medium text-slate-700 dark:text-slate-300 mb-1">
                    <span>{m.label}</span>
                    <span className="font-bold">{m.pct}%</span>
                  </div>
                  <div className="w-full bg-slate-100 dark:bg-slate-800 h-1.5 rounded-full overflow-hidden">
                    <div
                      className="bg-orange-500 h-full rounded-full"
                      style={{ width: `${m.pct}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

          <button
            id="view-full-profile-btn"
            onClick={() => setCurrentTab('profile')}
            className="mt-5 inline-flex items-center gap-1.5 text-xs font-bold text-orange-600 dark:text-orange-400 hover:underline"
          >
            <span>View Full Profile & Portfolio</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
};
