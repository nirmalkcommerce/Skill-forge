import React, { useState } from 'react';
import {
  Lock,
  CheckCircle2,
  Award,
  Play,
  Clock,
  Sparkles,
  ArrowRight,
  ShieldAlert,
  ChevronRight,
  X,
  Target,
} from 'lucide-react';
import { Career, SkillNode, UserProfile } from '../types';
import { ALL_CAREERS, getCareerById } from '../data/allCareers';
import { DynamicIcon } from './Icon';

interface SkillTreeViewProps {
  profile: UserProfile;
  selectedCareerId: string;
  onSelectCareer: (id: string) => void;
  onOpenModule: (moduleId: string) => void;
  onDemonstrateSkill: (skillId: string) => void;
}

export const SkillTreeView: React.FC<SkillTreeViewProps> = ({
  profile,
  selectedCareerId,
  onSelectCareer,
  onOpenModule,
  onDemonstrateSkill,
}) => {
  const currentCareer = getCareerById(selectedCareerId);
  const [selectedNode, setSelectedNode] = useState<SkillNode | null>(null);

  // Group nodes by category
  const categories = [
    { id: 'foundation', label: '1. Foundation Skills', desc: 'Core logic, syntax, and essential workplace fundamentals' },
    { id: 'core', label: '2. Core Professional Skills', desc: 'Daily execution tools, frameworks, and domain expertise' },
    { id: 'specialized', label: '3. Specialized & Advanced Skills', desc: 'Complex problem-solving, optimization, and architecture' },
    { id: 'applied', label: '4. Applied Workplace Integration', desc: 'Cross-functional delivery, storytelling, and leadership' },
  ];

  const getNodeStatus = (node: SkillNode) => {
    const isDemonstrated = profile.demonstratedSkillIds.includes(node.id);
    if (isDemonstrated) return 'demonstrated';

    const allModuleIds = node.modules.map((m) => m.id);
    const completedCount = allModuleIds.filter((id) => profile.completedModuleIds.includes(id)).length;

    if (completedCount === allModuleIds.length && allModuleIds.length > 0) {
      return 'completed';
    }

    if (completedCount > 0) {
      return 'in-progress';
    }

    // Check prerequisites
    const prereqsMet = node.prerequisites.every((reqId) =>
      profile.completedSkillIds.includes(reqId)
    );

    if (!prereqsMet && node.prerequisites.length > 0) {
      return 'locked';
    }

    return 'not-started';
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'demonstrated':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-amber-100 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300">
            <Award className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400" />
            Demonstrated 🏆
          </span>
        );
      case 'completed':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-emerald-100 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
            Completed
          </span>
        );
      case 'in-progress':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-blue-100 dark:bg-blue-950/60 text-blue-800 dark:text-blue-300">
            In Progress
          </span>
        );
      case 'locked':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400">
            <Lock className="w-3 h-3" />
            Locked
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300">
            Ready to Start
          </span>
        );
    }
  };

  return (
    <div id="skill-tree-view" className="space-y-8 pb-16">
      {/* Header & Career Switcher */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-6">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold uppercase tracking-wider bg-orange-100 dark:bg-orange-950/60 text-orange-700 dark:text-orange-300">
              Interactive Skill Tree
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight mt-1">
            {currentCareer.title} Progression
          </h1>
          <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 mt-1 max-w-2xl">
            Progress from fundamental building blocks to specialized workplace applications. Click any
            skill node to view bite-sized modules or demonstrate real-world competence.
          </p>
        </div>

        {/* Career Selector Dropdown */}
        <div className="flex items-center gap-2">
          <label className="text-xs font-bold text-slate-500 dark:text-slate-400 shrink-0">
            Path:
          </label>
          <select
            id="skill-tree-career-select"
            value={selectedCareerId}
            onChange={(e) => onSelectCareer(e.target.value)}
            className="px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-900 dark:text-white text-xs font-bold focus:ring-2 focus:ring-orange-500 focus:outline-none"
          >
            {ALL_CAREERS.map((c) => (
              <option key={c.id} value={c.id}>
                {c.title}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Legend */}
      <div
        id="skill-tree-legend"
        className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-850 flex flex-wrap items-center justify-between gap-3 text-xs"
      >
        <span className="font-bold text-slate-600 dark:text-slate-400">Node Legend:</span>
        <div className="flex flex-wrap items-center gap-3">
          <span className="flex items-center gap-1.5 text-slate-500">
            <Lock className="w-3.5 h-3.5" /> 🔒 Locked
          </span>
          <span className="flex items-center gap-1.5 text-slate-600 dark:text-slate-300">
            ⚪ Not Started
          </span>
          <span className="flex items-center gap-1.5 text-blue-600 dark:text-blue-400">
            🔵 In Progress
          </span>
          <span className="flex items-center gap-1.5 text-emerald-600 dark:text-emerald-400">
            🟢 Completed
          </span>
          <span className="flex items-center gap-1.5 text-amber-600 dark:text-amber-400 font-bold">
            🏆 Demonstrated (Real-world Proof)
          </span>
        </div>
      </div>

      {/* Structured Progression Tiers */}
      <div className="space-y-8">
        {categories.map((tier) => {
          const nodesInTier = currentCareer.skillTree.filter((n) => n.category === tier.id);
          if (nodesInTier.length === 0) return null;

          return (
            <div key={tier.id} className="space-y-4">
              <div>
                <h3 className="text-base font-extrabold text-slate-900 dark:text-white">
                  {tier.label}
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">{tier.desc}</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {nodesInTier.map((node) => {
                  const status = getNodeStatus(node);
                  const isLocked = status === 'locked';

                  return (
                    <div
                      key={node.id}
                      id={`skill-node-${node.id}`}
                      onClick={() => !isLocked && setSelectedNode(node)}
                      className={`rounded-2xl border p-5 transition-all relative ${
                        isLocked
                          ? 'border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-900/40 opacity-60 cursor-not-allowed'
                          : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-850 hover:border-orange-500/80 hover:shadow-md cursor-pointer group'
                      }`}
                    >
                      <div className="flex items-start justify-between gap-3 mb-3">
                        <div
                          className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                            status === 'demonstrated'
                              ? 'bg-amber-100 text-amber-600 dark:bg-amber-950/60 dark:text-amber-400'
                              : status === 'completed'
                              ? 'bg-emerald-100 text-emerald-600 dark:bg-emerald-950/60 dark:text-emerald-400'
                              : 'bg-orange-50 text-orange-600 dark:bg-orange-950/60 dark:text-orange-400'
                          }`}
                        >
                          <DynamicIcon name={node.icon} className="w-5 h-5" />
                        </div>

                        {getStatusBadge(status)}
                      </div>

                      <h4 className="text-sm font-bold text-slate-900 dark:text-white group-hover:text-orange-600 dark:group-hover:text-orange-400 transition-colors">
                        {node.title}
                      </h4>
                      <p className="text-xs text-slate-600 dark:text-slate-400 mt-1 line-clamp-2">
                        {node.shortDesc}
                      </p>

                      <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs text-slate-500">
                        <span className="flex items-center gap-1">
                          <Clock className="w-3.5 h-3.5" />
                          {node.estimatedMinutes} min
                        </span>

                        <span className="font-semibold text-slate-700 dark:text-slate-300">
                          {node.modules.length} {node.modules.length === 1 ? 'Module' : 'Modules'}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>

      {/* Skill Node Drawer / Modal */}
      {selectedNode && (
        <div
          id="skill-node-modal"
          className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto"
        >
          <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 max-w-xl w-full max-h-[90vh] overflow-y-auto shadow-2xl p-6 sm:p-8 space-y-6">
            <div className="flex items-start justify-between gap-4">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-orange-100 dark:bg-orange-950/60 text-orange-600 dark:text-orange-400 flex items-center justify-center">
                  <DynamicIcon name={selectedNode.icon} className="w-6 h-6" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    {getStatusBadge(getNodeStatus(selectedNode))}
                  </div>
                  <h3 className="text-xl font-black text-slate-900 dark:text-white mt-1">
                    {selectedNode.title}
                  </h3>
                </div>
              </div>

              <button
                id="close-node-modal-btn"
                onClick={() => setSelectedNode(null)}
                className="p-2 rounded-xl text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 leading-relaxed">
              {selectedNode.shortDesc}
            </p>

            {/* Modules List */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                  Interactive Learning Modules
                </h4>
                <span className="text-xs text-slate-400">
                  {selectedNode.modules.length} Available
                </span>
              </div>

              <div className="space-y-2">
                {selectedNode.modules.map((mod, idx) => {
                  const isDone = profile.completedModuleIds.includes(mod.id);

                  return (
                    <div
                      key={mod.id}
                      className="p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50 flex items-center justify-between gap-3"
                    >
                      <div className="space-y-0.5">
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-bold text-slate-900 dark:text-white">
                            Module {idx + 1}: {mod.title}
                          </span>
                          {isDone && (
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                          )}
                        </div>
                        <p className="text-[11px] text-slate-500 dark:text-slate-400 line-clamp-1">
                          Goal: {mod.goal}
                        </p>
                      </div>

                      <button
                        id={`launch-module-${mod.id}`}
                        onClick={() => {
                          onOpenModule(mod.id);
                          setSelectedNode(null);
                        }}
                        className={`px-3 py-1.5 rounded-lg text-xs font-bold shrink-0 transition-colors ${
                          isDone
                            ? 'bg-slate-200 dark:bg-slate-700 text-slate-800 dark:text-slate-200 hover:bg-slate-300'
                            : 'bg-orange-600 hover:bg-orange-700 text-white shadow-sm'
                        }`}
                      >
                        {isDone ? 'Review' : 'Start (15m)'}
                      </button>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Demonstrate Skill Prompt (Earn 🏆 Demonstrated) */}
            <div className="p-4 rounded-2xl border border-amber-200 dark:border-amber-900/60 bg-amber-50/50 dark:bg-amber-950/20 space-y-2">
              <div className="flex items-center gap-2">
                <Award className="w-4 h-4 text-amber-600 dark:text-amber-400" />
                <h4 className="text-xs font-bold uppercase tracking-wider text-amber-900 dark:text-amber-300">
                  Demonstrate Skill (Earn 🏆 Badge)
                </h4>
              </div>
              <p className="text-xs text-amber-800 dark:text-amber-400">
                Prove you can apply this skill to an unassisted workplace scenario to earn the
                Demonstrated badge on your profile and portfolio.
              </p>

              <button
                id="demonstrate-skill-btn"
                onClick={() => {
                  onDemonstrateSkill(selectedNode.id);
                  setSelectedNode(null);
                }}
                className="mt-2 w-full py-2 px-4 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold transition-colors shadow-sm text-center"
              >
                Take Practical Skill Demonstration
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
