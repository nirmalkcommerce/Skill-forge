import React, { useState, useRef, useEffect } from 'react';
import {
  Bot,
  Send,
  Sparkles,
  HelpCircle,
  Lightbulb,
  Compass,
  Zap,
  RefreshCw,
  User,
  ShieldAlert,
} from 'lucide-react';
import { UserProfile, ChatMessage } from '../types';
import { getCareerById } from '../data/allCareers';

interface ForgeAIPanelProps {
  profile: UserProfile;
  initialPrompt?: string;
  onClearInitialPrompt?: () => void;
}

export const ForgeAIPanel: React.FC<ForgeAIPanelProps> = ({
  profile,
  initialPrompt,
  onClearInitialPrompt,
}) => {
  const career = getCareerById(profile.selectedCareerId);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome-1',
      role: 'assistant',
      content: `Hello ${profile.name}! I'm **Forge AI**, your personalized career mentor for **${career.title}**.

I help you build practical workplace abilities:
- 💡 **Explain workplace concepts** with clear, real-world analogies
- 🏢 **Provide realistic business examples** and case studies
- 🔍 **Give hints on exercises** without spoiling solutions
- 🎯 **Diagnose weak spots** and suggest 2-minute booster drills

What would you like to explore or practice right now?`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, loading]);

  useEffect(() => {
    if (initialPrompt) {
      handleSendMessage(initialPrompt);
      if (onClearInitialPrompt) onClearInitialPrompt();
    }
  }, [initialPrompt]);

  const handleSendMessage = async (textToSend?: string) => {
    const query = textToSend || input;
    if (!query.trim() || loading) return;

    const userMsg: ChatMessage = {
      id: 'user-' + Date.now(),
      role: 'user',
      content: query.trim(),
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    if (!textToSend) setInput('');
    setLoading(true);

    try {
      const response = await fetch('/api/forge-ai/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: query.trim(),
          careerTrack: career.title,
          userLevel: profile.level,
          weakAreas: profile.weakAreas.map((w) => w.topic),
          completedModulesCount: profile.completedModuleIds.length,
          context: `Active career is ${career.title}. User has completed ${profile.completedModuleIds.length} modules. Focus on workplace practical capability and socratic guidance.`,
        }),
      });

      if (!response.ok) {
        throw new Error('AI service responded with error');
      }

      const data = await response.json();
      const assistantMsg: ChatMessage = {
        id: 'ai-' + Date.now(),
        role: 'assistant',
        content: data.reply,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      setMessages((prev) => [...prev, assistantMsg]);
    } catch (err) {
      console.warn('Using client-side fallback for Forge AI', err);
      // Fallback response with helpful Socratic guidance
      let fallbackText = `Here is how to think about this in a real workplace setting:

1. **The Business Problem**: Identify the core metric or stakeholder outcome that needs attention.
2. **First Principles**: Break the requirement down into simple steps (inputs, filtering conditions, and expected deliverables).
3. **Common Pitfall**: Avoid jumping straight to complex formulas or code before testing your basic assumptions with a tiny sample.

Would you like to try writing a 2-line draft so we can review it together?`;

      if (query.toLowerCase().includes('sql') || query.toLowerCase().includes('join')) {
        fallbackText = `In SQL, think of a **JOIN** like matching two sheets of paper with a paperclip based on an identical ID:

- **INNER JOIN**: Only keeps rows where both tables have an exact match.
- **LEFT JOIN**: Keeps all rows from your primary table, even if the secondary table has no matching data (filling gaps with NULL).

*Workplace Scenario*: If you need a list of all customers and any orders they placed this month (including customers who haven't bought anything yet), which join would you use?`;
      } else if (query.toLowerCase().includes('weak') || query.toLowerCase().includes('revise')) {
        fallbackText = `Based on your recent practice sessions, your main revision priority is **${
          profile.weakAreas[0]?.topic || 'Three-valued logic & NULL comparisons'
        }**.

Here is a 1-minute scenario:
A customer registered their account yesterday, but their \`last_purchase_date\` is NULL.
If you run \`WHERE last_purchase_date < '2026-01-01'\`, will this customer show up in your results? Why or why not?`;
      }

      const assistantMsg: ChatMessage = {
        id: 'ai-' + Date.now(),
        role: 'assistant',
        content: fallbackText,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages((prev) => [...prev, assistantMsg]);
    } finally {
      setLoading(false);
    }
  };

  const quickChips = [
    'Explain in simple terms',
    'Give me a real business example',
    'I am stuck on this task — give me a hint',
    'Give me a 2-minute practice question',
    'What skills am I missing for this career?',
    'What should I revise today?',
  ];

  return (
    <div id="forge-ai-view" className="space-y-6 pb-16">
      {/* Top Context Bar */}
      <div
        id="forge-ai-context-bar"
        className="rounded-2xl border border-indigo-200 dark:border-indigo-900/60 bg-gradient-to-r from-indigo-50/70 via-slate-50 to-white dark:from-indigo-950/40 dark:via-slate-900 dark:to-slate-900 p-4 sm:p-5 shadow-sm"
      >
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-600 text-white flex items-center justify-center shadow-sm shadow-indigo-500/30">
              <Bot className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-extrabold text-slate-900 dark:text-white">
                  Forge AI Career Mentor
                </h2>
                <span className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-indigo-100 text-indigo-800 dark:bg-indigo-950 dark:text-indigo-300">
                  Active Context
                </span>
              </div>
              <p className="text-xs text-slate-600 dark:text-slate-400 mt-0.5">
                Path: <strong className="text-slate-800 dark:text-slate-200">{career.title}</strong>{' '}
                • Level {profile.level} ({profile.xp} XP) • {profile.completedModuleIds.length} Modules
                Completed
              </p>
            </div>
          </div>

          {profile.weakAreas.length > 0 && (
            <div className="text-xs text-slate-500 dark:text-slate-400 bg-white dark:bg-slate-850 px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-800">
              <span className="font-bold text-amber-600 dark:text-amber-400">Target Area:</span>{' '}
              {profile.weakAreas[0].topic}
            </div>
          )}
        </div>
      </div>

      {/* Chat Container */}
      <div
        id="forge-ai-chat-card"
        className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-850 shadow-sm flex flex-col h-[650px] overflow-hidden"
      >
        {/* Messages List */}
        <div className="flex-1 p-4 sm:p-6 overflow-y-auto space-y-4">
          {messages.map((msg) => {
            const isUser = msg.role === 'user';

            return (
              <div
                key={msg.id}
                className={`flex items-start gap-3 ${isUser ? 'flex-row-reverse' : 'flex-row'}`}
              >
                <div
                  className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 ${
                    isUser
                      ? 'bg-slate-900 dark:bg-white text-white dark:text-slate-900 text-xs font-bold'
                      : 'bg-indigo-600 text-white'
                  }`}
                >
                  {isUser ? profile.name[0] : <Bot className="w-4 h-4" />}
                </div>

                <div
                  className={`max-w-[85%] sm:max-w-[75%] rounded-2xl p-4 text-xs sm:text-sm leading-relaxed ${
                    isUser
                      ? 'bg-orange-600 text-white rounded-tr-none shadow-sm'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-200 rounded-tl-none border border-slate-200/60 dark:border-slate-700/60'
                  }`}
                >
                  <div className="whitespace-pre-wrap">{msg.content}</div>
                  <span
                    className={`block text-[10px] mt-1.5 ${
                      isUser ? 'text-orange-200 text-right' : 'text-slate-400'
                    }`}
                  >
                    {msg.timestamp}
                  </span>
                </div>
              </div>
            );
          })}

          {loading && (
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-xl bg-indigo-600 text-white flex items-center justify-center">
                <Bot className="w-4 h-4" />
              </div>
              <div className="bg-slate-100 dark:bg-slate-800 rounded-2xl rounded-tl-none p-4 text-xs text-slate-500 flex items-center gap-2">
                <RefreshCw className="w-3.5 h-3.5 animate-spin text-indigo-500" />
                <span>Forge AI is reasoning...</span>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Quick Suggestion Chips */}
        <div className="px-4 py-2 bg-slate-50/70 dark:bg-slate-900/50 border-t border-slate-100 dark:border-slate-800/80 flex items-center gap-2 overflow-x-auto scrollbar-none">
          {quickChips.map((chip) => (
            <button
              key={chip}
              onClick={() => handleSendMessage(chip)}
              className="px-3 py-1 rounded-full text-xs font-semibold bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-orange-50 hover:text-orange-600 dark:hover:bg-slate-700 whitespace-nowrap transition-colors"
            >
              {chip}
            </button>
          ))}
        </div>

        {/* Input Bar */}
        <div className="p-4 border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-850">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSendMessage();
            }}
            className="flex items-center gap-2"
          >
            <input
              id="forge-ai-input"
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder={`Ask Forge AI about ${career.title}, requesting hints, concepts, or exercises...`}
              className="flex-1 px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-white placeholder-slate-400 text-xs sm:text-sm focus:ring-2 focus:ring-indigo-500 focus:outline-none"
            />

            <button
              id="forge-ai-send-btn"
              type="submit"
              disabled={!input.trim() || loading}
              className="px-5 py-3 rounded-xl bg-indigo-600 hover:bg-indigo-700 disabled:opacity-40 text-white text-xs font-bold inline-flex items-center gap-1.5 transition-colors shadow-sm"
            >
              <span>Send</span>
              <Send className="w-3.5 h-3.5" />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
