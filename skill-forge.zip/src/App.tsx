import React, { useState, useEffect } from 'react';
import { useUserStore } from './store/userStore';
import { Navbar } from './components/Navbar';
import { BottomNav } from './components/BottomNav';
import { DashboardView } from './components/DashboardView';
import { CareerExplorerView } from './components/CareerExplorerView';
import { SkillTreeView } from './components/SkillTreeView';
import { ChallengesProjectsView } from './components/ChallengesProjectsView';
import { ForgeAIPanel } from './components/ForgeAIPanel';
import { ProfileView } from './components/ProfileView';
import { ModuleRunnerModal } from './components/ModuleRunnerModal';
import { ChallengeSolverModal } from './components/ChallengeSolverModal';
import { GlobalSearchModal } from './components/GlobalSearchModal';
import { DAILY_CHALLENGES } from './data/challenges';
import { DailyChallenge } from './types';
import { Bot, Sparkles } from 'lucide-react';

export default function App() {
  const {
    profile,
    addXp,
    selectCareer,
    completeModule,
    markSkillDemonstrated,
    recordWeakArea,
    clearWeakArea,
    submitProject,
    resetAllProgress,
  } = useUserStore();

  const [currentTab, setCurrentTab] = useState<string>('home');
  const [skillTreeCareerId, setSkillTreeCareerId] = useState<string>(profile.selectedCareerId);

  // Modals & Assistant state
  const [activeModuleId, setActiveModuleId] = useState<string | null>(null);
  const [activeChallenge, setActiveChallenge] = useState<DailyChallenge | null>(null);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [aiPromptToSend, setAiPromptToSend] = useState<string | undefined>(undefined);

  // Dark mode
  const [darkMode, setDarkMode] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem('skillforge_theme');
      if (saved) return saved === 'dark';
      return window.matchMedia('(prefers-color-scheme: dark)').matches;
    } catch {
      return false;
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem('skillforge_theme', darkMode ? 'dark' : 'light');
    } catch (e) {}

    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  // Sync skill tree career with active career if changed
  useEffect(() => {
    setSkillTreeCareerId(profile.selectedCareerId);
  }, [profile.selectedCareerId]);

  // Keyboard shortcut for search
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === '/' && !['INPUT', 'TEXTAREA'].includes((e.target as HTMLElement)?.tagName)) {
        e.preventDefault();
        setIsSearchOpen(true);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const handleOpenAIWithPrompt = (prompt: string) => {
    setAiPromptToSend(prompt);
    setCurrentTab('forge-ai');
  };

  const handleOpenChallengeById = (challengeId: string) => {
    const found = DAILY_CHALLENGES.find((c) => c.id === challengeId) || DAILY_CHALLENGES[0];
    setActiveChallenge(found);
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 dark:bg-slate-900 dark:text-slate-100 flex flex-col font-sans transition-colors duration-200">
      {/* Top Navigation */}
      <Navbar
        currentTab={currentTab}
        setCurrentTab={setCurrentTab}
        profile={profile}
        darkMode={darkMode}
        setDarkMode={setDarkMode}
        onOpenSearch={() => setIsSearchOpen(true)}
        onOpenAI={() => setCurrentTab('forge-ai')}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 pt-6 pb-20 xl:pb-12">
        {currentTab === 'home' && (
          <DashboardView
            profile={profile}
            setCurrentTab={setCurrentTab}
            onOpenModule={(mId) => setActiveModuleId(mId)}
            onOpenChallenge={(ch) => setActiveChallenge(ch)}
            onOpenAIWithPrompt={handleOpenAIWithPrompt}
          />
        )}

        {currentTab === 'careers' && (
          <CareerExplorerView
            profile={profile}
            onSelectCareer={(cId) => selectCareer(cId)}
            onOpenSkillTree={(cId) => {
              setSkillTreeCareerId(cId);
              setCurrentTab('skills');
            }}
          />
        )}

        {currentTab === 'skills' && (
          <SkillTreeView
            profile={profile}
            selectedCareerId={skillTreeCareerId}
            onSelectCareer={(cId) => setSkillTreeCareerId(cId)}
            onOpenModule={(mId) => setActiveModuleId(mId)}
            onDemonstrateSkill={(skillId) => {
              // Open today's challenge as practical demonstration
              setActiveChallenge(DAILY_CHALLENGES[0]);
              markSkillDemonstrated(skillId);
            }}
          />
        )}

        {currentTab === 'challenges' && (
          <ChallengesProjectsView
            profile={profile}
            onOpenChallenge={(ch) => setActiveChallenge(ch)}
            onSubmitProject={(proj) => submitProject(proj)}
          />
        )}

        {currentTab === 'forge-ai' && (
          <ForgeAIPanel
            profile={profile}
            initialPrompt={aiPromptToSend}
            onClearInitialPrompt={() => setAiPromptToSend(undefined)}
          />
        )}

        {currentTab === 'profile' && (
          <ProfileView
            profile={profile}
            setCurrentTab={setCurrentTab}
            onResetProgress={resetAllProgress}
          />
        )}
      </main>

      {/* Floating Forge AI Quick Trigger (visible if not on forge-ai tab) */}
      {currentTab !== 'forge-ai' && (
        <button
          id="floating-ai-button"
          onClick={() => setCurrentTab('forge-ai')}
          className="fixed bottom-20 xl:bottom-8 right-5 z-40 flex items-center gap-2.5 px-4 py-3 rounded-full bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white font-bold text-xs shadow-lg shadow-indigo-500/25 hover:scale-105 transition-all"
          title="Ask Forge AI"
        >
          <Bot className="w-4 h-4" />
          <span className="hidden sm:inline">Ask Forge AI</span>
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
        </button>
      )}

      {/* Mobile Bottom Navigation */}
      <BottomNav currentTab={currentTab} setCurrentTab={setCurrentTab} />

      {/* Interactive Module Runner Modal */}
      {activeModuleId && (
        <ModuleRunnerModal
          moduleId={activeModuleId}
          onClose={() => setActiveModuleId(null)}
          onComplete={(modId, skId, earnedXp) => {
            completeModule(modId, skId, earnedXp);
          }}
          onRecordWeakArea={(skId, topic) => recordWeakArea(skId, topic)}
          onOpenAIWithPrompt={(prompt) => {
            setActiveModuleId(null);
            handleOpenAIWithPrompt(prompt);
          }}
        />
      )}

      {/* Interactive Practical Challenge Solver Modal */}
      {activeChallenge && (
        <ChallengeSolverModal
          challenge={activeChallenge}
          onClose={() => setActiveChallenge(null)}
          onComplete={(earnedXp) => {
            addXp(earnedXp);
          }}
          onOpenAIWithPrompt={(prompt) => {
            setActiveChallenge(null);
            handleOpenAIWithPrompt(prompt);
          }}
        />
      )}

      {/* Global Search Modal */}
      <GlobalSearchModal
        isOpen={isSearchOpen}
        onClose={() => setIsSearchOpen(false)}
        onSelectCareer={(cId) => selectCareer(cId)}
        onOpenModule={(mId) => setActiveModuleId(mId)}
        onOpenChallenge={handleOpenChallengeById}
        setCurrentTab={setCurrentTab}
      />
    </div>
  );
}
