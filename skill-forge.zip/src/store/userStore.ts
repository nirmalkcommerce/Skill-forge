import { useState, useEffect } from 'react';
import { UserProfile, CompletedProjectItem, Achievement } from '../types';

const INITIAL_ACHIEVEMENTS: Achievement[] = [
  {
    id: 'ach-first-step',
    title: 'First Step Taken',
    desc: 'Completed your first interactive skill module',
    icon: 'Footprints',
    category: 'skill',
    unlockedAt: '2026-09-12T10:00:00Z',
  },
  {
    id: 'ach-sql-found',
    title: 'SQL Foundations',
    desc: 'Demonstrated proficiency in database querying and conditional filters',
    icon: 'Database',
    category: 'skill',
    unlockedAt: '2026-09-14T14:30:00Z',
  },
  {
    id: 'ach-first-project',
    title: 'First Project Shipped',
    desc: 'Completed a simulated workplace project and published to Portfolio',
    icon: 'Award',
    category: 'project',
    unlockedAt: '2026-09-15T09:15:00Z',
  },
  {
    id: 'ach-streak-7',
    title: '7-Day Streak Warrior',
    desc: 'Practiced practical career skills 7 consecutive days',
    icon: 'Flame',
    category: 'streak',
    unlockedAt: '2026-09-16T08:00:00Z',
  },
  {
    id: 'ach-real-solver',
    title: 'Workplace Problem Solver',
    desc: 'Submitted an executive-level solution to a practical business challenge',
    icon: 'CheckCircle2',
    category: 'readiness',
  },
];

const INITIAL_PROJECTS: CompletedProjectItem[] = [
  {
    id: 'init-proj-1',
    projectId: 'da-project-1',
    title: 'Retail Sales Retention & Customer Churn Analysis',
    careerTitle: 'Data Analyst',
    completedAt: '2026-09-15',
    summary:
      'Diagnosed 14% drop in repeat customer orders by writing cohort SQL queries and building a visual retention curve for executive review.',
    artifactsLink: 'github.com/alex-forge/retail-retention-analysis',
    keyFindings:
      'Repeat order decline was heavily concentrated in shipping delays over 4 days. Customers experiencing on-time delivery had an 82% 60-day repurchase rate.',
    demonstratedSkills: ['SQL Cohorts', 'Excel XLOOKUP', 'Visual Storytelling', 'Executive Summary'],
  },
];

const DEFAULT_USER: UserProfile = {
  name: 'Alex',
  selectedCareerId: 'data-analyst',
  level: 4,
  xp: 850,
  streakDays: 7,
  lastActiveDate: new Date().toISOString().split('T')[0],
  completedModuleIds: ['da-found-1', 'da-excel-1', 'da-sql-1'],
  completedSkillIds: ['da-foundation', 'da-excel'],
  demonstratedSkillIds: ['da-foundation'],
  completedProjects: INITIAL_PROJECTS,
  weakAreas: [
    { skillId: 'da-sql', topic: 'Three-valued logic & NULL comparisons', count: 1 },
    { skillId: 'da-stats', topic: 'Outlier distortion in right-skewed data', count: 1 },
  ],
  achievements: INITIAL_ACHIEVEMENTS,
};

const STORAGE_KEY = 'skillforge_user_state_v1';

export function useUserStore() {
  const [profile, setProfile] = useState<UserProfile>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        return JSON.parse(stored);
      }
    } catch (e) {
      console.error('Failed to load user store from localStorage', e);
    }
    return DEFAULT_USER;
  });

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(profile));
    } catch (e) {
      console.error('Failed to persist user store to localStorage', e);
    }
  }, [profile]);

  const addXp = (amount: number) => {
    setProfile((prev) => {
      const newXp = prev.xp + amount;
      const newLevel = Math.floor(newXp / 250) + 1;
      return {
        ...prev,
        xp: newXp,
        level: newLevel,
      };
    });
  };

  const selectCareer = (careerId: string) => {
    setProfile((prev) => ({
      ...prev,
      selectedCareerId: careerId,
    }));
  };

  const completeModule = (moduleId: string, skillId: string, earnedXp = 50) => {
    setProfile((prev) => {
      const already = prev.completedModuleIds.includes(moduleId);
      const newCompletedModules = already
        ? prev.completedModuleIds
        : [...prev.completedModuleIds, moduleId];

      // Check if all modules in skill are complete
      const newCompletedSkills = prev.completedSkillIds.includes(skillId)
        ? prev.completedSkillIds
        : [...prev.completedSkillIds, skillId];

      const newXp = already ? prev.xp : prev.xp + earnedXp;
      const newLevel = Math.floor(newXp / 250) + 1;

      return {
        ...prev,
        completedModuleIds: newCompletedModules,
        completedSkillIds: newCompletedSkills,
        xp: newXp,
        level: newLevel,
      };
    });
  };

  const markSkillDemonstrated = (skillId: string) => {
    setProfile((prev) => {
      if (prev.demonstratedSkillIds.includes(skillId)) return prev;
      return {
        ...prev,
        demonstratedSkillIds: [...prev.demonstratedSkillIds, skillId],
        xp: prev.xp + 100,
        level: Math.floor((prev.xp + 100) / 250) + 1,
      };
    });
  };

  const recordWeakArea = (skillId: string, topic: string) => {
    setProfile((prev) => {
      const existing = prev.weakAreas.find((w) => w.topic === topic);
      if (existing) {
        return {
          ...prev,
          weakAreas: prev.weakAreas.map((w) =>
            w.topic === topic ? { ...w, count: w.count + 1 } : w
          ),
        };
      }
      return {
        ...prev,
        weakAreas: [...prev.weakAreas, { skillId, topic, count: 1 }],
      };
    });
  };

  const clearWeakArea = (topic: string) => {
    setProfile((prev) => ({
      ...prev,
      weakAreas: prev.weakAreas.filter((w) => w.topic !== topic),
    }));
  };

  const submitProject = (projectItem: Omit<CompletedProjectItem, 'id' | 'completedAt'>) => {
    const newItem: CompletedProjectItem = {
      ...projectItem,
      id: 'proj-' + Date.now(),
      completedAt: new Date().toISOString().split('T')[0],
    };

    setProfile((prev) => {
      const newProjects = [newItem, ...prev.completedProjects];
      const newXp = prev.xp + 150;
      const newLevel = Math.floor(newXp / 250) + 1;

      // Unlock project achievement if not already
      const hasProjAch = prev.achievements.some((a) => a.id === 'ach-first-project');
      const updatedAchievements = hasProjAch
        ? prev.achievements
        : [
            ...prev.achievements,
            {
              id: 'ach-first-project',
              title: 'First Project Shipped',
              desc: 'Completed a simulated workplace project and published to Portfolio',
              icon: 'Award',
              category: 'project' as const,
              unlockedAt: new Date().toISOString(),
            },
          ];

      return {
        ...prev,
        completedProjects: newProjects,
        xp: newXp,
        level: newLevel,
        achievements: updatedAchievements,
      };
    });
  };

  const resetAllProgress = () => {
    setProfile(DEFAULT_USER);
  };

  return {
    profile,
    addXp,
    selectCareer,
    completeModule,
    markSkillDemonstrated,
    recordWeakArea,
    clearWeakArea,
    submitProject,
    resetAllProgress,
  };
}
