export type SkillState = 'locked' | 'not_started' | 'in_progress' | 'completed' | 'demonstrated';

export interface AssessmentQuestion {
  id: string;
  type: 'mcq' | 'scenario' | 'code';
  prompt: string;
  options?: string[];
  correctAnswer?: number | string;
  explanation: string;
}

export interface SkillModule {
  id: string;
  skillId: string;
  title: string;
  estimatedMinutes: number;
  goal: string;
  learnContent: {
    keyConcepts: string[];
    explanation: string;
    workplaceContext: string;
  };
  example: {
    title: string;
    description: string;
    codeSnippet?: string;
    sampleData?: {
      headers: string[];
      rows: (string | number)[][];
    };
    keyTakeaway: string;
  };
  practice: {
    question: string;
    options: string[];
    correctIndex: number;
    explanation: string;
    hint: string;
  };
  apply: {
    title: string;
    scenario: string;
    starterQueryOrText?: string;
    expectedKeywords?: string[];
    modelSolution: string;
    rubricTip: string;
  };
  assessment: {
    questions: AssessmentQuestion[];
  };
}

export interface SkillNode {
  id: string;
  title: string;
  shortDesc: string;
  category: 'foundation' | 'core' | 'advanced' | 'integration' | 'project';
  prerequisites: string[]; // Node IDs required before unlocking
  estimatedMinutes: number;
  icon: string;
  modules: SkillModule[];
}

export interface CareerProjectStep {
  title: string;
  description: string;
  deliverable: string;
}

export interface CareerProject {
  id: string;
  careerId: string;
  title: string;
  summary: string;
  skillsCovered: string[];
  difficulty: 'Standard' | 'Advanced';
  estimatedTime: string;
  steps: CareerProjectStep[];
  sampleDataOrScenario: string;
  rubric: string[];
}

export interface CareerCoreSkill {
  name: string;
  proficiencyTarget: number; // 0-100
  description: string;
}

export interface Career {
  id: string;
  title: string;
  tagline: string;
  category:
    | 'Technology'
    | 'Data & AI'
    | 'Business'
    | 'Design'
    | 'Marketing'
    | 'Finance'
    | 'Security'
    | 'Management'
    | 'Content'
    | 'Entrepreneurship';
  icon: string;
  summary: string;
  responsibilities: string[];
  estimatedHours: string;
  prerequisites: string[];
  difficulty: 'Beginner Friendly' | 'Intermediate' | 'Advanced';
  coreSkills: CareerCoreSkill[];
  skillTree: SkillNode[];
  projects: CareerProject[];
  assessmentOverview: string;
  realWorldOutcome: string;
}

export interface CompletedProjectItem {
  id: string;
  projectId: string;
  title: string;
  careerTitle: string;
  completedAt: string;
  summary: string;
  artifactsLink?: string;
  keyFindings: string;
  demonstratedSkills: string[];
}

export interface Achievement {
  id: string;
  title: string;
  desc: string;
  icon: string;
  category: 'skill' | 'project' | 'streak' | 'readiness';
  unlockedAt?: string;
}

export interface UserProfile {
  name: string;
  selectedCareerId: string;
  level: number;
  xp: number;
  streakDays: number;
  lastActiveDate: string;
  completedModuleIds: string[];
  completedSkillIds: string[];
  demonstratedSkillIds: string[];
  completedProjects: CompletedProjectItem[];
  weakAreas: {
    skillId: string;
    topic: string;
    count: number;
  }[];
  achievements: Achievement[];
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  sender?: 'user' | 'assistant';
  text?: string;
  timestamp: string;
  source?: 'gemini' | 'fallback' | 'system';
}

export interface DailyChallenge {
  id: string;
  title: string;
  careerCategory: string;
  skill: string;
  prompt: string;
  xpReward: number;
  taskType: 'analysis' | 'code' | 'decision' | 'writing';
  sampleContext: string;
  starterInput?: string;
  solutionGuide: string;
}
